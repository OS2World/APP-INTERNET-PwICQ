/*
 * DLGPROC.C - Dialog procedure
 */

 #pragma strings(readonly)

 #define INCL_WIN

 #include <stdio.h>
 #include <malloc.h>
 #include <string.h>

 #include "wintlkt.h"

/*---[ Estruturas ]-----------------------------------------------------------------------------------*/

 struct config
 {
    USHORT		sz;
    const DLGMGR        *mgr;
    ULONG               uin;
    HICQ                icq;
    int                 extraBytes;

    char                buffer[0x0100];
 };

/*---[ Prototipos ]-----------------------------------------------------------------------------------*/

 static void configure(HWND hwnd, struct cfgdlgparm *);
 static void destroy(HWND);
 static void load(HWND);
 static void save(HWND);
 static void event(HWND,UCHAR,USHORT,ULONG);
 static void searchButton(HWND,HWND,USHORT);

 static int  command(HWND, USHORT, USHORT, USHORT);
 static int  control(HWND,USHORT, USHORT, ULONG);

/*---[ Constantes ]-----------------------------------------------------------------------------------*/

 static int  _System readCheckBox(HWND,ULONG,USHORT,const char *,BOOL);
 static int  _System readString(HWND,ULONG,USHORT,const char *,int,const char *);
 static int  _System readRadioButton(HWND,ULONG,USHORT,const char *, int, int);
 static int  _System readSpinButton(HWND,ULONG,USHORT,const char *, int, int, int);

 static int  _System saveCheckBox(HWND,ULONG,USHORT,const char *);
 static int  _System saveString(HWND,ULONG,USHORT,const char *, int);
 static int  _System saveRadioButton(HWND,ULONG,USHORT,const char *, int);
 static int  _System saveSpinButton(HWND,ULONG,USHORT,const char *);

 static int  _System browseFiles(HWND, USHORT, BOOL, const char *, const char *, const char *, char *, int (* _System)(const struct dlghelper *,HWND,HICQ,char *));
 static int  _System populateEventList(HWND, USHORT);

 static void * _System getConfig(HWND);

 static const DLGHELPER dlgHelper = {  sizeof(DLGHELPER),
                                       setString,
                                       getString,

                                       setCheckBox,
                                       getCheckBox,

                                       setRadioButton,
                                       getRadioButton,

                                       getLength,
                                       enableControl,
                                       setTextLimit,

                                       listBoxInsert,
                                       listBoxQuery,

                                       populateEventList,
                                       browseFiles,

                                       readCheckBox,
                                       readString,
                                       readRadioButton,
                                       readSpinButton,

                                       saveCheckBox,
                                       saveString,
                                       saveRadioButton,
                                       saveSpinButton,

                                       getConfig

                                 };

/*---[ Implementacao ]--------------------------------------------------------------------------------*/

 MRESULT EXPENTRY cfgDialogProc(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_DESTROY:
       destroy(hwnd);
       return WinDefDlgProc(hwnd,msg,mp1,mp2);

    case WM_INITDLG:
       configure(hwnd,(struct cfgdlgparm * ) mp2);
       return WinDefDlgProc(hwnd,msg,mp1,mp2);

    case WMICQ_LOAD:            /* Load */
       load(hwnd);
       break;

    case WMICQ_SAVE:            /* Save */
       save(hwnd);
       break;

    case WMICQ_SELECTED:        /* Selected */
       CHKPoint();
//       select(hwnd);
       break;

    case WMICQ_EVENT:           /* ICQ event */
       event(hwnd,CHAR3FROMMP(mp1),SHORT1FROMMP(mp1),(ULONG) mp2);
       break;

    case WMICQ_SEARCH:		/* Button click, MP1=click MP2=HWND */
       searchButton(hwnd,(HWND) mp2,SHORT1FROMMP(mp1));
       break;

    case WM_COMMAND:            /* Acao de controle */
       if(command(hwnd, SHORT1FROMMP(mp1), SHORT1FROMMP(mp2), SHORT2FROMMP(mp1)))
          return WinDefDlgProc(hwnd,msg,mp1,mp2);
       break;

    case WM_CONTROL:    /* Control event */
       control(hwnd,SHORT1FROMMP(mp1),SHORT2FROMMP(mp1),LONGFROMMP(mp2));
       break;

    default:
       return WinDefDlgProc(hwnd,msg,mp1,mp2);
    }

    return 0;
 }

 static void configure(HWND hwnd, struct cfgdlgparm *parm)
 {
    char                buffer[0x0100];
    struct config       *cfg;
    int                 sz      = 0;

    WinEnableWindow(hwnd,FALSE);
    WinSetWindowPtr(hwnd,QWL_USER,NULL);

    if(parm->mgr && parm->mgr->sz != sizeof(DLGMGR))
       return;

    if(parm->mgr && parm->mgr->configure)
       sz = parm->mgr->configure(&dlgHelper,hwnd,parm->icq,parm->uin,buffer);

    if(sz < 0)
       return;

    cfg = malloc(sizeof(struct config)+sz);

    WinSetWindowPtr(hwnd,QWL_USER,cfg);

    if(!cfg)
       return;

    memset(cfg,0,sizeof(struct config)+sz);

    cfg->sz		= sizeof(struct config);
    cfg->extraBytes     = sz;
    cfg->mgr            = parm->mgr;
    cfg->uin            = parm->uin;
    cfg->icq            = parm->icq;

    WinEnableWindow(hwnd,TRUE);

    return;
 }

 static void destroy(HWND hwnd)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    if(!cfg)
       return;
    free(cfg);
 }

 int _System readCheckBox(HWND hwnd, ULONG uin, USHORT id, const char *key, BOOL def)
 {
    struct config       *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    BOOL                flag;

    if(!cfg)
       return -1;

    flag = icqLoadValue(cfg->icq, key, def ? 1 : 0);
    return WinCheckButton(hwnd,id,flag);
 }

 static int _System readString(HWND hwnd, ULONG uin, USHORT id, const char *key, int sz, const char *def)
 {
    struct config       *cfg    = WinQueryWindowPtr(hwnd,QWL_USER);
    char                *buffer;
    HWND                h       = WinWindowFromID(hwnd,id);

    if(!cfg)
       return -1;

    if(sz >= 0x0100)
    {
       buffer = malloc(sz+5);
       if(!buffer)
          return -1;
    }
    else
    {
       buffer = cfg->buffer;
    }

    *buffer = 0;
    icqLoadString(cfg->icq, key, def, buffer, sz);
    WinSetWindowText(h,buffer);

    if(sz >= 0x0100)
       free(buffer);

    return 0;;
 }

 int _System readRadioButton(HWND hwnd, ULONG uin, USHORT id, const char *key, int qtd, int def)
 {
    struct config       *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    int                 pos;

    if(!cfg)
       return -1;

    pos = icqLoadValue(cfg->icq,key,def);

    if(pos >= qtd)
       pos = def;

    WinSendDlgItemMsg(hwnd,id+pos,BM_SETCHECK,MPFROMSHORT(1),0);

    return 0;
 }

 static int _System saveCheckBox(HWND hwnd, ULONG uin, USHORT id, const char *key)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);

    if(cfg)
       icqSaveValue(cfg->icq,key,WinSendDlgItemMsg(hwnd,id,BM_QUERYCHECK,0,0) ? 1 : 0);

    return 0;
 }

 static int _System saveString(HWND hwnd, ULONG uin, USHORT id, const char *key, int sz)
 {
    struct config *cfg          = WinQueryWindowPtr(hwnd,QWL_USER);
    char          *buffer;

    if(!cfg)
       return -1;

    hwnd = WinWindowFromID(hwnd,id);

    sz = WinQueryWindowTextLength(hwnd);

    DBGTrace(sz);

    if(sz > 0xF0)
       buffer = malloc(sz+5);
    else
       buffer = cfg->buffer;

    WinQueryWindowText(hwnd,sz+1,buffer);
    DBGMessage(buffer);

    icqSaveString(cfg->icq, key, buffer);

    if(sz > 0xF0)
       free(buffer);

    return 0;
 }

 static int _System saveRadioButton(HWND hwnd, ULONG uin, USHORT id, const char *key, int qtd)
 {
    struct config       *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    int                 f;

    if(!cfg)
       return -1;

    for(f=0;f<qtd;f++)
    {
       if(WinSendDlgItemMsg(hwnd,id+f,BM_QUERYCHECK,0,0))
       {
          DBGMessage(key);
          DBGTrace(f);
          icqSaveValue(cfg->icq,key,f);
          return 0;
       }
    }

    return 1;
 }

/*
 static void select(HWND hwnd)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
 }
*/

 static void load(HWND hwnd)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);

    DBGTracex(cfg);

    if(!cfg)
       return;

    DBGMessage("Carregar campos");

    if(cfg->mgr && cfg->mgr->sz != sizeof(DLGMGR))
       return;

    if(cfg->mgr && cfg->mgr->load)
    {
       if(cfg->mgr->load(&dlgHelper,hwnd,cfg->icq,cfg->uin,cfg->buffer))
          return;
    }

    WinEnableWindow(hwnd,TRUE);
 }

 static void save(HWND hwnd)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    if(!cfg)
       return;

    if(cfg->mgr && cfg->mgr->sz != sizeof(DLGMGR))
       return;

    DBGMessage("Gravando campos");

    if(cfg->mgr && cfg->mgr->save)
       cfg->mgr->save(&dlgHelper,hwnd,cfg->icq,cfg->uin,cfg->buffer);

 }

 static int _System readSpinButton(HWND hwnd, ULONG uin, USHORT id, const char *key, int def, int min, int max)
 {
    struct config       *cfg    = WinQueryWindowPtr(hwnd,QWL_USER);
    HWND                h       = WinWindowFromID(hwnd,id);

    if(!cfg)
       return -1;

    WinSendMsg(h,SPBM_SETLIMITS,MPFROMLONG(max),MPFROMLONG(min));

    def = icqLoadValue(cfg->icq,key,def);
    WinSendMsg(h,SPBM_SETCURRENTVALUE,MPFROMLONG(def),0);

    return 0;
 }

 static void event(HWND hwnd, UCHAR id, USHORT code, ULONG parm)
 {
    struct config *cfg    = WinQueryWindowPtr(hwnd,QWL_USER);

    if(!cfg)
       return;

    if(cfg->mgr && cfg->mgr->sz != sizeof(DLGMGR))
       return;

    if(cfg->mgr && cfg->mgr->event)
       cfg->mgr->event(&dlgHelper,hwnd,cfg->icq,cfg->uin,id,code,cfg->buffer);

 }


 static int _System saveSpinButton(HWND hwnd, ULONG uin, USHORT id, const char *key)
 {
    ULONG               vlr     = 0;
    struct config       *cfg    = WinQueryWindowPtr(hwnd,QWL_USER);
    HWND                h       = WinWindowFromID(hwnd,id);

    if(!cfg)
       return -1;


    WinSendMsg(h,SPBM_QUERYVALUE,MPFROMP(&vlr),MPFROM2SHORT(0,SPBQ_ALWAYSUPDATE));

    icqSaveValue(cfg->icq,key,vlr);

    return 0;
 }


 static void * _System getConfig(HWND hwnd)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    if(cfg && cfg->extraBytes > 0)
       return (cfg+1);
    return NULL;
 }

 static int command(HWND hwnd, USHORT id, USHORT cmd, USHORT parm)
 {
    struct config       *cfg            = WinQueryWindowPtr(hwnd,QWL_USER);
    HWND                h               = WinWindowFromID(hwnd,id);
//    char                class[20];

    if(!cfg || cmd != CMDSRC_PUSHBUTTON)
       return -1;

    if(cfg->mgr->click)
       cfg->mgr->click(&dlgHelper,hwnd,cfg->icq,cfg->uin,id,cfg->buffer);

    return 0;
 }

 static int control(HWND hwnd, USHORT id, USHORT code, ULONG parm)
 {
    /* Processa um controle */
    HWND                h               = WinWindowFromID(hwnd,id);
    ULONG               hdl             = 0;
    USHORT              pos             = 0xFFFF;
    struct config       *cfg            = WinQueryWindowPtr(hwnd,QWL_USER);
    char                class[20];

    if(!cfg)
       return 0;

    if(!cfg->mgr)
       return 0;

    if(!h)
       return 0;

    WinQueryClassName(h,19,class);

//    DBGMessage(class);
// #3 = button

    if( !(strcmp(class,"#2") && strcmp(class,"#7")) && code == LN_SELECT)
    {
       /* DropDown/ListBox Select */
       pos = SHORT1FROMMR(WinSendMsg(h,LM_QUERYSELECTION,MPFROMSHORT(LIT_FIRST),0));

       if(pos != LIT_NONE)
          hdl = LONGFROMMR(WinSendMsg(h,LM_QUERYITEMHANDLE,MPFROMSHORT(pos),0));

       DBGTracex(hdl);

       if(cfg->mgr->selected)
          cfg->mgr->selected(&dlgHelper,hwnd,cfg->icq,cfg->uin,id,hdl,cfg->buffer);
    }
    else if( !strcmp(class,"#6") && code == EN_CHANGE )
    {
       if(cfg->mgr->changed)
          cfg->mgr->changed(&dlgHelper,hwnd,cfg->icq,cfg->uin,id,(USHORT) WinQueryWindowTextLength(h), cfg->buffer);
    }

    return 0;
 }

 static int _System browseFiles(HWND hwnd, USHORT id, BOOL save, const char *key, const char *masc, const char *title, char *vlr,int (* _System callBack)(const struct dlghelper *,HWND,HICQ,char *))
 {
    struct config  *cfg = WinQueryWindowPtr(hwnd,QWL_USER);
    if(!cfg)
       return -1;
    return selectFile(hwnd, cfg->icq, id, save, key, masc, title, vlr, callBack, &dlgHelper);
 }

 static int _System populateEventList(HWND hwnd,USHORT id)
 {
    HAB         	hab     = WinQueryAnchorBlock(hwnd);
    struct config	*cfg	= WinQueryWindowPtr(hwnd,QWL_USER);

    FILE		*arq;
    char		buffer[0x0100];
    char		*ptr;
    short       	item;
    ULONG       	hdl;

    icqQueryProgramPath(cfg->icq,"events.dat",cfg->buffer,0xFF);
    DBGMessage(cfg->buffer);

    hwnd = WinWindowFromID(hwnd,id);

    arq = fopen(cfg->buffer,"r");
    if(!arq)
    {
       WinEnableWindow(hwnd,FALSE);
       return -1;
    }

    while(!feof(arq))
    {
       *buffer = 0;
       fgets(buffer,0xFF,arq);

       *(buffer+0xFF) = 0;
       for(ptr = buffer;*ptr && *ptr >= ' ';ptr++);
       *ptr = 0;

       if(strlen(buffer) > 6 && *buffer != ';')
       {
          ptr  = buffer+5;
          item = SHORT1FROMMR(WinSendMsg(hwnd,LM_INSERTITEM,MPFROMSHORT(LIT_END),MPFROMP(ptr)));
          if(item == LIT_ERROR || item == LIT_MEMERROR)
          {
             WinEnableWindow(hwnd,FALSE);
             fclose(arq);
             return -1;
          }
          WinSendMsg(hwnd,LM_SETITEMHANDLE,MPFROMSHORT(item),MPFROMLONG( *((ULONG *)buffer) ));
       }
    }
    fclose(arq);

    return 0;
 }

 static void searchButton(HWND hwnd, HWND to, USHORT id)
 {
    struct config *cfg = WinQueryWindowPtr(hwnd,QWL_USER);

    DBGMessage("Search Button");
    DBGTrace(id);
    DBGTracex(cfg);
    DBGTrace(cfg->sz);
    DBGTrace(sizeof(struct config));

    if(cfg && cfg->mgr && cfg->mgr->sysButton)
       cfg->mgr->sysButton(&dlgHelper,hwnd,cfg->icq,cfg->uin,to,id,searchCallback,cfg->buffer);
 }


