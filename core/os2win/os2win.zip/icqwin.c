/*
 * ICQWIN.C - Funcoes principais do modulo de caixa de dialogo
 */

 #include <string.h>
 #include <stdio.h>
 #include <malloc.h>

 #define INCL_WIN
 #include "wintlkt.h"

/*---[ Publics ]-------------------------------------------------------------------------------------------*/

 extern HMODULE module = NULLHANDLE;

/*---[ Constantes ]----------------------------------------------------------------------------------------*/

/*---[ Implementacao ]-------------------------------------------------------------------------------------*/

 unsigned long _System _DLL_InitTerm(unsigned long hModule, unsigned long ulFlag)
 {
    switch (ulFlag)
    {
    case 0 :
       if (_CRT_init() == -1)
          return 0UL;
       break;

    case 1 :
       break;

    default  :
       return 0UL;
    }

    module = hModule;
    return 1UL;
 }

 APIRET EXPENTRY icqStartWindowTools(HICQ icq, HAB hab)
 {

    DBGMessage("ICQWin - Debug");

    if(icqQueryUserDataBlockLength() != sizeof(ICQUSER))
    {
       icqWriteSysLog(icq,PROJECT,"Invalid core version detected");
       return -1;
    }

    icqWriteSysLog(icq,PROJECT,"OS/2 PM layer version " OS2WIN_VERSION " Build " __DATE__ " " __TIME__ " by " USER "@" HOSTNAME);
#ifdef EXTENDED_LOG
    icqWriteSysLog(NULL,PROJECT,"*** Extensive logging enabled ***");
#endif

    WinRegisterClass(hab,(PSZ) msgClass, messageEditor, CS_SIZEREDRAW, sizeof(PVOID));
    WinRegisterClass(hab,(PSZ) shrClass, shrDialogProc, CS_SIZEREDRAW, sizeof(PVOID));


    return 0;
 }

 APIRET EXPENTRY icqExecuteWindowLoop(HICQ icq, HWND hwnd)
 {
    QMSG        qmsg;
    HAB         hab     = icqQueryAnchorBlock(icq);

#ifndef NDEBUG
//    icqInsertMessage(icq,  5767646, 0, MSG_NORMAL, 0, 0, -1, "Teste de inclusao de mensagem http://www.os2brasil.com.br");
//    icqInsertMessage(icq,  27241234, 0, MSG_NORMAL, 0, 0, -1, "Teste de inclusao de mensagem");
//    icqInsertMessage(icq,  27241234, 0, MSG_URL, 0, 0, -1, "Teste de inclusao de URL�http://www.os2brasil.com.br");
//    icqInsertMessage(icq,  9999, MSG_NORMAL, 0, 0, -1, "Teste de inclusao na fila do sistema");
//    icqInsertMessage(icq,  8888, MSG_URL, 0, 0, -1, "Teste de inclusao de URL�http://www.os2brasil.com.br");
//    icqInsertMessage(icq,  28986464, MSG_ADD, 0, 0, -1, "Sal�Roberto�Salomon�salomon@scr.com.br�0");
//    icqInsertMessage(icq, 0,  28986464, MSG_REQUEST, 0, 0, -1, "Sal�Roberto�Salomon�salomon@scr.com.br�0�Resolve, P�!!!");
//    icqInsertMessage(icq, 111,  28986464, MSG_FILE, 0, 0, -1, "Sal�Roberto�Salomon�salomon@scr.com.br�0�Resolve, P�!!!");
//    icqInsertMessage(icq,  27241234, MSG_AUTHORIZED, 0, 0, -1, "Autorizado!!");
//    icqInsertMessage(icq,  27241234, MSG_REFUSED, 0, 0, -1, "Voce nao e bom o bastante para entrar na minha lista");
 #endif

    while(WinGetMsg(hab,&qmsg,0,0,0))
       WinDispatchMsg(hab,&qmsg);


    return 0;
 }


 APIRET EXPENTRY icqStopWindowTools(HICQ icq)
 {
//    const struct mgritem        *mgr;

    DBGMessage("Encerrando ICQWIN");

/*
    for(mgr = mgrs; mgr->mgr; mgr++)
       WinDestroyPointer(mgr->mgr->dlgIcon);
*/

    return 0;
 }

 void  EXPENTRY icqDefaultMsgPreProcessor(HICQ icq, HUSER usr, ULONG uin, struct icqmsg *msg, BOOL convert)
 {
    /* Pr�-processar uma mensagem */

/*
    const struct mgritem        *mgr    = mgrs;

    while(mgr->mgr)
    {
       if(msg->type == mgr->type)
       {
          msg->mgr = mgr->mgr;
          if(convert && mgr->ajust)
             mgr->ajust( (char *) (msg+1), msg );
          return;
       }
       mgr++;
    }
*/
 }

 void EXPENTRY icqAjustDefaultMsgDialog(HWND hwnd, HICQ icq, ULONG flags, USHORT type, BOOL out)
 {
/*
    WinPostMsg(hwnd,WM_USER+13,MPFROMLONG(flags),MPFROM2SHORT(type,out));
*/
 }

 const MSGMGR * EXPENTRY icqQueryDefaultMsgMgr(HICQ icq)
 {
/*
    return defaultMGR;
*/
    return NULL;
 }

 static void getTitleByMode(HICQ icq, ULONG sel, char *buffer)
 {
    int                 pos;
    const ICQMODETABLE  *mode;

    /* Ajusta pelo modo atual */

    pos = 0;
    for(mode = icqQueryModeTable(icq);mode && mode->descr;mode++)
    {
       if(mode->mode == sel)
       {
          /* Achei o modo */
          strncat(buffer," - ",0xFF);
          strncat(buffer,mode->descr,0xFF);
          return;
       }
       pos++;
    }
 }

 static USHORT getModeIcon(HICQ icq, ULONG sel)
 {
    const ICQMODETABLE  *mode;

    for(mode = icqQueryModeTable(icq);mode && mode->descr; mode++)
    {
       if(mode->mode == sel)
          return mode->icon;
    }
    return ICQICON_ONLINE;
 }

 void EXPENTRY icqAjustFrameTitle(HICQ icq, HWND hwnd, const char *txt, HPOINTER *ptrMode)
 {
    icqWriteSysLog(icq,PROJECT,"Deprecated call to icqAjustFrameTitle()");
 }

 void EXPENTRY icqAjustTaskList(HICQ icq, HWND hwnd, const char *txt)
 {
    ULONG               sel             = icqQueryOnlineMode(icq);
    HMSG                msg             = NULL;
    ULONG               uin;
    int                 pos;
    int                 task            = icqLoadValue(icq,"TaskTITLE",0);
    char                *buffer         = NULL;

    CHKPoint();

    icqQueryFirstMessage(icq, &uin, &msg);

    DBGTracex(txt);

    buffer = malloc(1024);

    if(buffer)
    {
       if(task && txt)
       {
          CHKPoint();
          sprintf(buffer,"%lu - %s",icqQueryUIN(icq),txt);
       }
       else
       {
          sprintf(buffer,"%lu",icqQueryUIN(icq));

          switch(task)
          {
          case 0:                  // No change
             break;

          case 1:
             getTitleByMode(icq,sel,buffer);
             break;

          case 2:
             if(msg)
             {
                strncat(buffer," - ",0xFF);
                pos = strlen(buffer);
                CHKPoint();
                icqQueryMessageTitle(icq, uin, FALSE, msg, buffer + pos, 0xFF - pos);
                CHKPoint();
             }
             else
             {
                getTitleByMode(icq,sel,buffer);
             }
             break;
          }
       }
       DBGMessage(buffer);
       DBGTrace(strlen(buffer));

       WinSendMsg(hwnd,WM_USER+1040,(MPARAM) buffer, 0);

       CHKPoint();
       free(buffer);
    }
    else
    {
       icqWriteSysLog(icq,PROJECT,"Memory allocation error when changing window title");
    }

    switch(icqLoadValue(icq,"TaskICON",0))
    {
    case 0:		// No change
       break;

    case 1:		// By mode
       WinPostMsg(hwnd,WM_USER+1039,(MPARAM) getModeIcon(icq, sel), 0);
       break;

    case 2:		// By message
       if(msg && msg->mgr)
          WinPostMsg(hwnd,WM_USER+1039,(MPARAM) msg->mgr->icon[0], 0);
       else
          WinPostMsg(hwnd,WM_USER+1039,(MPARAM) getModeIcon(icq, sel), 0);
       break;

    }

    CHKPoint();
 }

 int EXPENTRY icqValidateDefaultEditHelper(USHORT sz)
 {
    return sz == sizeof(MSGEDITHELPER) ? 0 : 99;
 }

 int EXPENTRY icqProcessGuiEvent(HICQ icq, ULONG uin, UCHAR type, USHORT event, ULONG parm)
 {
    return 0;
 }

