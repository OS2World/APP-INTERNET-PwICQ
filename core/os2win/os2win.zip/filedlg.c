/*
 * FILEDLG.C - Dialogo de selecao de arquivos
 */

 #pragma strings(readonly)

 #define INCL_WIN
 #include <string.h>
 #include <malloc.h>

 #include <pwMacros.h>

 #include <icqkernel.h>
 #include "wintlkt.h"

 int selectFile(HWND hwnd, HICQ icq, USHORT id, BOOL save, const char *key, const char *masc, const char *title, char *vlr, int (* _System callBack)(const struct dlghelper *,HWND,HICQ,char *), const DLGHELPER *dlgHelper)
 {
    char                temp[80];
    FILEDLG             fild;
    char                *ptr;
    char                *pos;

    CHKPoint();
    memset(&fild,0,sizeof(FILEDLG));

    fild.cbSize      = sizeof(FILEDLG);
    fild.fl          = FDS_CENTER|FDS_OPEN_DIALOG;
    fild.pszTitle    = (PSZ) title;

    if(id)
       WinQueryDlgItemText(hwnd,id,CCHMAXPATH,fild.szFullFile);
    else if(vlr)
       strncpy(vlr,fild.szFullFile,CCHMAXPATH);

    if(!*fild.szFullFile)
    {
        /* Monta a mascara */
       strcpy(temp,"path.");
       strncat(temp,key,79);
       icqLoadString(icq, key, "", fild.szFullFile, 0xFF);

       if(!*fild.szFullFile && icq->sz == sizeof(ICQ))
       {
          strncpy(fild.szFullFile,icq->programPath,CCHMAXPATH);
          strncat(fild.szFullFile,key,CCHMAXPATH);
       }

    }

    strncat(fild.szFullFile,"\\",CCHMAXPATH);
    strncat(fild.szFullFile,masc,CCHMAXPATH);

    DBGMessage(fild.szFullFile);
    DBGMessage(fild.pszTitle);

    if(WinFileDlg(HWND_DESKTOP, hwnd, &fild) && fild.lReturn == DID_OK)
    {
       if(id)
          WinSetDlgItemText(hwnd,id,fild.szFullFile);

       if(callBack)
          callBack(dlgHelper,hwnd,icq,fild.szFullFile);

       if(vlr)
          strncpy(fild.szFullFile,vlr,CCHMAXPATH);

       for(pos = ptr = fild.szFullFile;*ptr;ptr++)
       {
          if(*ptr == '\\' || *ptr == ':')
              pos = ptr;

       }
       *pos = 0;

       DBGMessage(temp);
       DBGMessage(fild.szFullFile);

       icqSaveString(icq, key, fild.szFullFile);

       return strlen(fild.szFullFile);

    }

    return 0;

 }

/*
 void EXPENTRY ICQSelectFile(HWND hwnd, USHORT control, DLGINFO *dlg, const char *filt,const char *tit)
 {
     FILEDLG    fild;
     char       temp[30];
     int        f;

     CHKPoint();
     strncpy(temp,tit,30);

     memset(&fild,0,sizeof(FILEDLG));

     fild.cbSize      = sizeof(FILEDLG);       Size of structure
     fild.fl          = FDS_CENTER|FDS_OPEN_DIALOG;
     fild.pszTitle    = temp;

     DBGMessage(fild.pszTitle);

     WinQueryDlgItemText(hwnd,control,CCHMAXPATH,fild.szFullFile);

     if(!*fild.szFullFile && *dlg->id)
     {
        // Tenta ler ultimo resultado do .INI
        ICQQueryProfileString(  dlg->ctl,
                                "FileDLG",
                                dlg->id,
                                "",
                                fild.szFullFile,
                                CCHMAXPATH);

        if(*fild.szFullFile && filt)
           strncat(fild.szFullFile,filt,CCHMAXPATH);
     }

     if(!*fild.szFullFile)
     {
        ICQQueryProfileString(  dlg->ctl,
                                "MAIN",
                                "DataPath",
                                ".\\",
                                fild.szFullFile,
                                CCHMAXPATH);

        if(filt == NULL)
           strncat(fild.szFullFile,"Sounds\\*.wav",CCHMAXPATH);
        else
           strncat(fild.szFullFile,filt,CCHMAXPATH);
     }

     DBGTrace(fild.cbSize);
     DBGMessage(fild.szFullFile);

     if(WinFileDlg(HWND_DESKTOP, hwnd, &fild) && fild.lReturn == DID_OK)
     {
        WinSetDlgItemText(hwnd,control,fild.szFullFile);

        if(*dlg->id)
        {
           for(f=strlen(fild.szFullFile);f>0 && fild.szFullFile[f] != ':' && fild.szFullFile[f] != '\\' ;f--);
           if(f)
           {
              fild.szFullFile[f+1] = 0;
              DBGMessage(fild.szFullFile);

              PrfWriteProfileString(    icqQueryInifile(dlg->ctl),
                                        "FileDLG",
                                        dlg->id,
                                        fild.szFullFile);
           }
        }
     }
 }

*/

