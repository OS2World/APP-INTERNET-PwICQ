/*
 * wndproc.c - Funcoes de acesso a janelas
 */

 #pragma strings(readonly)

 #define INCL_WIN

 #include <malloc.h>
 #include <string.h>

 #include "wintlkt.h"

/*---[ Implementacao ]--------------------------------------------------------------------------------*/


 int _System setTextLimit(HWND hwnd, USHORT id, short sz)
 {
    char class[20];

    hwnd = WinWindowFromID(hwnd,id);

    WinQueryClassName(hwnd,19,class);

    if(strcmp(class,"#6"))
       return -1;

    WinSendMsg(hwnd,EM_SETTEXTLIMIT,MPFROMSHORT(sz),0);

    return 0;
 }

 int _System getLength(HWND hwnd, USHORT id)
 {
    if(id)
       return WinQueryWindowTextLength(WinWindowFromID(hwnd,id));
    return WinQueryWindowTextLength(hwnd);
 }

 int _System enableControl(HWND hwnd, USHORT id, BOOL modo)
 {
    WinEnableWindow(WinWindowFromID(hwnd,id),modo);
    return 0;
 }

 int _System setString(HWND hwnd, USHORT id, const char *txt)
 {
    if(id)
       return WinSetWindowText(WinWindowFromID(hwnd,id),(PSZ) txt);
    return WinSetWindowText(hwnd,(PSZ) txt);
 }

 int _System setVisible(HWND hwnd, USHORT id, BOOL flag)
 {
    if(id)
       hwnd = WinWindowFromID(hwnd,id);

    if(flag)
       flag = TRUE;

    WinEnableWindow(hwnd,flag);
    WinShowWindow(hwnd,flag);

    return 0;
 }

 int _System getString(HWND hwnd, USHORT id,int sz, char *txt)
 {
    if(id)
       return WinQueryWindowText(WinWindowFromID(hwnd,id),sz,txt);
    return WinQueryWindowText(hwnd,sz,txt);
 }

 int _System setCheckBox(HWND hwnd, USHORT id, BOOL flag)
 {
    WinSendDlgItemMsg(hwnd,id,BM_SETCHECK,MPFROMSHORT(flag ? 1 : 0),0);
    return 0;
 }

 int _System getCheckBox(HWND hwnd, USHORT id)
 {
    return WinSendDlgItemMsg(hwnd,id,BM_QUERYCHECK,0,0) ? 1 : 0;
 }

 int _System listBoxInsert(HWND hwnd, USHORT id, ULONG hdl, const char *txt, BOOL selected)
 {
    short pos;

    hwnd = WinWindowFromID(hwnd,id);

    pos = SHORT1FROMMR(WinSendMsg(hwnd,LM_INSERTITEM,MPFROMSHORT(LIT_END),MPFROMP(txt)));

    if(pos == LIT_ERROR || pos == LIT_MEMERROR)
       return -1;

    WinSendMsg(hwnd,LM_SETITEMHANDLE,MPFROMSHORT(pos),MPFROMLONG(hdl));

    if(selected)
       WinSendMsg(hwnd,LM_SELECTITEM,MPFROMSHORT(pos),MPFROMSHORT(TRUE));

    return pos;
 }

 int  _System listBoxQuery(HWND hwnd, USHORT id, ULONG hdl, int sz, char *buffer)
 {
    short count;
    short pos;

    hwnd    = WinWindowFromID(hwnd,id);
    *buffer = 0;

    if(!hdl)
    {
       pos = SHORT1FROMMR( WinSendMsg(hwnd, LM_QUERYSELECTION, MPFROMSHORT(LIT_CURSOR), 0) );
       if(pos == LIT_NONE)
          return 0;
       return (int) WinSendMsg(hwnd,LM_QUERYITEMTEXT,MPFROM2SHORT(pos,sz),(MPARAM) buffer);
    }

    DBGTrace(count);
    count = SHORT1FROMMR( WinSendMsg(hwnd,LM_QUERYITEMCOUNT,0,0) );

    for(pos = 0; pos < count; pos++)
    {

       if( LONGFROMMR( WinSendMsg(hwnd,LM_QUERYITEMHANDLE,MPFROMSHORT(pos),0) ) == hdl )
          return (int) WinSendMsg(hwnd,LM_QUERYITEMTEXT,MPFROM2SHORT(pos,sz),(MPARAM) buffer);
    }

    return 0;
 }

/*

 int _System populateEventList(HWND hwnd,USHORT id)
 {
    HAB         hab     = WinQueryAnchorBlock(hwnd);
    char        buffer[0x0100];
    USHORT      msg     = 2000;
    char        *ptr;
    short       item;
    ULONG       hdl;

    hwnd = WinWindowFromID(hwnd,id);

    while(WinLoadString(hab, module, msg++, 0xFF, buffer) > 0 && *buffer)
    {
       for(ptr = buffer;*ptr && *ptr != '\n';ptr++);

       if(*ptr == '\n')
       {
          ptr++;
          item = SHORT1FROMMR(WinSendMsg(hwnd,LM_INSERTITEM,MPFROMSHORT(LIT_END),MPFROMP(ptr)));

          if(item == LIT_ERROR || item == LIT_MEMERROR)
          {
             WinEnableWindow(hwnd,FALSE);
             return -1;
          }

          WinSendMsg(hwnd,LM_SETITEMHANDLE,MPFROMSHORT(item),MPFROMLONG( *((ULONG *)buffer) ));
       }
    }

    return 0;
 }

*/

 int _System setRadioButton(HWND hwnd,USHORT id,int pos)
 {
    WinSendDlgItemMsg(hwnd,id+pos,BM_SETCHECK,MPFROMSHORT(1),0);
    return 0;
 }

 int _System getRadioButton(HWND hwnd, USHORT id, short qtd)
 {
    int f;
    CHKPoint();
    for(f=0;f<qtd;f++)
    {
       if(WinSendDlgItemMsg(hwnd,id+f,BM_QUERYCHECK,0,0))
       {
          DBGTrace(f);
          return f;
       }
    }
    return 0;
 }


