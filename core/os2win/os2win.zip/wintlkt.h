/*
 * ICQWIN.H - Funcoes exclusivas para o modulo
 */

 #include <pwMacros.h>
 #include <os2win.h>

 #include <icqtlkt.h>

/*---[ Estruturas ]---------------------------------------------------------------------------*/

 #define OS2WIN_VERSION "1.0"

 #pragma pack(1)
 struct mgritem
 {
    USHORT      type;
    MSGMGR      *mgr;
    void        (* _System ajust)(char *, ICQMSG *);
 };

 struct cfgdlgparm
 {
    USHORT              sz;
    ULONG               uin;
    HICQ                icq;
    const DLGMGR        *mgr;
 };

/*---[ Constantes ]---------------------------------------------------------------------------*/

 extern HMODULE                 module;

 extern const char              *msgClass;
 extern const char              *shrClass;

/*
 extern MSGMGR                  messageMGR[];
 extern MSGMGR                  defaultMGR[];
 extern MSGMGR                  urlMGR[];
 extern MSGMGR                  addMGR[];
 extern MSGMGR                  reqMGR[];
 extern MSGMGR                  autMGR[];
 extern MSGMGR                  refMGR[];

 extern const struct    mgritem    mgrs[];
*/

/*---[ Macros ]------------------------------------------------------------------------------*/

 #define HIDE(x)        WinShowWindow(WinWindowFromID(hwnd,x),FALSE);
 #define SHOW(x)        WinShowWindow(WinWindowFromID(hwnd,x),TRUE);


/*---[ Interface com janelas ]---------------------------------------------------------------*/

 int  _System setString(HWND,USHORT,const char *);
 int  _System getString(HWND,USHORT,int, char *);
 int  _System setCheckBox(HWND,USHORT,BOOL);
 int  _System getCheckBox(HWND,USHORT);
 int  _System getLength(HWND, USHORT);
 int  _System setTextLimit(HWND,USHORT,short);
 int  _System listBoxInsert(HWND,USHORT,ULONG,const char *,BOOL);
 int  _System listBoxQuery(HWND,USHORT,ULONG, int, char *);
 int  _System enableControl(HWND,USHORT,BOOL);
 int  _System populateEventList(HWND,USHORT);
 int  _System setRadioButton(HWND,USHORT,int);
 int  _System getRadioButton(HWND,USHORT,short);
 int  _System setVisible(HWND, USHORT, BOOL);
 int  _System searchCallback(HICQ, ULONG, USHORT, HWND, const ICQSEARCHRESPONSE *);



/*---[ Prototipos ]--------------------------------------------------------------------------*/


 MRESULT EXPENTRY       messageEditor(HWND, ULONG, MPARAM, MPARAM);
 MRESULT EXPENTRY       cfgDialogProc(HWND, ULONG, MPARAM, MPARAM);
 MRESULT EXPENTRY       shrDialogProc(HWND, ULONG, MPARAM, MPARAM);

 HUSER                  fillUserFields(HICQ, HWND, ULONG);

 USHORT                 ajustButtons(HWND, USHORT, USHORT, const USHORT *, const USHORT *);
 USHORT                 ajustLines(HWND, USHORT, USHORT, const USHORT *, const USHORT *);
 USHORT                 defaultTop(HWND, USHORT, USHORT, BOOL);

 void _System           ajustURL(char *, ICQMSG *);
 void _System           ajustADD(char *, ICQMSG *);

 char *                 splitFields(char *, char **, int);
 BOOL                   addUser(HICQ, ULONG, HWND, BOOL);

 BOOL                   sendNormalMSG(HICQ, USHORT, ULONG, HWND);

 int                    selectFile(HWND, HICQ, USHORT, BOOL, const char *, const char *, const char *, char *, int (* _System)(const struct dlghelper *,HWND,HICQ,char *), const DLGHELPER *);

 int _System            unknownMsgFormatter(const MSGEDITHELPER *, hWindow, HICQ, ULONG, USHORT, BOOL, HMSG);












