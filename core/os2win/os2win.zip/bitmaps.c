/*
 * ICQWIN.C - Funcoes principais do modulo de caixa de dialogo
 */

 #include <string.h>
 #include <stdio.h>
 #include <malloc.h>

 #define INCL_WIN
 #define INCL_GPI
 #include "wintlkt.h"

/*---[ Publics ]-------------------------------------------------------------------------------------------*/


/*---[ Constantes ]----------------------------------------------------------------------------------------*/

 #define ICON_TABLE_COUNTER 53
 #define ICON_TABLE_CY     16

/*---[ Implementacao ]-------------------------------------------------------------------------------------*/

 int EXPENTRY icqLoadIconTable(HICQ icq, HBITMAP *img, HBITMAP *msk)
 {
    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HAB                hab             = icqQueryAnchorBlock(icq);
    int                rc              = -1;
    HDC                hdc;
    HPS                hps;
    HBITMAP            src;

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       src = GpiLoadBitmap(hps, module, 30, (ICON_TABLE_COUNTER*ICON_TABLE_CY), ICON_TABLE_CY);
       if(src != GPI_ERROR)
       {
          icqMakeBitmapTransparent(hps, src, img, msk);
          rc =  ICON_TABLE_COUNTER;
       }
       GpiDestroyPS(hps);
    }
    DevCloseDC(hdc);
    return rc;
 }

 int EXPENTRY icqMakeBitmapTransparent(HPS hps, HBITMAP src, HBITMAP *img, HBITMAP *msk)
 {
    int                rc               = 0;
    BITMAPINFOHEADER   bmpData;
    BITMAPINFOHEADER2  bmih;
    POINTL             aptlPoints[4];

    GpiQueryBitmapParameters(src, &bmpData);
    rc = bmpData.cy;

    /* Create masking image */

    memset(&bmih,0, sizeof(BITMAPINFOHEADER2));
    bmih.cbFix        = sizeof(bmih);
    bmih.cx           = bmpData.cx;
    bmih.cy           = bmpData.cy;
    bmih.cPlanes      = 1;
    bmih.cBitCount    = 1;

    *msk = GpiCreateBitmap(hps, &bmih, 0L, NULL, NULL);

    GpiSetBitmap(hps,*msk);

    aptlPoints[0].x=0;
    aptlPoints[0].y=0;
    aptlPoints[1].x=aptlPoints[0].x+bmpData.cx-1;
    aptlPoints[1].y=aptlPoints[0].y+bmpData.cy-1;
    aptlPoints[2].x=0;
    aptlPoints[2].y=0;
    aptlPoints[3].x=aptlPoints[2].x+bmpData.cx;
    aptlPoints[3].y=aptlPoints[2].y+bmpData.cy;

    GpiSetColor(hps,CLR_WHITE);
    GpiSetBackColor(hps,CLR_PINK);
    GpiWCBitBlt(hps,src,4,aptlPoints,ROP_NOTSRCCOPY,BBO_IGNORE);

    /* Create base image */
    *img  = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

    bmih.cbFix        = sizeof(bmih);
    bmih.cx           = bmpData.cx;
    bmih.cy           = bmpData.cy;
    bmih.cPlanes      = 1;
    bmih.cBitCount    = 24;

    *img  = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

    GpiSetBitmap(hps,*img);
    GpiSetColor(hps,CLR_WHITE);
    GpiSetBackColor(hps,CLR_BLACK);

    GpiWCBitBlt( hps,*msk,4,aptlPoints,ROP_NOTSRCCOPY,BBO_IGNORE);
    GpiWCBitBlt( hps,src,4,aptlPoints,ROP_SRCAND,BBO_IGNORE);

    GpiSetBitmap(hps,NULLHANDLE);

    return rc;
 }

 HPOINTER EXPENTRY icqCreatePointer(HICQ icq, int id)
 {
    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HPOINTER           ret			   = NULLHANDLE;
    HAB                hab             = icqQueryAnchorBlock(icq);
    HDC                hdc;
    HPS                hps;

    HBITMAP            bmp;
    HBITMAP            iconImage;
    HBITMAP            iconMasc;

    BITMAPINFOHEADER2  bmih;
    RECTL              rcl;
    POINTL			   p;
    USHORT			   fator;
    int				   iconCount;

    if(id > ICON_TABLE_COUNTER || id < 0)
    {
       icqWriteSysLog(icq,PROJECT,"Invalid icon identifier");
       return NULLHANDLE;
    }

    iconCount = icqLoadIconTable(icq, &iconImage, &iconMasc);

    if(iconCount < 0)
    {
       icqWriteSysLog(icq,PROJECT,"Failure loading icon table");
       return NULLHANDLE;
    }

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       bmih.cbFix        = sizeof(bmih);
       bmih.cx           = ICON_TABLE_CY;
       bmih.cy           = ICON_TABLE_CY*2;
       bmih.cPlanes      = 1;
       bmih.cBitCount    = 24;
       bmp               = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

       GpiSetBitmap(hps,bmp);

/*
       Bit-map handle from which the pointer image is created.

       The bit map must be logically divided into two sections vertically,
       each half representing one of the two images used as the successive
       drawing masks for the pointer.

       For an icon, there are two bit map images.
       The first half is used for the AND mask and the second half is used
       for the XOR mask. For details of bit map formats, see
*/

       rcl.xLeft   =
       rcl.yBottom = 0;

       rcl.yTop    = ICON_TABLE_CY*2;
       rcl.xRight  = ICON_TABLE_CY;

       WinFillRect(hps, &rcl, CLR_BLACK);

       fator       = ICON_TABLE_CY * id;
       rcl.xLeft   = fator;
       rcl.yBottom = 0;
       rcl.yTop    = ICON_TABLE_CY;
       rcl.xRight  = fator+ICON_TABLE_CY;

       p.x = 0;
       p.y = 0;
       WinDrawBitmap(hps, iconImage, &rcl, &p, CLR_WHITE, CLR_BLACK, DBM_NORMAL);

       p.x = 0;
       p.y = ICON_TABLE_CY;
       WinDrawBitmap(hps, iconMasc, &rcl, &p, CLR_WHITE, CLR_BLACK, DBM_NORMAL);

       GpiSetBitmap(hps,NULLHANDLE);

       ret = WinCreatePointer(HWND_DESKTOP, bmp, TRUE, 0, 0);
       DBGTracex(ret);

       GpiDeleteBitmap(bmp);
       GpiDestroyPS(hps);
    }

    DevCloseDC(hdc);

    GpiDeleteBitmap(iconImage);
    GpiDeleteBitmap(iconMasc);

    return ret;

 }


