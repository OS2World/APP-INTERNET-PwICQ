/*
 * MSGDLG.C - Caixa de dialogo default
 */

 #pragma strings(readonly)

 #define INCL_WIN
 #define INCL_NLS
 #define INCL_DOSPROCESS
 #define INCL_GPIPRIMITIVES
 #define INCL_GPILCIDS

 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <time.h>
 #include <ctype.h>

 #include <pwMacros.h>
 #include <icqtlkt.h>
 #include <msgdlg.h>

 #include "wintlkt.h"

/*---[ Macros ]--------------------------------------------------------------------------------------------*/

 #define SETTEXT(h,i,t) WinSetWindowText(WinWindowFromID(h,i),(PSZ) t)

/*---[ Definicoes ]----------------------------------------------------------------------------------------*/

 #pragma pack(1)

 struct parm
 {
    BOOL         flag;
    ULONG        uin;
    USHORT       type;
    HMSG         msg;
    const MSGMGR *mgr;
    char         *text;
    char         *url;
 };

 typedef struct msgedit
 {
    USHORT              sz;

    HAB                 hab;
    HMQ                 hmq;

    HPOINTER            icon;

    QMSG                qmsg;

    HWND                main;
    HWND                frame;

    HWND                sendTo;
    USHORT              lastMenu;

    USHORT              type;
    BOOL                out;
    BOOL                sysMsg;
    BOOL				hasMgr;

    HICQ                icq;
    ULONG               uin;
    ULONG               sequenceNumber;
    HUSER               usr;

    const MSGMGR        *mgr;

 } MSGEDIT;

 typedef struct fieldDescr
 {
    USHORT      id;
    PSZ         wndClass;
    ULONG       style;
 } FIELDDESCR;

 #ifndef MSGEDITWINDOW
    #define MSGEDITWINDOW hWindow
 #endif

/*---[ Prototipos ]----------------------------------------------------------------------------------------*/

 static void  _System   event(ICQTHREAD *, ULONG, char, USHORT, ULONG);
 static void  _System   stopthread(ICQTHREAD *);

 static void  _System   msgThread(ICQTHREAD *);

 static int   _System   setMessage(MSGEDITWINDOW, USHORT, BOOL, HMSG);
 static int   _System   loadUserFields(MSGEDITWINDOW);
 static int   _System   setTitle(MSGEDITWINDOW,const char *);
 static void  _System   loadString(MSGEDITWINDOW, USHORT, USHORT);
 static void  _System   showTime(MSGEDITWINDOW, USHORT, time_t);
 static void  _System   setReply(MSGEDITWINDOW, USHORT);
 static int   _System   setEnabled(hWindow, USHORT, BOOL);
 static void  _System   setEditable(hWindow, USHORT, BOOL);
 static int   _System   queryClipboard(HICQ, int, char *);
 static int   _System   getVisible(hWindow, USHORT);
 static void  _System   setIcon(hWindow,USHORT,USHORT);

 static HWND            createWindow(MSGEDIT *);
 static void            create(HWND, PCREATESTRUCT);
 static void            start(HWND,MSGEDIT *, HMSG);
 static void            paint(HWND);
 static void            resize(HWND, USHORT, USHORT);
 static void            saveWindowPos(HWND, MSGEDIT *);
 static void            sizeControls(HWND, MSGEDIT *);
 static void            action(HWND,USHORT, USHORT);
 static void            chkEvent(HWND,UCHAR,USHORT,ULONG);
 static void            reply(HWND, MSGEDIT *, USHORT);
 static void            ajustQuote(HWND, ULONG, char *);
 static BOOL            navigateWindow(HWND,LONG);
 static BOOL            readNext(MSGEDIT *);
 static void            dblClick(HWND,MSGEDIT *);
 static void            sendOk(HWND, HICQ, MSGEDIT *);
 static void            openURL(HWND, MSGEDIT *);
 static void            menu(HWND,USHORT);
 static void            destroy(HWND, MSGEDIT *);

/*---[ Constantes ]----------------------------------------------------------------------------------------*/

 extern const char      *msgClass       = "pwICQMsgEditor";

/*
   typedef struct _dialogcalls
   {
      USHORT    sz;

	  // Frame Window only
      int          (* _System setTitle)(hWindow,const char *);
      int          (* _System setVisible)(hWindow, USHORT, BOOL);
      int          (* _System setEnabled)(hWindow, USHORT, BOOL);
      int          (* _System setString)(hWindow,USHORT,const char *);
      int          (* _System getString)(hWindow,USHORT,int,char *);
      int          (* _System setCheckBox)(hWindow,USHORT,BOOL);
      int          (* _System getCheckBox)(hWindow,USHORT);
      void         (* _System loadString)(hWindow, USHORT, USHORT);
      void         (* _System setTime)(hWindow, USHORT, time_t);
	  void         (* _System setEditable)(hWindow, USHORT, BOOL);

      // Miscellaneous 	
      int          (* _System queryClipboard)(HICQ, int, char *);
	
	  // Message dialog only
      int          (* _System setMessage)(hWindow, USHORT, BOOL, HMSG);
      int          (* _System loadUserFields)(hWindow);
      void         (* _System setReply)(hWindow, USHORT);

   } DIALOGCALLS;

 */

 static const DIALOGCALLS  msgHelper  =
 {
       sizeof(DIALOGCALLS),
       XBUILD,

       setTitle,
       setVisible,
       getVisible,
       setEnabled,
       setString,
       getString,
       setCheckBox,
       getCheckBox,
       loadString,
       showTime,
       setEditable,
       setIcon,

       queryClipboard,

       setMessage,
       loadUserFields,
       setReply,
 };

 static const FIELDDESCR fields[] =
 {
                ICQMSGC_TEXTBOX,        WC_STATIC,      SS_GROUPBOX | DT_LEFT         | DT_TOP | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,
                ICQMSGC_TOFROM,         WC_STATIC,      SS_GROUPBOX | DT_LEFT         | DT_TOP | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,

                ICQMSGC_STATICNICK,     WC_STATIC,      SS_AUTOSIZE | SS_TEXT         | DT_LEFT | DT_VCENTER | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,
                ICQMSGC_STATICEMAIL,    WC_STATIC,      SS_AUTOSIZE | SS_TEXT         | DT_LEFT | DT_VCENTER | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,
                ICQMSGC_STATICUIN,      WC_STATIC,      SS_AUTOSIZE | SS_TEXT         | DT_LEFT | DT_VCENTER | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,
                ICQMSGC_STATICNAME,     WC_STATIC,      SS_AUTOSIZE | SS_TEXT         | DT_LEFT | DT_VCENTER | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,
                ICQMSGC_STATICSUBJ,     WC_STATIC,      SS_AUTOSIZE | SS_TEXT         | DT_LEFT | DT_VCENTER | DT_MNEMONIC | WS_VISIBLE | WS_GROUP,

                ICQMSGC_NICKNAME,       WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_READONLY | ES_ANY | WS_VISIBLE | WS_GROUP,
                ICQMSGC_UIN,            WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_READONLY | ES_ANY | WS_VISIBLE | WS_GROUP,
                ICQMSGC_EMAIL,          WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_READONLY | ES_ANY | WS_VISIBLE | WS_GROUP,
                ICQMSGC_NAME,           WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_READONLY | ES_ANY | WS_VISIBLE | WS_GROUP,

                ICQMSGC_SUBJECT,        WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_ANY | WS_VISIBLE | WS_GROUP | WS_TABSTOP,

                ICQMSGC_TEXT,           WC_MLE,         MLS_BORDER  | MLS_WORDWRAP    | MLS_HSCROLL | MLS_VSCROLL | MLS_IGNORETAB | WS_VISIBLE | WS_GROUP | WS_TABSTOP,

                ICQMSGC_ENTRY,          WC_ENTRYFIELD,  ES_LEFT     | ES_AUTOSCROLL   | ES_MARGIN | ES_ANY | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_BROWSE,         WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,


                ICQMSGC_CHECKBOX,       WC_BUTTON,      BS_AUTOSIZE | BS_AUTOCHECKBOX | WS_VISIBLE | WS_GROUP | WS_TABSTOP,

                ICQMSGC_ADD,            WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_REJECT,         WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_REFUSE,         WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_ACCEPT,         WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_SEND,           WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_OPEN,           WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_SENDTO,         WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_REPLY,          WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_NEXT,           WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,
                ICQMSGC_CLOSE,          WC_BUTTON,      BS_AUTOSIZE | BS_PUSHBUTTON   | WS_VISIBLE | WS_GROUP | WS_TABSTOP,

                0,              NULL,           0
 };


/*---[ Implementacao ]-------------------------------------------------------------------------------------*/

 APIRET EXPENTRY icqOpenMsgWindow(HICQ icq, ULONG uin, USHORT type, HMSG msg, const MSGMGR *mgr, const char *text, const char *url)
 {
    struct parm p;
    int         f;
    HAB         hab     = icqQueryAnchorBlock(icq);
    char        buffer[0x0100];

    DBGTrace(type);

    if(!type)
    {
       if(msg)
       {
          type = msg->type;
       }
       else if(mgr)
       {
          type = mgr->type;
       }
       else if(url)
       {
          /* Tem uma URL, ajusta a mensagem de acordo */
          type = MSG_URL;
       }
       else if(icqLoadValue(icq,"Chk4URL",1))
       {
          /* Verificar se existe URL no clipboard */
          type = MSG_NORMAL;

          DBGMessage("Verificar clipboard por uma URL valida");

          if (WinOpenClipbrd(hab))
          {
             if( (url = (char *) WinQueryClipbrdData(hab , CF_TEXT)) != NULL)
             {
                DBGMessage(url);
                if( strncmp(url,"http:",5) && strncmp(url,"ftp:",4) && strncmp(url,"https:",6) )
                {
                   url = NULL;
                }
                else
                {
                   strncpy(buffer,url,0xFF);
                   url  = buffer;
                   type = MSG_URL;
                }
             }
             WinCloseClipbrd(hab);
          }
       }
       else
       {
          type = MSG_NORMAL;
       }
    }

    DBGTracex(type);

    p.flag      = TRUE;
    p.uin       = uin;
    p.type      = type;
    p.msg       = msg;
    p.mgr       = mgr;
    p.text      = (char *) text;
    p.url       = (char *) url;

    DBGTrace(uin);

    icqCreateThread(icq, &msgThread, 32768, sizeof(MSGEDIT), &p, "MEW"); /* [M]essage [E]dit [W]indow (-: */

    for(f=0;f<100 && p.flag;f++)
       DosSleep(10);

    if(p.flag)
    {
       icqWriteSysLog(icq,PROJECT,"**** Timeout starting message-edit thread");
       DosSleep(1000);
    }
    return 0;
 }

 static void _System msgThread(ICQTHREAD *thd)
 {
    MSGEDIT             *m      = (MSGEDIT *) (thd+1);
    HMSG                msg     = ((struct parm *) thd->parm)->msg;
    char                *text   = ((struct parm *) thd->parm)->text;
    char                *url    = ((struct parm *) thd->parm)->url;

    if(text)
       text = strdup(text);

    if(url)
       url  = strdup(url);

    DBGTracex(text);
    DBGTracex(url);

    m->uin              = ((struct parm *) thd->parm)->uin;
    m->type             = ((struct parm *) thd->parm)->type;
    m->mgr              = ((struct parm *) thd->parm)->mgr;
    m->icq              = thd->icq;
    m->sz = sizeof(MSGEDIT);

    if(m->mgr)
       m->hasMgr = TRUE;

    ((struct parm *) thd->parm)->flag = FALSE;

    DBGMessage("Thread de edicao de mensagems iniciada");

    m->hab = WinInitialize(0);

    if(m->hab != NULLHANDLE)
    {
       if( (m->hmq = WinCreateMsgQueue(m->hab,0)) != NULLHANDLE)
       {
          if(createWindow(m) != NULLHANDLE)
          {
             /* Register callbacks */
             thd->event      = event;
             thd->stopthread = stopthread;

             m->usr          = icqQueryUserHandle(m->icq,m->uin);
             if(m->usr)
                m->usr->wndCounter++;

             /* Configure window */
             WinSendMsg(m->main,WM_USER+10,MPFROMP(m),MPFROMP(msg));

             CHKPoint();

             WinSendMsg(m->main,WM_USER+12,MPFROMP(text),MPFROMP(url));

             free(text);
             free(url);
             text = url = NULL;


             /* Process messages */
             while(WinGetMsg(m->hab,&m->qmsg,0,0,0))
                WinDispatchMsg(m->hab,&m->qmsg);

             m->usr          = icqQueryUserHandle(m->icq,m->uin);
             if(m->usr && m->usr->wndCounter)
                m->usr->wndCounter--;

          }
          WinDestroyMsgQueue(m->hmq);
       }
       WinTerminate(m->hab);
    }

    if(text)
       free(text);

    if(url)
       free(url);

    DBGMessage("Thread de edicao de mensagems terminada");
 }

 static void _System stopthread(ICQTHREAD *thd)
 {
    MSGEDIT *m    = (MSGEDIT *) (thd+1);
    DBGMessage("Parando janela de edicao de mensagems");
    WinPostMsg(m->main,WM_CLOSE,0,0);
 }

 static void _System event(ICQTHREAD *thd, ULONG uin, char id, USHORT event, ULONG parm)
 {
    MSGEDIT *m = (MSGEDIT *) (thd+1);

    if(id == 'S' || uin == m->uin)
       WinPostMsg(m->main,WMICQ_EVENT,MPFROMSH2CH(event, id, 0), (MPARAM) parm);

 }

 static HWND createWindow(MSGEDIT *ctl)
 {
    ULONG ulFrameFlags =         FCF_TITLEBAR
                                |FCF_SIZEBORDER
                                |FCF_MINMAX
                                |FCF_TASKLIST
                                |FCF_SYSMENU
                                |FCF_NOMOVEWITHOWNER
                                |FCF_ACCELTABLE;


    DBGTracex(ctl);

    ctl->frame = WinCreateStdWindow(    HWND_DESKTOP,
                                        0,
                                        &ulFrameFlags,
                                        (PSZ) msgClass,
                                        (PSZ) "pwICQ Message",
                                        WS_VISIBLE,
                                        (HMODULE) module,
                                        100,
                                        &ctl->main );


    ctl->sendTo = WinLoadMenu(ctl->main, module, ICQMSGM_SENDTO);

    return ctl->main;
 }

 MRESULT EXPENTRY messageEditor(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_USER+10:
       start(hwnd,PVOIDFROMMP(mp1),PVOIDFROMMP(mp2));
       break;

    case WM_USER+11:
       WinSetFocus(HWND_DESKTOP,WinWindowFromID(hwnd,ICQMSGC_TEXT));
       break;

    case WM_USER+12:    /* Configurar campos enviados mp1=text mp2=url */
       if(mp1)
          WinSetWindowText(WinWindowFromID(hwnd,ICQMSGC_TEXT),PVOIDFROMMP(mp1));
       if(mp2)
          WinSetWindowText(WinWindowFromID(hwnd,ICQMSGC_ENTRY),PVOIDFROMMP(mp2));
       break;

    case WMICQ_EVENT:
       chkEvent(hwnd,CHAR3FROMMP(mp1),SHORT1FROMMP(mp1),(ULONG) mp2);
       break;

    case WM_CREATE:
       create(hwnd,PVOIDFROMMP(mp2));
       return WinDefWindowProc(hwnd, msg, mp1, mp2);

    case WM_PAINT:
       paint(hwnd);
       break;

    case WM_SIZE:
       resize(hwnd, SHORT1FROMMP(mp2), SHORT2FROMMP(mp2));
       break;

    case WM_CLOSE:
       saveWindowPos(hwnd, WinQueryWindowPtr(hwnd,0));
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    case WM_DESTROY:
       destroy(hwnd,WinQueryWindowPtr(hwnd,0));
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    case WM_COMMAND:
       if(SHORT1FROMMP(mp2) == CMDSRC_MENU)
          menu(hwnd,SHORT1FROMMP(mp1));
       else
          action(hwnd,SHORT1FROMMP(mp1),SHORT1FROMMP(mp2));
       break;

   case WM_BUTTON1DBLCLK:
       dblClick(hwnd,WinQueryWindowPtr(hwnd,0));
       return WinDefWindowProc(hwnd, msg, mp1, mp2);

    default:
       return WinDefWindowProc(hwnd,msg,mp1,mp2);
    }

    return 0;
 }

 static void create(HWND hwnd, PCREATESTRUCT c)
 {
    static const USHORT entryFields[] = { ICQMSGC_NICKNAME,
                                          ICQMSGC_EMAIL,
                                          ICQMSGC_NAME,
                                          ICQMSGC_ENTRY,
                                          ICQMSGC_SUBJECT,
                                          0 };

    char                buffer[0x0100];
    const FIELDDESCR    *f;
    const USHORT        *field;
    HAB                 hab     = WinQueryAnchorBlock(hwnd);
    ULONG               bg      = CLR_PALEGRAY;

    for(f=fields;f->id;f++)
    {
       *buffer = 0;
       WinLoadString(hab, module, f->id, 0xFF, (PSZ) buffer);
       WinCreateWindow(hwnd, f->wndClass, buffer, f->style, 0,0,0,0, hwnd, HWND_BOTTOM, f->id, 0, 0);
    }
    WinSetPresParam(hwnd,PP_BACKGROUNDCOLORINDEX,sizeof(bg),&bg);
    WinSetPresParam(hwnd,PP_DISABLEDBACKGROUNDCOLORINDEX,sizeof(bg),&bg);

    WinSendDlgItemMsg(hwnd,ICQMSGC_TEXT,MLM_SETTEXTLIMIT,MPFROMLONG(MAX_MSG_SIZE), 0);

    for(field=entryFields;*field;field++)
       WinSendDlgItemMsg(hwnd, *field, EM_SETTEXTLIMIT, MPFROMSHORT(0xFF), 0);

 }

 static void paint(HWND hwnd)
 {
   RECTL        rcl;
   HPS          hps;

   hps = WinBeginPaint(hwnd,NULLHANDLE,&rcl);
   WinFillRect(hps, &rcl, CLR_PALEGRAY);
   WinEndPaint(hps);

 }

 static void saveWindowPos(HWND hwnd, MSGEDIT *ctl)
 {
    CHKPoint();
    if(ctl)
    {
       icqStoreWindow(ctl->frame, ctl->icq, ctl->uin,ctl->out ? "msgEdit" : "msgView");
       if(ctl->mgr && !ctl->out && ctl->usr && (ctl->mgr->flags & ICQMSGMF_LOADUSERFIELDS) )
          icqUpdateUserFlag(ctl->icq, ctl->usr, getCheckBox(hwnd, ICQMSGC_CHECKBOX), USRF_AUTOOPEN);
    }
 }

 static void start(HWND hwnd,MSGEDIT *ctl,HMSG msg)
 {
    char buffer[0x0100];

    DBGTracex(msg);

    /* Set fonts and colors before registering the controller to prevent double saving */
    icqLoadString(ctl->icq, "Font:MsgWin", "8.Helv", buffer, 0xFF);
    if(*buffer)
    {
       WinSetPresParam( hwnd,
                        PP_FONTNAMESIZE,
                        (ULONG) strlen(buffer)+1,
                        (PVOID) buffer);
    }

    icqLoadString(ctl->icq, "Font:MsgEdit", "8.Courier", buffer, 0xFF);
    if(*buffer)
    {
       WinSetPresParam( WinWindowFromID(hwnd,ICQMSGC_TEXT),
                        PP_FONTNAMESIZE,
                        (ULONG) strlen(buffer)+1,
                        (PVOID) buffer);
    }

    /* Configure fields */
    ctl->out = (msg == NULL);

    if(msg && (msg->msgFlags & MSGF_OUTPUT))
       ctl->out = TRUE;

    /* Register the controller */
    WinSetWindowPtr(hwnd,0,ctl);

    setMessage(hwnd, ctl->type, ctl->out, msg);

    CHKPoint();

    sizeControls(hwnd,ctl);

    CHKPoint();

    icqRestoreWindow(ctl->frame, ctl->icq, ctl->uin, ctl->out ? "msgEdit" : "msgView", 366, 250);

    CHKPoint();

 }

 static void sizeControls(HWND hwnd, MSGEDIT *ctl)
 {
    /* Ajusta tamanho dos controles */
    HPS                 hps;
    HWND                h;
    POINTL              aptl[TXTBOX_COUNT];
    const FIELDDESCR    *f;
    SWP                 swp;
    char                buffer[0x0100];

    for(f=fields;f->id;f++)
    {
       h = WinWindowFromID(hwnd,f->id);
       WinQueryWindowText(h,0xFF,buffer);

       hps = WinGetPS(h);

       GpiQueryTextBox(      hps,
                             strlen(buffer),
                             (char *) buffer,
                             TXTBOX_COUNT,
                             aptl);
       WinReleasePS(hps);

       WinQueryWindowPos(h,&swp);
       swp.cy = aptl[TXTBOX_TOPRIGHT].y - aptl[TXTBOX_BOTTOMRIGHT].y;

       if(f->id == ICQMSGC_CHECKBOX)
       {
          swp.cx  = aptl[TXTBOX_TOPRIGHT].x + 50;
          swp.cy += 10;
       }
       else if(f->wndClass == WC_BUTTON)
       {
          swp.cy  += 10;
       }
       else
       {
          swp.cx = aptl[TXTBOX_TOPRIGHT].x;
       }

       WinSetWindowPos(h,0,0,0,swp.cx,swp.cy,SWP_SIZE);

    }
 }

 static int getTextRows(HWND hwnd, int qtd, const USHORT *tbl)
 {
    /* Ajusta tamanho dos controles */
    HPS                 hps;
    HWND                h;
    POINTL              aptl[TXTBOX_COUNT];
    int                 f;
    char                buffer[0x0100];
    int                 ret                     = 0;
    int                 rows;

    for(f=0;f<qtd;f++)
    {
       h = WinWindowFromID(hwnd,*tbl);

       if(WinIsWindowVisible(h))
       {
          WinQueryWindowText(h,0xFF,buffer);

          hps = WinGetPS(h);

          GpiQueryTextBox(      hps,
                                strlen(buffer),
                                (char *) buffer,
                                TXTBOX_COUNT,
                                aptl);
          WinReleasePS(hps);
          rows = aptl[TXTBOX_TOPRIGHT].y - aptl[TXTBOX_BOTTOMRIGHT].y;
          ret  = max(ret,rows);
       }
       tbl++;
    }

    return ret;
 }

 static USHORT getMaxRow(HWND hwnd, int qtd, const USHORT *tbl)
 {
    USHORT      ret = 0;
    int         f;
    SWP         swp;
    HWND        h;

    for(f=0;f<qtd;f++)
    {
       h = WinWindowFromID(hwnd,*(tbl+f));
       if(WinIsWindowVisible(h))
       {
          WinQueryWindowPos(h,&swp);
          ret = max(ret,swp.cy);
       }
    }

    return ret;
 }

 static USHORT getMaxCol(HWND hwnd, int qtd, int step, const USHORT *tbl)
 {
    USHORT      ret = 0;
    int         f;
    SWP         swp;
    HWND        h;

    for(f=0;f<qtd;f+= step)
    {
       h = WinWindowFromID(hwnd,*(tbl+f));
       if(WinIsWindowVisible(h))
       {
          WinQueryWindowPos(h,&swp);
          ret = max(ret,swp.cx);
       }
    }

    return ret;
 }

 static USHORT showLine(HWND hwnd, USHORT row, USHORT center, USHORT c1, USHORT c2, USHORT rows, const USHORT *tbl)
 {
    int         f;
    USHORT      ret     = row;

    for(f=0;f<4 && !WinIsWindowVisible(WinWindowFromID(hwnd,*(tbl+f))); f++);

    if(f >= 4)
       return ret;

    ret -= rows;

    c1 += 12;
    c2 += 12;

    WinSetWindowPos(WinWindowFromID(hwnd,*tbl),0, 8,ret, 20,20, SWP_MOVE);

    tbl++;
    WinSetWindowPos(WinWindowFromID(hwnd,*tbl),0, c1, ret, center-(c1+8), rows, SWP_MOVE|SWP_SIZE);

    tbl++;
    WinSetWindowPos(WinWindowFromID(hwnd,*tbl),0, center,ret, 20,20, SWP_MOVE);

    tbl++;
    WinSetWindowPos(WinWindowFromID(hwnd,*tbl),0, center+c2, ret, center-(c2+8), rows, SWP_MOVE|SWP_SIZE);

    return ret;
 }

 static USHORT showButtons(HWND hwnd, USHORT pos, USHORT rows, int qtd, const USHORT *tbl)
 {
    HWND        h;
    SWP         swp;

    while(qtd--)
    {
       h = WinWindowFromID(hwnd,*tbl);

       if(WinIsWindowVisible(h))
       {
          WinQueryWindowPos(h,&swp);
          pos -= swp.cx;
          WinSetWindowPos(h,0, pos, 0, 20,20, SWP_MOVE);
       }

       tbl++;
    }

    return pos;

 }

 static USHORT showTopBox(HWND hwnd, USHORT pos, USHORT cols, const USHORT *tbl)
 {
    USHORT rows = getMaxRow(hwnd, 2, tbl);
    HWND   h;
    SWP    swp;
    USHORT col  = 8;

    pos -= 12;

    if(!rows)
       return pos;

    rows  = getMaxRow(hwnd,1,tbl);
    pos  -= rows;

    h = WinWindowFromID(hwnd,*tbl);
    if(WinIsWindowVisible(h))
    {
       WinQueryWindowPos(h,&swp);
       WinSetWindowPos(h,0, col, pos, 20,20, SWP_MOVE);
       col += swp.cx;
       col += 8;
    }

    tbl++;

    h = WinWindowFromID(hwnd,*tbl);
    if(WinIsWindowVisible(h))
       WinSetWindowPos(h,0, col, pos, cols-(col+6), rows, SWP_MOVE|SWP_SIZE);

    return pos-4;
 }

 static USHORT showBottomBox(HWND hwnd, USHORT pos, USHORT cols, const USHORT *tbl)
 {
    USHORT rows = getMaxRow(hwnd, 2, tbl);
    HWND   h;
    SWP    swp;
    USHORT col = cols;
    BOOL   button;

    if(!rows)
       return pos+4;

    h      = WinWindowFromID(hwnd,*tbl);
    button = WinIsWindowVisible(h);
    if(button)
    {
       pos += 2;
       WinQueryWindowPos(h,&swp);
       cols -= swp.cx;
       WinSetWindowPos(h,0, cols, pos, swp.cx, rows, SWP_MOVE|SWP_SIZE);
       cols -= 4;
       WinQueryWindowPos(WinWindowFromID(hwnd,ICQMSGC_STATICNICK),&swp);
    }
    else
    {
       pos  += 6;
       WinQueryWindowPos(WinWindowFromID(hwnd,ICQMSGC_STATICNICK),&swp);
       rows = swp.cy;
    }

    tbl++;

    h = WinWindowFromID(hwnd,*tbl);
    if(WinIsWindowVisible(h))
    {
       if(button)
       {
          WinSetWindowPos(h,0, 6,pos + ((rows - swp.cy)/2), cols-8, swp.cy, SWP_MOVE|SWP_SIZE);
       }
       else
       {
          WinSetWindowPos(h,0, 6,pos, cols-10, rows, SWP_MOVE|SWP_SIZE);
          pos += 2;
       }
    }

    return pos+rows+2;
 }

 static void showTextBox(HWND hwnd, USHORT bottom, USHORT top, USHORT cx)
 {
   WinSetWindowPos(WinWindowFromID(hwnd,ICQMSGC_TEXT),0, 4, bottom, cx-8, top-bottom, SWP_MOVE|SWP_SIZE);
 }

 static void resize(HWND hwnd, USHORT cx, USHORT cy)
 {
    /* Reposiciona toda a janela */
    USHORT              top      = cy;
    USHORT              bottom   = 0;
    USHORT              center   = cx >> 1;
    USHORT              rows;
    USHORT              c1;
    USHORT              c2;
    SWP                 swp;
    HWND                h;

    static const USHORT header[]  = {   ICQMSGC_STATICNICK,
                                        ICQMSGC_NICKNAME,
                                        ICQMSGC_STATICNAME,
                                        ICQMSGC_NAME,
                                        ICQMSGC_STATICUIN,
                                        ICQMSGC_UIN,
                                        ICQMSGC_STATICEMAIL,
                                        ICQMSGC_EMAIL
                                   };

    static const USHORT buttons[] = {   ICQMSGC_CLOSE,
                                        ICQMSGC_NEXT,
                                        ICQMSGC_REPLY,
                                        ICQMSGC_SENDTO,
                                        ICQMSGC_SEND,
                                        ICQMSGC_ACCEPT,
                                        ICQMSGC_REFUSE,
                                        ICQMSGC_REJECT,
                                        ICQMSGC_ADD,
                                        ICQMSGC_OPEN,

                                        ICQMSGC_CHECKBOX        /* Sempre o ultimo */
                                    };

    static const USHORT subject[] = {   ICQMSGC_STATICSUBJ,
                                        ICQMSGC_SUBJECT
                                    };

    static const USHORT urlBox[] =  {   ICQMSGC_BROWSE,
                                        ICQMSGC_ENTRY
                                    };


    sizeControls(hwnd, WinQueryWindowPtr(hwnd,0));

    /* Parte superior da tela */

    rows = getTextRows(hwnd, 8, header);

    if(rows)
    {
       /* Tem header */
       c1   = getMaxCol(hwnd, 4, 2, header);
       c2   = getMaxCol(hwnd, 4, 2, header+4);
       top = showLine(hwnd,top-12,center,c1,c2,rows,header);
       top = showLine(hwnd,top-8,center,c1,c2,rows,header+4);

       WinSetWindowPos(WinWindowFromID(hwnd,ICQMSGC_TOFROM),0, 0, top-8, cx, cy-(top-12), SWP_MOVE|SWP_SIZE);
       top -= 4;
    }

    /* Parte inferior da tela */
    rows = getMaxRow(hwnd, 9, buttons);
    if(rows)
    {
       /* Posiciona botoes */
       bottom += rows;
       c2  = showButtons(hwnd, cx, rows, 10, buttons);
       c2 -= 4;

       if(c2 > 4)
       {
          h  = WinWindowFromID(hwnd,ICQMSGC_CHECKBOX);
          WinQueryWindowPos(h,&swp);
          WinSetWindowPos(h,0, 0, 0, c2 < swp.cx ? c2 : swp.cx, rows, SWP_MOVE|SWP_SIZE);
       }
    }

    /* Campos extras na caixa de edicao */
    WinSetWindowPos(WinWindowFromID(hwnd,ICQMSGC_TEXTBOX),0, 0, bottom, cx, top-bottom, SWP_MOVE|SWP_SIZE);
    top    = showTopBox(hwnd,top,cx,subject);
    bottom = showBottomBox(hwnd,bottom,cx-2,urlBox);

    /* Area de texto */
    showTextBox(hwnd,bottom,top,cx);

 }

 static BOOL addNewUser(HWND hwnd, MSGEDIT *msg)
 {
    char        nickName[20];
    char        name[80];
    char        *lastName;

    CHKPoint();

    msg->usr    = icqQueryUserHandle(msg->icq,msg->uin);

    if(!msg->usr)
       return TRUE;

    if(!(msg->usr->flags & USRF_TEMPORARY) )
    {
       if(msg->usr->flags & USRF_WAITING)
       {
          setMessage(hwnd, MSG_REQUEST, TRUE, NULL);
          return FALSE;
       }
       return TRUE;
    }

    if(msg->usr->flags & USRF_AUTHORIZE)
    {
       setMessage(hwnd, MSG_REQUEST, TRUE, NULL);
       return FALSE;
    }

    WinQueryWindowText(WinWindowFromID(hwnd,ICQMSGC_NICKNAME),19,nickName);
    WinQueryWindowText(WinWindowFromID(hwnd,ICQMSGC_NAME),79,name);

    for(lastName = name;*lastName && !isspace(*lastName);lastName++);

    if(*lastName)
       *(lastName++) = 0;


    DBGTracex(msg);
    DBGTracex(msg->icq);
    DBGTracex(msg->uin);

    DBGMessage(nickName);
    DBGMessage(name);
    DBGMessage(lastName);

    icqAddNewUser(msg->icq, msg->uin, nickName, name, lastName, NULL, FALSE);

    CHKPoint();

    return FALSE;
 }

 static void action(HWND hwnd, USHORT id, USHORT type)
 {
    MSGEDIT *msg = WinQueryWindowPtr(hwnd,0);

    if( id < ICQMSGC_DOWN && !WinIsWindowVisible(WinWindowFromID(hwnd,id)))
       return;

    if(msg->mgr && msg->mgr->action)
    {
       if(msg->mgr->action(&msgHelper,hwnd,msg->icq,msg->uin,id))
          return;
    }

    DBGTrace(id);

    switch(id)
    {
    case ICQMSGC_CLOSE:
       if( (type == CMDSRC_PUSHBUTTON) || icqLoadValue(msg->icq,"ESC2Close",1))
          WinPostMsg(hwnd,WM_CLOSE,0,0);
       break;

    case ICQMSGC_NEXT:
       readNext(msg);
       break;

    case ICQMSGC_REPLY:
       if(msg->mgr)
          reply(hwnd, msg, msg->mgr->reply);
       else
          reply(hwnd, msg, MSG_NORMAL);
       break;

    case ICQMSGC_SEND:
       if(msg->mgr && msg->mgr->send)
       {
#ifdef EXTENDED_LOG
          icqWriteSysLog(msg->icq,PROJECT,"Sending message thru message manager");
#endif
          if(!msg->mgr->send(&msgHelper,hwnd,msg->icq,msg->uin))
             sendOk(hwnd,msg->icq,msg);
       }
       else
       {
          icqWriteSysLog(msg->icq,PROJECT,"No message manager or no sender block in message manager");
       }
       break;

    case ICQMSGC_ACCEPT:
       CHKPoint();
       if(msg->mgr && (msg->mgr->flags & ICQMSGMF_REQUESTMESSAGE))
       {
#ifdef EXTENDED_LOG
          icqWriteSysLog(msg->icq,PROJECT,"Request accepted");
#endif
          if(!icqAcceptRequest(msg->icq, msg->sequenceNumber, ""))
             WinPostMsg(hwnd,WM_CLOSE,0,0);
       }
       else
       {
          if(!icqSendMessage(msg->icq, msg->uin, MSG_AUTHORIZED, ""))
             sendOk(hwnd,msg->icq,msg);
       }
       break;

    case ICQMSGC_REJECT:
       CHKPoint();
       if(msg->mgr && (msg->mgr->flags & ICQMSGMF_REQUESTMESSAGE))
       {
#ifdef EXTENDED_LOG
          icqWriteSysLog(msg->icq,PROJECT,"Request refused");
#endif
          if(!icqRefuseRequest(msg->icq, msg->sequenceNumber, ""))
             WinPostMsg(hwnd,WM_CLOSE,0,0);

       }
       break;

    case ICQMSGC_BROWSE:
       selectFile(hwnd, msg->icq, ICQMSGC_ENTRY, FALSE, "msgbrw", "*.*", "Select File", "", NULL, NULL);
       break;

    case ICQMSGC_OPEN:
       openURL(hwnd,msg);
       break;

    case ICQMSGC_REFUSE:
       reply(hwnd, msg, MSG_REFUSED);
       break;

    case ICQMSGC_ADD:
       addNewUser(hwnd,msg);
       break;

    case ICQMSGC_DOWN:
       if(navigateWindow(WinQueryFocus(HWND_DESKTOP),QW_NEXT))
          navigateWindow(WinQueryWindow(hwnd,QW_TOP),QW_NEXT);
       break;

    case ICQMSGC_UP:
       if(navigateWindow(WinQueryFocus(HWND_DESKTOP),QW_PREV))
          WinSetFocus(HWND_DESKTOP,WinWindowFromID(hwnd,ICQMSGC_CLOSE));
       break;

    case ICQMSGC_SENDTO:
       if(msg->sendTo)
          WinPopupMenu(WinWindowFromID(hwnd,id), msg->main, msg->sendTo, 5, 5, 0, PU_HCONSTRAIN|PU_VCONSTRAIN|PU_KEYBOARD|PU_MOUSEBUTTON1 );
       break;

#ifdef DEBUG
    default:
       DBGPrint("Acao desconhecida: id=%d",id);
#endif

    }

 }

 static void ajustUser(MSGEDIT *wnd, HMSG msg)
 {
    char                buffer[0x0100];

    CHKPoint();

    wnd->usr    = icqQueryUserHandle(wnd->icq,wnd->uin);

    DBGTracex(wnd->usr);

    wnd->sysMsg = (wnd->usr == NULL);

    WinEnableWindow(WinWindowFromID(wnd->main,ICQMSGC_NEXT),icqQueryMessage(wnd->icq,wnd->sysMsg ? 0 : wnd->uin) != NULL);

    *buffer = 0;

    DBGTracex(wnd->mgr);
    DBGTracex(wnd->mgr->title);

    if(wnd->mgr && wnd->mgr->title)
    {
       wnd->mgr->title(wnd->icq, wnd->usr, wnd->uin, wnd->out, msg, buffer, 0xFF);
    }
    else
    {
       sprintf(buffer,"Message %04x %s %s (ICQ#%lu)",
                                        wnd->type,
                                        wnd->out ? "to" : "from",
                                        icqQueryUserNick(wnd->usr),
                                        wnd->uin );
    }

    if(*buffer)
       WinSetWindowText(wnd->frame, (PSZ) buffer);

    if(wnd->mgr && (wnd->mgr->flags & ICQMSGMF_LOADUSERFIELDS))
       loadUserFields(wnd->main);

    CHKPoint();
 }

 static int _System insertSndMenu(HWND hwnd, USHORT dunno, const char *text, SENDTOCALLBACK *callback)
 {
    MENUITEM    itn;
    MSGEDIT     *wnd            = WinQueryWindowPtr(hwnd,0);

    itn.iPosition       = MIT_END;              /*  Position. */
    itn.afStyle         = MIS_TEXT;             /*  Style. */
    itn.afAttribute     = 0;                    /*  Attribute. */
    itn.id              = wnd->lastMenu++;      /*  Identity. */
    itn.hwndSubMenu     = NULLHANDLE;           /*  Submenu. */
    itn.hItem           = (ULONG) callback;     /*  Item. */

    DBGMessage(text);
    DBGTrace(itn.id);

    WinSendMsg(wnd->sendTo,MM_INSERTITEM,MPFROMP(&itn),MPFROMP(text));

    return 0;

 }

#ifdef DEBUG

 static int _System testMenu(HICQ icq, ULONG uin, const MSGMGR *mgr, const char *text, const char *url)
 {
    DBGMessage("Teste de menu");
    return 0;
 }

#endif

 static int _System setMessage(MSGEDITWINDOW hwnd, USHORT type, BOOL out, HMSG msg)
 {
    MSGEDIT             *wnd            = WinQueryWindowPtr(hwnd,0);
    MSGFORMATTER        *formatter      = NULL;
    SWP                 swp;
    BOOL		        flag;

    if(wnd->mgr)
    {
       if(wnd->mgr->exit)
          wnd->mgr->exit(&msgHelper,hwnd,wnd->icq,wnd->uin,wnd->type,type);

       saveWindowPos(hwnd, wnd);
    }

    WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_SEND),FALSE);

    wnd->type = type;
    wnd->out  = out;

    if(msg)
    {
       DBGTracex(msg->mgr);
       wnd->mgr            = msg->mgr;
       wnd->sequenceNumber = msg->sequenceNumber;
    }
    else
    {
       if(!wnd->hasMgr)
          wnd->mgr = icqQueryMessageManager(wnd->icq,wnd->type);
       else
          wnd->hasMgr = FALSE;

       wnd->sequenceNumber = 0;
    }

    if(wnd->mgr)
       formatter = wnd->mgr->formatWindow;

    if(!formatter)
       formatter = unknownMsgFormatter;

    if(wnd->icon)
    {
       WinDestroyPointer(wnd->icon);
       wnd->icon = 0;
    }

    if(wnd->mgr)
    {
       wnd->icon = icqCreatePointer(wnd->icq, wnd->mgr->icon[0]);
       WinSendMsg(wnd->frame,WM_SETICON,MPFROMP(wnd->icon),0);
    }

    WinSendMsg(WinWindowFromID(hwnd,ICQMSGC_TEXT),MLM_SETREADONLY,MPFROMSHORT(msg!=NULL),0);

    ajustUser(wnd,msg);

    CHKPoint();

    if(formatter)
       formatter(&msgHelper,hwnd,wnd->icq,wnd->uin,type,out,msg);

    CHKPoint();

    if(msg)
       icqRemoveMessage(wnd->icq,wnd->uin,msg);

    CHKPoint();

    if(wnd->mgr)
    {
       WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_REPLY),wnd->mgr->reply != 0xFFFF);
       flag = (wnd->sequenceNumber || !(wnd->mgr->flags&ICQMSGMF_REQUESTMESSAGE));
    }
    else
    {
       WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_REPLY),TRUE);
       flag = FALSE;
    }

    DBGTracex(flag);
    WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_ACCEPT),flag);
    WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_REJECT),flag);
    CHKPoint();

    WinQueryWindowPos(wnd->main,&swp);

    if(wnd->sendTo)
    {
       WinDestroyWindow(wnd->sendTo);
       wnd->sendTo = WinLoadMenu(wnd->main, module, ICQMSGM_SENDTO);
    }

    if(wnd->mgr && wnd->mgr->send && !(wnd->mgr->flags & ICQMSGMF_DISABLESEND))
       WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_SEND),TRUE);

    DBGTracex(type);
    DBGTracex(wnd->type);

#ifdef DEBUG
    if(msg)
       DBGTracex(msg->type);

    insertSndMenu(hwnd, 1, "T1", testMenu);
    insertSndMenu(hwnd, 1, "T2", testMenu);
#endif

//    if(WinIsWindowEnabled(WinWindowFromID(hwnd,ICQMSGC_ENTRY)) && wnd->mgr && (wnd->mgr->flags & ICQMSGMF_SENDTO) )

    if(WinIsWindowVisible(WinWindowFromID(hwnd,ICQMSGC_ENTRY)) && wnd->mgr && (wnd->mgr->flags & ICQMSGMF_SENDTO) )
    {
       icqInsertSendToOptions(wnd->icq, hwnd, type, out, wnd->mgr, &insertSndMenu);
       setVisible(hwnd, ICQMSGC_SENDTO, WinSendMsg(wnd->sendTo,MM_QUERYITEMCOUNT,0,0) != 0);
    }
    else
    {
       setVisible(hwnd,ICQMSGC_SENDTO,FALSE);
    }

    resize(wnd->main,swp.cx,swp.cy);

    if(out)
       WinPostMsg(hwnd,WM_USER+11,0,0);

    CHKPoint();

    return 0;
 }

 static int _System loadUserFields(MSGEDITWINDOW hwnd)
 {
    MSGEDIT     *wnd = WinQueryWindowPtr(hwnd,0);
    HWND        h;
    char        buffer[0x0100];

    DBGTrace(wnd->uin);
    wnd->usr = icqQueryUserHandle(wnd->icq,wnd->uin);

    if(!wnd->usr)
       wnd->usr = icqAddUserInCache(wnd->icq, wnd->uin);

    sprintf(buffer,"%lu",wnd->uin);
    SETTEXT(hwnd,ICQMSGC_UIN,buffer);

    strncpy(buffer,icqQueryUserFirstName(wnd->usr),0xFF);
    strncat(buffer," ",0xFF);
    strncat(buffer,icqQueryUserLastName(wnd->usr),0xFF);
    SETTEXT(hwnd,ICQMSGC_NAME,buffer);

    SETTEXT(hwnd,ICQMSGC_NICKNAME,icqQueryUserNick(wnd->usr));

    if(wnd->out)
       SETTEXT(hwnd,ICQMSGC_EMAIL,icqQueryUserEmail(wnd->usr));

    WinLoadString(WinQueryAnchorBlock(hwnd), module, wnd->out ? ICQMSGS_URGENT: ICQMSGS_AUTOOPEN, 0xFF, (PSZ) buffer);
    SETTEXT(hwnd,ICQMSGC_CHECKBOX,buffer);

    if(wnd->out || !wnd->usr)
    {
       WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_CHECKBOX),FALSE);
       WinSendDlgItemMsg(hwnd,ICQMSGC_CHECKBOX,BM_SETCHECK,0,0);
    }
    else
    {
       if(wnd->usr->flags & USRF_AUTOOPEN)
          WinSendDlgItemMsg(hwnd,ICQMSGC_CHECKBOX,BM_SETCHECK,MPFROMSHORT(TRUE),0);
       else
          WinSendDlgItemMsg(hwnd,ICQMSGC_CHECKBOX,BM_SETCHECK,MPFROMSHORT(FALSE),0);
    }

    DBGTracex(wnd->usr);

    if(!wnd->usr)
       return 0;

    h = WinWindowFromID(wnd->main,ICQMSGC_ADD);
    if(wnd->usr)
    {
       WinLoadString(   WinQueryAnchorBlock(h),
                        module,
                        (wnd->usr->flags & (USRF_AUTHORIZE|USRF_WAITING)) ? ICQMSGS_AUTHORIZE : ICQMSGS_ADD,
                        40,
                        (PSZ) buffer);

       WinSetWindowText(h,buffer);
       DBGTracex(wnd->usr->flags & (USRF_TEMPORARY|USRF_WAITING));
       WinEnableWindow(h,(wnd->usr->flags & (USRF_TEMPORARY|USRF_WAITING)));
    }
    else
    {
       WinShowWindow(h,FALSE);
    }

    CHKPoint();

    return 0;
 }

 static int _System setTitle(MSGEDITWINDOW hwnd, const char *title)
 {
    MSGEDIT             *wnd            = WinQueryWindowPtr(hwnd,0);
    WinSetWindowText(wnd->frame, (PSZ) title);
    return 0;
 }

 static void chkEvent(HWND hwnd, UCHAR id, USHORT event, ULONG parm)
 {
    MSGEDIT *wnd = WinQueryWindowPtr(hwnd,0);

    switch(id)
    {
    case 'S':   /* System event */
       switch(event)
       {
       case ICQEVENT_STOPPING:
          WinPostMsg(hwnd,WM_CLOSE,0,0);
          break;

       case ICQEVENT_MESSAGECHANGED:
          if(wnd->sysMsg)
             WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_NEXT),icqQueryMessage(wnd->icq,0) != NULL);
       }
       break;

    case 'U':   /* User event */
       switch(event)
       {
       case ICQEVENT_MESSAGECHANGED:
          WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_NEXT),icqQueryMessage(wnd->icq,wnd->uin) != NULL);
          break;

       case ICQEVENT_UPDATED:
          CHKPoint();
          ajustUser(wnd,NULL);
          break;

       case ICQEVENT_REQDELETED:
       case ICQEVENT_REQACCEPTED:
       case ICQEVENT_REQREFUSED:

          DBGTrace(parm);
          DBGTrace(wnd->sequenceNumber);

          if(parm && parm == wnd->sequenceNumber)
          {
             WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_REJECT),FALSE);
             WinEnableWindow(WinWindowFromID(hwnd,ICQMSGC_ACCEPT),FALSE);
          }
          break;

       }
       break;
    }

    if(wnd->mgr && wnd->mgr->event)
       wnd->mgr->event(&msgHelper,hwnd,wnd->icq,wnd->uin,id,event,parm);

 }

 static void _System loadString(MSGEDITWINDOW hwnd, USHORT id, USHORT str)
 {
    char buffer[40];

    WinLoadString(WinQueryAnchorBlock(hwnd), module, str, 39, (PSZ) buffer);
    WinSetWindowText(WinWindowFromID(hwnd,id),buffer);
 }

 static void _System showTime(MSGEDITWINDOW hwnd, USHORT id, time_t tm)
 {
    char buffer[80];
    char key[20];

    WinLoadString(WinQueryAnchorBlock(hwnd), module, 1200, 19, key);
    strftime(buffer,79,key,localtime(&tm));
    WinSetWindowText(WinWindowFromID(hwnd,id),buffer);
 }

 static void _System setReply(MSGEDITWINDOW hwnd, USHORT type)
 {
    reply(hwnd, WinQueryWindowPtr(hwnd,0), type);
 }

 static void reply(HWND hwnd, MSGEDIT *ctl, USHORT type)
 {

    HWND        h       = WinWindowFromID(hwnd,ICQMSGC_TEXT);
    char        *text   = NULL;
//    ULONG       sz      = LONGFROMMR(WinSendMsg(h,MLM_QUERYTEXTLENGTH,0,0));
    ULONG       bytes;

    if(type == 0xFFFF)
       return;

    text = malloc(MAX_MSG_SIZE+10);
    if(!text)
    {
       icqWriteSysLog(ctl->icq,PROJECT,"Memory allocation error when formatting reply string");
       return;
    }

    DBGMessage("Formatar Reply");

    WinSetDlgItemText(hwnd,ICQMSGC_ENTRY,"");

    switch(icqLoadValue(ctl->icq, "Quote", 1))
    {
    case 1:     /* Quota o bloco marcado */
       *text = 0;
       bytes = LONGFROMMR(WinSendMsg(h,MLM_QUERYSELTEXT,MPFROMP(text),0));

       DBGTrace(bytes);
       DBGMessage(text);

       if(bytes > 2)
       {
          *(text+bytes) = 0;
          WinSetWindowText(h,text);
          ajustQuote(h,MAX_MSG_SIZE,text);
       }
       else
       {
          *text = 0;
       }
       break;

    case 2:     /* Quota tudo */
       *text = 0;
       ajustQuote(h,MAX_MSG_SIZE,text);
       break;

    default:
       *text = 0;

    }

    CHKPoint();
    setMessage(hwnd, type, TRUE, NULL);

    DBGTracex(text);
    DBGMessage(text);

    WinSetWindowText(h,text);

    WinPostMsg(hwnd,WM_USER+11,0,0);

    CHKPoint();

    free(text);

 }

 static void ajustQuote(HWND h, ULONG sz, char *buffer)
 {
     ULONG   lins;
     ULONG   pos        = 0;
     char    *ptr;
     ULONG   f;
     IPT     p;
     IPT     s;

     lins  = (ULONG) WinSendMsg(h,MLM_QUERYLINECOUNT,0,0);

     for(f=0;f<lins && pos <= sz;f++)
     {
        *(buffer+(pos++)) = '>';
        p = (IPT) WinSendMsg(h,MLM_CHARFROMLINE,MPFROMLONG(f),0);
        s = (IPT) WinSendMsg(h,MLM_QUERYLINELENGTH,(MPARAM) p, 0);

        DBGTrace(s+pos);
        DBGTrace(sz);

        if( (s+pos) < sz )
        {
           ptr  = buffer+pos;
           pos += s;
           if(WinSendMsg(h,MLM_SETIMPORTEXPORT,MPFROMP(ptr), MPFROMLONG(s) ))
              WinSendMsg(h,MLM_EXPORT,MPFROMP(&p), MPFROMP(&s));
           *(buffer+(pos++)) = '\n';
        }
     }
     *(buffer+pos) = 0;

#ifdef EXTENDED_LOG
     if(pos > sz)
        icqWriteSysLog(NULL,PROJECT,"Buffer overflow on quote formatting");
#endif

     DBGMessage(buffer);

 }

 static BOOL navigateWindow(HWND focus, LONG dir)
 {
   HWND next  = WinQueryWindow(focus,dir);

   while(next && next != focus)
   {
      if( WinIsWindowEnabled(next) && WinIsWindowVisible(next) && (WinQueryWindowULong(next,QWL_STYLE) & WS_TABSTOP))
      {
         WinSetFocus(HWND_DESKTOP,next);
         return FALSE;
      }
      next = WinQueryWindow(next,dir);
   }
   return TRUE;
 }

 static BOOL readNext(MSGEDIT *wnd)
 {
    HMSG msg = icqQueryMessage(wnd->icq,wnd->sysMsg ? 0 : wnd->uin);

    if(msg)
    {
       CHKPoint();
       setMessage(wnd->main, msg->type, FALSE, msg);
       CHKPoint();
       return FALSE;
    }
    return TRUE;
 }

 static void dblClick(HWND hwnd,MSGEDIT *ctl)
 {
    char   *ptr;
    HWND   h;
    ULONG  sz;
    SWP    swp;

    if(ctl->out && ctl->mgr && (ctl->mgr->flags & ICQMSGMF_URLCOMPATIBLE) )
    {
       WinQueryWindowPos(ctl->main,&swp);
       setVisible(hwnd,ICQMSGC_ENTRY,!getVisible(hwnd, ICQMSGC_ENTRY));
       resize(ctl->main,swp.cx,swp.cy);
    }
    else if(ctl->out)
    {
       h   = WinWindowFromID(hwnd,ICQMSGC_TEXT);
       sz  = LONGFROMMR(WinSendMsg(h,MLM_QUERYTEXTLENGTH,0,0));
       sz += 10;

       ptr = malloc(sz);

       if(ptr)
       {
          WinQueryWindowText(h,sz,ptr);
          setMessage(hwnd, ctl->type == MSG_NORMAL ? MSG_URL : MSG_NORMAL, TRUE, NULL);
          CHKPoint();
          WinSetWindowText(h,ptr);
          CHKPoint();
          free(ptr);
       }
       else
       {
          CHKPoint();
          setMessage(hwnd, ctl->type == MSG_NORMAL ? MSG_URL : MSG_NORMAL, TRUE, NULL);
          CHKPoint();
       }
    }
    else
    {
       reply(hwnd, ctl, MSG_NORMAL);
    }
 }

 static void sendOk(HWND hwnd, HICQ icq, MSGEDIT *msg)
 {
    if(icqLoadValue(icq,"NextOnSend",1))
    {
       if(readNext(msg))
          WinPostMsg(hwnd,WM_CLOSE,0,0);
    }
    else
    {
       WinPostMsg(hwnd,WM_CLOSE,0,0);
    }
 }

 static void openURL(HWND hwnd, MSGEDIT *ctl)
 {
    char buffer[0x0100];

    *buffer = 0;
    WinQueryWindowText(WinWindowFromID(hwnd,ICQMSGC_ENTRY),0xFF,buffer);

    if(*buffer)
       icqOpenURL(ctl->icq,buffer);

 }


 static char *queryText(HWND hwnd, USHORT id)
 {
    int  sz;
    char *ret;

    hwnd = WinWindowFromID(hwnd,id);

    sz = WinQueryWindowTextLength(hwnd);

    ret = malloc(sz+5);

    if(ret)
       WinQueryWindowText(hwnd,sz+2,ret);

    return ret;

 }
 static void menu(HWND hwnd, USHORT id)
 {
    MSGEDIT             *wnd            = WinQueryWindowPtr(hwnd,0);
    MENUITEM            itn;
    char                *text           = NULL;
    char                *url            = NULL;

    DBGTracex(id);

    WinSendMsg(wnd->sendTo,MM_QUERYITEM,MPFROM2SHORT(id,FALSE),MPFROMP(&itn));

    DBGTracex(itn.iPosition);
    DBGTracex(itn.afStyle);
    DBGTracex(itn.afAttribute);
    DBGTracex(itn.id);
    DBGTracex(itn.hwndSubMenu);
    DBGTracex(itn.hItem);

//   typedef int (_System SENDTOCALLBACK)(HICQ, ULONG, const MSGMGR *, const char *, const char *);

    if(itn.hItem)
    {
       text = queryText(hwnd,ICQMSGC_TEXT);
       url  = queryText(hwnd,ICQMSGC_ENTRY);

       DBGMessage(text);
       DBGMessage(url);

       ((SENDTOCALLBACK *) itn.hItem)(wnd->icq,wnd->uin,wnd->mgr,text,url);
    }

    if(text)
       free(text);

    if(url)
       free(url);

 }

 static void destroy(HWND hwnd, MSGEDIT *wnd)
 {
    if(wnd->icon)
    {
       WinDestroyPointer(wnd->icon);
       wnd->icon = 0;
    }
 }

 static int  _System setEnabled(hWindow hwnd, USHORT id, BOOL flag)
 {
    return 0;
 }

 static void _System setEditable(hWindow hwnd, USHORT id, BOOL flag)
 {

 }

 static int  _System queryClipboard(HICQ icq, int sz, char *buffer)
 {
    HAB  hab   = icqQueryAnchorBlock(icq);
    char *ptr;

    *buffer = 0;

    if(!WinOpenClipbrd(hab))
       return -1;

    ptr = (char *) WinQueryClipbrdData(hab , CF_TEXT);

    if(ptr)
    {
       strncpy(buffer,ptr,sz);
       *(buffer+sz) = '0';
    }

    WinCloseClipbrd(hab);

    return strlen(buffer);
 }

 static int _System getVisible(hWindow hwnd, USHORT id)
 {
    return (int) WinIsWindowVisible(WinWindowFromID(hwnd,id));
 }

 static void _System setIcon(hWindow hwnd, USHORT id, USHORT icon)
 {

 }


