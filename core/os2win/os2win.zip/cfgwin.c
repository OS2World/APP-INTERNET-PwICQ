/*
 * CFGWIN.C - Dialogo de configuracao padrao
 */

// #pragma strings(readonly)

 #define INCL_WIN
 #define INCL_DOSPROCESS
 #define INCL_GPI

 #include <stdio.h>
 #include <string.h>

 #include <pwMacros.h>
 #include <os2win.h>

 #include "wintlkt.h"

/*---[ Estruturas ]-----------------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct page
 {
    HWND        dialog;
    BOOL        flags;
    #define DLG_SELECTED        0x00000001

    USHORT      id;
 } PAGE;

 typedef struct cfgdlg
 {
    USHORT              sz;

    HICQ                icq;
    USHORT              type;

    HAB                 hab;
    HMQ                 hmq;
    QMSG                qmsg;

    HWND                hwnd;
    HWND                frame;

    HWND                bg;

    HWND                dialog;

    ULONG               uin;

    char                buffer[0x0100];
    char                string[0x0100];

    HPOINTER            icon;

    PAGELOADER          *load;

    RECORDINSERT        r;

 } CFGDLG;

 struct parm
 {
    BOOL        flag;
    USHORT      type;
    ULONG       uin;
    PAGELOADER  *load;
 };

/*---[ Prototipos ]-----------------------------------------------------------------------------------*/

 MRESULT EXPENTRY configDialog(HWND, ULONG, MPARAM, MPARAM);
 MRESULT EXPENTRY aboutDialog(HWND, ULONG, MPARAM, MPARAM);


 static void _System cfgThread(ICQTHREAD *);
 static void _System ldlThread(ICQTHREAD *);

 static void _System stopthread(ICQTHREAD *);
 static void _System event(ICQTHREAD *, ULONG, char, USHORT, ULONG);


 static void            create(HWND, PCREATESTRUCT);
 static void            configure(HWND, CFGDLG *);
 static void            destroy(HWND);
 static void            paint(HWND);
 static HWND            createWindow(CFGDLG *);
 static int             insertPage(HWND, RECORDCORE *, USHORT, HWND, const char *);
 static void            selectDialog(HWND);
 static void            broadcast(HWND, ULONG, MPARAM, MPARAM);
 static void            save(CFGDLG *,HWND);
 static void            showDialog(HWND, HWND, ULONG);
 static void            resize(HWND, USHORT, USHORT);
 static RECORDCORE      *findNode(HWND, USHORT);
 static HWND            ajustDialogParameters(HWND,HICQ);


 static int  _System insertDialog(HWND,HMODULE,USHORT,const DLGMGR *,USHORT);
 static HWND _System loadDialog(HWND, HICQ, ULONG, HMODULE, USHORT, const DLGMGR *);
 static int  _System addPage(HWND, USHORT, HWND, const char *);
 static HWND _System ajustDlg(HWND,HWND);

/*---[ Constants ]----------------------------------------------------------------------------------*/

 static const char      *cfgClass       = "pwICQConfigDialog";

 static const DLGINSERT dlgInsert       = {     sizeof(DLGINSERT),
                                                insertDialog,
                                                loadDialog,
                                                addPage,
                                                ajustDlg
                                          };

 static const DLGHELPER dlgHelper = {  sizeof(DLGHELPER),
                                       setString,
                                       getString,

                                       setCheckBox,
                                       getCheckBox,

                                       setRadioButton,
                                       getRadioButton,

                                       getLength,
                                       enableControl,
                                       setTextLimit,

                                       listBoxInsert,
                                       listBoxQuery,

                                       NULL,
                                       NULL,

                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,

                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL

                                 };


/*---[ Implementacao ]--------------------------------------------------------------------------------*/


 APIRET EXPENTRY icqRegisterConfigurationWindow(HICQ icq, HAB hab)
 {
    return WinRegisterClass(hab,(PSZ) cfgClass, configDialog, CS_SIZEREDRAW, sizeof(PVOID));
 }

 APIRET EXPENTRY icqOpenDefaultConfigurationWindow(HICQ icq, ULONG uin, USHORT type, PAGELOADER *load)
 {
    struct parm p;
    int         f;

    p.flag      = TRUE;
    p.type      = type;
    p.uin       = uin;
    p.load      = load;

    icqCreateThread(icq, &cfgThread, 32768, sizeof(CFGDLG), &p, "CEW"); /* [C]onfig [E]dit [W]indow (-: */

    for(f=0;f<100 && p.flag;f++)
       DosSleep(10);

    if(p.flag)
    {
       icqWriteSysLog(icq,PROJECT,"**** Timeout starting configuration editor thread");
       DosSleep(1000);
    }
    return 0;
 }

 void _System cfgThread(ICQTHREAD *thd)
 {
    CFGDLG             *cfg     = (CFGDLG *) (thd+1);

    cfg->sz   = sizeof(CFGDLG);
    cfg->type = ((struct parm *) thd->parm)->type;
    cfg->uin  = ((struct parm *) thd->parm)->uin;
    cfg->load = ((struct parm *) thd->parm)->load;
    cfg->icq  = thd->icq;

    ((struct parm *) thd->parm)->flag = FALSE;

    DBGMessage("Thread de edicao de configuracao iniciada");

    cfg->hab = WinInitialize(0);

    if(cfg->hab != NULLHANDLE)
    {
       if( (cfg->hmq = WinCreateMsgQueue(cfg->hab,0)) != NULLHANDLE)
       {
          if(createWindow(cfg) != NULLHANDLE)
          {
             // Register callbacks
             thd->event         = event;
             thd->stopthread    = stopthread;

             icqCreateThread(thd->icq, &ldlThread, 32768, 0, cfg, "CEL"); /* [C]onfig [E]dit [L]oad (-: */

             // Process messages
             while(WinGetMsg(cfg->hab,&cfg->qmsg,0,0,0))
                WinDispatchMsg(cfg->hab,&cfg->qmsg);

          }

          if(cfg->icon)
             WinDestroyPointer(cfg->icon);

          WinDestroyMsgQueue(cfg->hmq);
       }

       WinTerminate(cfg->hab);
    }

    DBGMessage("Thread de edicao de configuracao terminada");

 }

 void _System stopthread(ICQTHREAD *t)
 {
    CFGDLG *cfg     = (CFGDLG *) (t+1);

    CHKPoint();

    if(cfg->hwnd)
       WinPostMsg(cfg->hwnd,WM_CLOSE,0,0);
 }

 void _System event(ICQTHREAD *t, ULONG uin, char id, USHORT event, ULONG parm)
 {
    CFGDLG *cfg = (CFGDLG *) (t+1);

    if(id != 'U' || uin == cfg->uin)
       WinPostMsg(cfg->hwnd,WMICQ_EVENT,MPFROMSH2CH(event, id, 0), (MPARAM) parm);

    if(id == 'S' && event == ICQEVENT_STOPPING && cfg->hwnd)
    {
       DBGMessage("ICQEVENT_STOPPING");
       WinPostMsg(cfg->hwnd,WM_CLOSE,0,0);
    }


 }

 static HWND createWindow(CFGDLG *ctl)
 {
    ULONG ulFrameFlags =         FCF_TITLEBAR
                                |FCF_SIZEBORDER
                                |FCF_TASKLIST
                                |FCF_SYSMENU
                                |FCF_NOMOVEWITHOWNER;

//                                |FCF_ACCELTABLE;
//                                |FCF_SIZEBORDER
//                                |FCF_DLGBORDER
//                                |FCF_MINMAX

#ifdef DEBUG
    ulFrameFlags |= FCF_SIZEBORDER;
#endif

    DBGTracex(ctl);

    ctl->frame = WinCreateStdWindow(    HWND_DESKTOP,
                                        0,
                                        &ulFrameFlags,
                                        (PSZ) cfgClass,
                                        (PSZ) "pwICQ Configuration",
                                        WS_VISIBLE,
                                        (HMODULE) module,
                                        100,
                                        &ctl->hwnd );



    DBGTracex(ctl->hwnd);
    DBGTracex(WinWindowFromID(ctl->frame,FID_CLIENT));

    return ctl->hwnd;
 }


 MRESULT EXPENTRY configDialog(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_CLOSE:
       DBGMessage("WM_CLOSE");
       save(WinQueryWindowPtr(hwnd,0),WinWindowFromID(hwnd,1000));
       return WinDefWindowProc(hwnd, msg, mp1, mp2);

    case WM_USER+10:
       configure(hwnd, PVOIDFROMMP(mp1));
       break;

    case WMICQ_EVENT:  /* Event - MP1 = EVENT, MP2=PARM */
//       DBGTracex(SHORT1FROMMP(mp1));
//       DBGTracex(CHAR3FROMMP(mp1));
       broadcast(WinWindowFromID(hwnd,1000),msg,mp1,mp2);
       break;

    case WM_CONTROL:
       if( (SHORT1FROMMP(mp1) != 1000) || (SHORT2FROMMP(mp1) != CN_EMPHASIS) )
          return WinDefWindowProc(hwnd, msg, mp1, mp2);
       selectDialog(hwnd);
       break;


    case WM_SIZE:
       resize(hwnd,SHORT1FROMMP(mp2),SHORT2FROMMP(mp2));
       break;

    case WM_PAINT:
       paint(hwnd);
       break;

    case WM_CREATE:
       create(hwnd,PVOIDFROMMP(mp2));
       return WinDefWindowProc(hwnd, msg, mp1, mp2);

    case WM_DESTROY:
       destroy(hwnd);
       return WinDefWindowProc(hwnd, msg, mp1, mp2);

    default:
       return WinDefWindowProc(hwnd, msg, mp1, mp2);
    }

    return 0;

 }

 static void resize(HWND hwnd, USHORT cx, USHORT cy)
 {
    CFGDLG *cfg = WinQueryWindowPtr(hwnd,0);

    WinSetWindowPos(WinWindowFromID(hwnd,1000),0,2,2,119,cy-8,SWP_SIZE);
    WinSetWindowPos(WinWindowFromID(hwnd,1001),0,125,cy-21,cx-127,16,SWP_SIZE|SWP_MOVE);
    WinSetWindowPos(WinWindowFromID(hwnd,1002),0,125,2,cx-127,cy-28,SWP_SIZE|SWP_MOVE);

    if(cfg)
       showDialog(hwnd,cfg->dialog,CLR_PALEGRAY);
 }

 static void create(HWND hwnd, PCREATESTRUCT cr)
 {
    HWND                h;
    ULONG               clr;
    HAB                 hab             = WinQueryAnchorBlock(hwnd);
    char                buffer[0x0100];
    CNRINFO             cnrinfo;

    WinLoadString(hab, module, 1300, 0xFF, buffer);
    WinSetPresParam( hwnd,PP_FONTNAMESIZE,(ULONG) strlen(buffer)+1,(PVOID) buffer);

    h = WinCreateWindow(        hwnd,
                                WC_CONTAINER,
                                "",
                                WS_VISIBLE|WS_TABSTOP|CCS_READONLY, // |CCS_AUTOPOSITION
                                2,2,
                                119,428,
                                hwnd,
                                HWND_TOP,
                                1000,
                                NULL,
                                NULL );

    clr = CLR_WHITE;
    WinSetPresParam(h,PP_BACKGROUNDCOLORINDEX,sizeof(clr),&clr);
    clr = CLR_BLACK;
    WinSetPresParam(h,PP_FOREGROUNDCOLORINDEX,sizeof(clr),&clr);

    WinLoadString(hab, module, 1302, 0xFF, buffer);
    WinSetPresParam( h,PP_FONTNAMESIZE,(ULONG) strlen(buffer)+1,(PVOID) buffer);

    cnrinfo.cb            = sizeof( CNRINFO );
    cnrinfo.flWindowAttr  = CV_TREE|CV_TEXT|CA_TREELINE; // |CA_CONTAINERTITLE; // |CA_TITLESEPARATOR;
    cnrinfo.cxTreeIndent  = 1;
    cnrinfo.cxTreeLine    = -1;
    cnrinfo.pszCnrTitle   = "";

    WinSendMsg(h, CM_SETCNRINFO, MPFROMP( &cnrinfo ),MPFROMLONG(CMA_FLWINDOWATTR|CMA_CXTREEINDENT)); //); |CMA_CNRTITLE)); // |CMA_LINESPACING));

    h = WinCreateWindow(        hwnd,
                                WC_FRAME,
                                "",
                                WS_VISIBLE|FS_NOMOVEWITHOWNER|FS_NOBYTEALIGN,
                                125,2,
                                495,410,
                                hwnd,
                                HWND_TOP,
                                1002,
                                NULL,
                                NULL );

    /* Cria a barra de titulo por ultimo pois o tipo de letra e diferente */

    h = WinCreateWindow(        hwnd,
                                WC_STATIC,
                                "",
                                WS_VISIBLE|SS_TEXT|DT_LEFT|DT_VCENTER|SS_AUTOSIZE,
                                125,415,
                                495,16,
                                hwnd,
                                HWND_TOP,
                                1001,
                                NULL,
                                NULL );


    clr = CLR_DARKGRAY;
    WinSetPresParam(h,PP_BACKGROUNDCOLORINDEX,sizeof(clr),&clr);
    clr = CLR_BLACK;
    WinSetPresParam(h,PP_FOREGROUNDCOLORINDEX,sizeof(clr),&clr);


 }

 static int insertPage(HWND h, RECORDCORE *base, USHORT id, HWND dialog, const char *text)
 {
    RECORDCORE          *core;
    RECORDINSERT        recordInsert;
    int                 sz;
    char                *ptr;
    PAGE                *p;

    sz   = strlen(text)+sizeof(PAGE)+5;
    core = PVOIDFROMMR(WinSendMsg(h,CM_ALLOCRECORD,MPFROMLONG(sz),MPFROMSHORT(1)));

    if(!core)
       return -1;

    core->cb    = sizeof(RECORDCORE);
    memset(core,0,core->cb);

    p           = (PAGE *) (core+1);
    ptr         = (CHAR *) (p+1);

    p->dialog   = dialog;
    p->id       = id;

    strcpy( ptr, text);

//    DBGMessage(ptr);
//    DBGTracex(core);
//    DBGTrace(id);

    core->pszIcon  =
    core->pszName  =
    core->pszText  = ptr;

    while(*ptr && *ptr != '\n')
       ptr++;

    if(*ptr)
       *ptr = 0;
    else
       *(ptr+1) = 0;

    memset(&recordInsert,0,sizeof(RECORDINSERT));

    recordInsert.cb                  = sizeof(RECORDINSERT);                   /*RBS*/
    recordInsert.pRecordParent       = base;
    recordInsert.pRecordOrder        = (PRECORDCORE)CMA_END;
    recordInsert.zOrder              = CMA_TOP;
    recordInsert.cRecordsInsert      = 1;
    recordInsert.fInvalidateRecord   = TRUE;

    WinSendMsg(h,CM_INSERTRECORD,MPFROMP(core),MPFROMP(&recordInsert));

    return 0;

 }

 static void showDialog(HWND hwnd, HWND dialog, ULONG clr)
 {
    HWND        h       = WinWindowFromID(hwnd,1002);
    SWP         swp;
    SWP         dlg;
    USHORT      yPos;

    WinQueryWindowPos(h,&swp);
    WinQueryWindowPos(dialog,&dlg);

    yPos = swp.cy - (dlg.cy > swp.cy ? swp.cy : dlg.cy);

    WinSetWindowPos(dialog,0,0,yPos,swp.cx,dlg.cy,SWP_SHOW|SWP_MOVE|SWP_SIZE );

    WinSetPresParam(h,PP_BACKGROUNDCOLORINDEX,sizeof(clr),&clr);

 }


 static void configure(HWND hwnd, CFGDLG *cfg)
 {
    HAB                 hab             = WinQueryAnchorBlock(hwnd);
    HWND                base            = WinWindowFromID(hwnd,1002);
    HWND                container       = WinWindowFromID(hwnd,1000);
    char                buffer[0x0100]; /* CANT USE CFG->BUFFER!! IS USED BY OTHER THREAD */

    DBGMessage("Configurar a janela");

    WinSetWindowPtr(hwnd,0,cfg);

    /* Configure base dialog box */

    *buffer = 0;

    DBGTracex(cfg->load);

    if(cfg->load)
       cfg->load(cfg->icq,cfg->uin,cfg->type,cfg->frame,base,&dlgInsert,buffer);

    if(*buffer)
       WinSetWindowText(cfg->frame,buffer);

    if(cfg->bg)
    {
       cfg->dialog = cfg->bg;
    }
    else
    {

       /* Load the about box if the loader procedure didn't */
       cfg->dialog =
       cfg->bg     = WinLoadDlg(   base,
                                   base,   // h,
                                   aboutDialog,
                                   module,
                                   (icqLoadProfileValue(cfg->icq,"MAIN","SmallFonts",0) & 0x1) ? 100 : 101,
                                   NULL );

       ajustDialogParameters(cfg->bg,cfg->icq);

       *buffer = ' ';
       if(WinLoadString(hab, module, 1311, 0xFE, buffer+1))
          WinSetWindowText(WinWindowFromID(hwnd,1001),buffer);

       WinSetWindowPtr(cfg->bg,QWL_USER,cfg);
       showDialog(hwnd,cfg->bg,CLR_PALEGRAY);

    }

    if(!cfg->icon)
       cfg->icon = WinLoadPointer(HWND_DESKTOP,module,300);

    if(cfg->icon)
       WinSendMsg(cfg->frame,WM_SETICON,(MPARAM) cfg->icon,0);


    /* Posiciona e mostra */
/*
    cols = 581; // 495
//    rows = 386; // 386

    if(cfg->bg)
    {
       WinQueryWindowPos(cfg->bg,&swp);
       DBGTrace(swp.cx);
       DBGTrace(swp.cy);

       cols = swp.cx+87;

//       WinQueryWindowPos(container,&swp);
//       cols += swp.cx; // 119

//       rows = swp.cy;
    }

    DBGTrace(cols);
//    DBGTrace(rows);
*/

    if(icqLoadValue(cfg->icq, "AjustDialogFont", 1))
    {
       WinLoadString(hab, module, 1301, 0xFF, buffer);
       WinSetPresParam( WinWindowFromID(hwnd,1001),PP_FONTNAMESIZE,(ULONG) strlen(buffer)+1,(PVOID) buffer);
    }

// De acordo com �rico: cx = 868 cy = 448

    sprintf(cfg->buffer,"cfgWin.%d",cfg->type);
    icqRestoreWindow(   cfg->frame,
                        cfg->icq, cfg->uin,
                        cfg->buffer,
                        (icqLoadProfileValue(cfg->icq,"MAIN","SmallFonts",0) & 0x1) ? 578 : 730,
                        475);

//                        (icqLoadProfileValue(cfg->icq,"MAIN","SmallFonts",0) & 0x1) ? 578 : 868,
 }

 static void destroy(HWND hwnd)
 {
 }

 static void border(HWND hwnd, HPS hps)
 {
   SWP          pos;
   POINTL       p;

   WinQueryWindowPos(hwnd,&pos);
   pos.x--;
   pos.y--;
   pos.cx +=2;
   pos.cy +=2;
   GpiSetColor(hps,CLR_BLACK);

   p.x = pos.x;
   p.y = pos.y;
   GpiMove(hps,&p);
   p.y = pos.cy;
   GpiLine(hps,&p);
   p.x = pos.cx;
   GpiLine(hps,&p);
   p.y = pos.y;
   GpiLine(hps,&p);
   p.x = pos.x;
   GpiLine(hps,&p);

 }

 static void paint(HWND hwnd)
 {
   RECTL        rcl;
   HPS          hps;

   hps = WinBeginPaint(hwnd,NULLHANDLE,&rcl);
   WinFillRect(hps, &rcl, CLR_PALEGRAY);

   border(WinWindowFromID(hwnd,1000),hps);

   WinEndPaint(hps);
 }

 static RECORDCORE *findNode(HWND container, USHORT pos)
 {
    RECORDCORE *node = WinSendMsg(container,CM_QUERYRECORD,0,MPFROM2SHORT(CMA_FIRST,CMA_ITEMORDER));

//    DBGTracex(node);
#ifdef DEBUG
    if(!node)
       DBGMessage("Arvore do container esta vazia!!!");
#endif

    while(node && ((PAGE *)(node+1))->id != pos)
       node = WinSendMsg(container,CM_QUERYRECORD,MPFROMP(node),MPFROM2SHORT(CMA_NEXT,CMA_ITEMORDER));

//    DBGTracex(node);

    return node;

 }

 static HWND _System ajustDlg(HWND hwnd,HWND h)
 {
    CFGDLG *cfg = WinQueryWindowPtr(WinWindowFromID(hwnd,FID_CLIENT),0);
    if(cfg)
       return ajustDialogParameters(h,cfg->icq);
    return 0;
 }

 static int _System addPage(HWND hwnd, USHORT pos, HWND dlg, const char *title)
 {
    /* Anexa um dialogo pr�-carregado no container */
    char                buffer[80];
    HWND                h         = WinWindowFromID(hwnd,FID_CLIENT);
    HWND                base      = WinWindowFromID(h,1002);
    HWND                container = WinWindowFromID(h,1000);
    CFGDLG              *cfg      = WinQueryWindowPtr(h,0);
    RECORDCORE          *node;

    DBGTracex(dlg);

    if( !(h && cfg && container && base) )
       return 1;

    DBGTracex(cfg);

    if(cfg->sz != sizeof(CFGDLG))
       return 2;

    DBGTracex(base);

    if(!base)
       return 3;


    node = findNode(container,pos);

    if(!node)
    {
       /* Unable to find node, insert it */
      if(WinLoadString(WinQueryAnchorBlock(container), module, pos, 79, buffer))
          insertPage(container,NULL,pos,NULLHANDLE,buffer);
    }

    node = findNode(container,pos);

    WinShowWindow(dlg,FALSE);

    return insertPage(container, node, 0xFFFF, dlg, title);
}


 static int _System insertDialog(HWND hwnd, HMODULE mod, USHORT id, const DLGMGR *mgr, USHORT pos)
 {
    /* Carrega um dialogo e insere no n� "pos" da arvore */
    HWND                h         = WinWindowFromID(hwnd,FID_CLIENT);
    HWND                base      = WinWindowFromID(h,1002);
    HWND                container = WinWindowFromID(h,1000);
    CFGDLG              *cfg      = WinQueryWindowPtr(h,0);
    HWND                dlg;
    RECORDCORE          *node;
    char                title[80];
    char                *ptr;
    struct cfgdlgparm   dparm;

#ifndef DEBUG
    if(mgr && mgr->sz != sizeof(DLGMGR))
       return 5;
#endif

//    DBGTracex(h);

    if( !(h && cfg && container && base) )
       return 1;

//    DBGTracex(cfg);

    if(cfg->sz != sizeof(CFGDLG))
       return 2;

//    DBGTracex(base);
    if(!base)
       return 3;

    memset(&dparm,0,sizeof(dparm));

    dparm.sz    = sizeof(struct cfgdlgparm);
    dparm.uin   = cfg->uin;
    dparm.icq   = cfg->icq;
    dparm.mgr   = mgr;

    if(pos == 0xFFFF)
    {
       DBGMessage("Carregar di�logo de about");

       if(cfg->bg)
          return -1;

       cfg->bg = WinLoadDlg(   base,
                               base,
                               cfgDialogProc,
                               mod,
                               id,
                               &dparm );

       ajustDialogParameters(cfg->bg,cfg->icq);

       if(!cfg->icon)
          cfg->icon = WinLoadPointer(HWND_DESKTOP,mod,id);

       if(WinLoadString(WinQueryAnchorBlock(container), mod, id, 79, title))
       {
           DBGMessage(title);

           for(ptr = title; *ptr && *ptr != '\n';ptr++);

           DBGMessage(ptr);

           if(*ptr)
           {
              *ptr = ' ';
              WinSetWindowText(WinWindowFromID(h,1001),ptr);
           }
       }

       if(mgr && mgr->load)
          mgr->load(&dlgHelper,cfg->bg,cfg->icq,cfg->uin,cfg->buffer);

       showDialog(h,cfg->bg,CLR_PALEGRAY);

       return 0;
    }

    node = findNode(container,pos);

    if(!node)
    {
       /* Unable to find node, insert it */
      if(WinLoadString(WinQueryAnchorBlock(container), module, 1500+pos, 79, title))
          insertPage(container,NULL,pos,NULLHANDLE,title);
    }

    if(!id)
       return 5;

    node = findNode(container,pos);

    if(!node)
       return 4;

    /* Carrego o dialogo */
    dlg = WinLoadDlg(   base,
                        base,   // h,
                        cfgDialogProc,
                        mod,
                        id,
                        &dparm );


    ajustDialogParameters(dlg,cfg->icq);

#ifdef DEBUG
    if(!dlg)
       DBGMessage("N�o conseguiu carregar o dialogo!!!!!!!!");
#endif

    if(!dlg)
       return -1;

    WinEnableWindow(dlg,FALSE);
    WinSetWindowPos(dlg,0,0,0,492,415,SWP_HIDE|SWP_MOVE );

    *title = 0;
    WinLoadString(WinQueryAnchorBlock(dlg), mod, id, 79, title);

    return insertPage(container, node, 0xFFFF, dlg, title);

 }

 static void selectDialog(HWND hwnd)
 {
    CFGDLG      *cfg = WinQueryWindowPtr(hwnd,0);
    RECORDCORE  *rec = WinSendMsg(WinWindowFromID(hwnd,1000),CM_QUERYRECORDEMPHASIS,MPFROMLONG(CMA_FIRST),MPFROMSHORT(CRA_SELECTED));
    PAGE        *p;
    const char  *src;
    char        *dst;
    HWND        dialog;

    DBGTracex(cfg);

    if(!cfg)
       return;

    DBGMessage("Selecionar dialogo");

    if(!rec || ((LONG)rec) == -1)
       return;

    p = (PAGE *)(rec+1);

    if(!p->dialog && p->id == CFGWIN_ABOUT)
       dialog = cfg->bg;
    else
       dialog = p->dialog;

    if(!dialog || dialog == cfg->dialog)
       return;

    DBGTracex(p);
    DBGTrace(p->id);
    DBGTracex(p->dialog);

    if(cfg->dialog)
       WinSetWindowPos(cfg->dialog,0,0,0,492,415,SWP_HIDE|SWP_MOVE );

    showDialog(hwnd,dialog,CLR_PALEGRAY);

    cfg->dialog  = dialog;
    p->flags    |= DLG_SELECTED;

    dst = cfg->buffer;
    *(dst++) = ' ';

    if(dialog == cfg->bg)
    {
       *dst = 0;
       WinLoadString(WinQueryAnchorBlock(dialog), module, 1311, 0xFE, dst);
    }
    else
    {
       src = (char *)(p+1);
       while(*src)
          src++;
       src++;
       strncpy(dst,src,0xF0);

       WinPostMsg(cfg->dialog,WMICQ_SELECTED,0,0);
    }

    DBGMessage(cfg->buffer);
    WinSetWindowText(WinWindowFromID(hwnd,1001),cfg->buffer);

    CHKPoint();

    WinSetFocus(HWND_DESKTOP,cfg->dialog);

    CHKPoint();

 }

 static void _System ldlThread(ICQTHREAD *t)
 {
    CFGDLG      *cfg    = (CFGDLG *) t->parm;

    HICQ        icq     = ( (CFGDLG *) t->parm )->icq;
    ULONG       uin     = ( (CFGDLG *) t->parm )->uin;
    USHORT      type    = ( (CFGDLG *) t->parm )->type;

    HAB         hab;
    HMQ         hmq;

    DBGMessage("Thread de leitura de configuracao iniciada");

    if( (hab = WinInitialize(0)) != NULLHANDLE)
    {
       if( (hmq = WinCreateMsgQueue(hab,0)) != NULLHANDLE)
       {
          /* Faz a carga inicial */

          // Configure window
          WinSendMsg(cfg->hwnd,WM_USER+10,MPFROMP(cfg),0);

          // Load information
          DBGMessage("Pedir a carga de configura��o");
          broadcast(WinWindowFromID(cfg->hwnd,1000),WMICQ_LOAD,0,0);
          DBGMessage("Configuracao carregada");

          WinDestroyMsgQueue(hmq);
       }
       WinTerminate(hab);
    }

    DBGMessage("Thread de leitura de configuracao terminada");

 }

 static void broadcast(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    RECORDCORE  *node;
    RECORDCORE  *item;
    PAGE        *page;

    for( node = WinSendMsg(hwnd,CM_QUERYRECORD,0,MPFROM2SHORT(CMA_FIRST,CMA_ITEMORDER));
         node;
         node = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(node),MPFROM2SHORT(CMA_NEXT,CMA_ITEMORDER)) )
    {
       for( item = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(node),MPFROM2SHORT(CMA_FIRSTCHILD,CMA_ITEMORDER));
            item;
            item = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(item),MPFROM2SHORT(CMA_NEXT,CMA_ITEMORDER)) )
       {
          page = (PAGE *)(item+1);
          if(page->dialog)
             WinSendMsg(page->dialog,msg,mp1,mp2);
       }
    }

 }

 static void save(CFGDLG *cfg, HWND hwnd)
 {
    RECORDCORE  *node;
    RECORDCORE  *item;
    PAGE        *page;
    HPOINTER    pointer;

    DBGMessage("Salvando informacoes...");

    pointer = WinQueryPointer(HWND_DESKTOP);
    WinSetPointer(HWND_DESKTOP,WinQuerySysPointer(HWND_DESKTOP,SPTR_WAIT,FALSE));

    for( node = WinSendMsg(hwnd,CM_QUERYRECORD,0,MPFROM2SHORT(CMA_FIRST,CMA_ITEMORDER));
         node;
         node = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(node),MPFROM2SHORT(CMA_NEXT,CMA_ITEMORDER)) )
    {
       for( item = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(node),MPFROM2SHORT(CMA_FIRSTCHILD,CMA_ITEMORDER));
            item;
            item = WinSendMsg(hwnd,CM_QUERYRECORD,MPFROMP(item),MPFROM2SHORT(CMA_NEXT,CMA_ITEMORDER)) )
       {
          page = (PAGE *)(item+1);

          if(page->dialog && (page->flags & DLG_SELECTED) && WinIsWindowEnabled(page->dialog))
             WinSendMsg(page->dialog,WMICQ_SAVE,0,0);
       }
    }

    WinSetPointer(HWND_DESKTOP,pointer);

    sprintf(cfg->buffer,"cfgWin.%d",cfg->type);
    icqStoreWindow(cfg->frame, cfg->icq, cfg->uin, cfg->buffer);

 }

 static HWND ajustDialogParameters(HWND hwnd,HICQ icq)
 {
    char                buffer[0x0100];

    if(hwnd && icqLoadValue(icq, "AjustDialogFont", 1))
    {
       WinLoadString(WinQueryAnchorBlock(hwnd), module, 1302, 0xFF, buffer);
       DBGMessage(buffer);
       WinSetPresParam(hwnd,PP_FONTNAMESIZE,(ULONG) strlen(buffer)+1,(PVOID) buffer);
    }
    return hwnd;
 }


 static HWND _System loadDialog(HWND hwnd, HICQ icq, ULONG uin, HMODULE mod, USHORT id, const DLGMGR *mgr)
 {
    struct cfgdlgparm   dparm;
    HWND                ret;

    if(mgr && mgr->sz != sizeof(DLGMGR))
       return NULLHANDLE;

    memset(&dparm,0,sizeof(dparm));

    dparm.sz  = sizeof(struct cfgdlgparm);
    dparm.uin = uin;
    dparm.icq = icq;
    dparm.mgr = mgr;

    ret = WinLoadDlg(   hwnd,
                        hwnd,
                        cfgDialogProc,
                        mod,
                        id,
                        &dparm );

    ajustDialogParameters(ret,icq);

    return ret;
 }

 static void procAboutButton(HWND hwnd, CFGDLG *cfg, USHORT id)
 {

    if(cfg->sz != sizeof(CFGDLG))
    {
       DBGMessage("*** ERRO GRAVE, CHAMOU BOTAO SEM ESTRUTURA DE CONTROLE");
       return;
    }

    DBGTrace(id);

    switch(id)
    {
    case 104:
       icqNewUserMessage(cfg->icq, 27241234, MSG_NORMAL, 0, 0);
       break;

    case 102:
       icqOpenURL(cfg->icq, "news://news.ecomstation.dk/pwicq.help");
       break;

    default:
       icqWriteSysLog(cfg->icq,PROJECT,"Invalid button request in about dialog");
    }

 }

 MRESULT EXPENTRY aboutDialog(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_CONTROL:
       CHKPoint();
       return WinDefDlgProc(hwnd,msg,mp1,mp2);

    case WM_COMMAND:            /* Acao de controle */
       CHKPoint();
       if(SHORT1FROMMP(mp2) != CMDSRC_PUSHBUTTON)
          return WinDefDlgProc(hwnd,msg,mp1,mp2);
       procAboutButton(hwnd,WinQueryWindowPtr(hwnd,QWL_USER),SHORT1FROMMP(mp1));
       break;

    default:
       return WinDefDlgProc(hwnd,msg,mp1,mp2);

    }

    return 0;
 }

