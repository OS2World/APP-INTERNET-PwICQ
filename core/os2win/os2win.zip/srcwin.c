/*
 * srcwin.c - Search Window
 */

 #pragma strings(readonly)

 #define INCL_WIN
 #define INCL_DOSPROCESS
 #include <stdio.h>
 #include <malloc.h>
 #include <string.h>

 #include <msgdlg.h>
 #include "wintlkt.h"

#ifdef DEBUG
 #define DEBUG_CONTAINER
#endif

/*---[ Estruturas ]-------------------------------------------------------------------------------------*/

 #define STRING_COUNTER 12

 #pragma pack(1)

 typedef struct shrWindow
 {
    USHORT			sz;
    HICQ			icq;
    HWND			frame;
    const ICQSEARCHRESPONSE	*selected;
    USHORT			nbCols;
    USHORT			lbCols;
    USHORT			lbMin;
    USHORT			nbMin;
    HPOINTER			mode[3];
    USHORT			offset[STRING_COUNTER];
    char			text[1];
 } SHRWINDOW;

typedef struct _record
{
  RECORDCORE  		recordCore;
  HPOINTER		mode;
  PSZ			nick;
  PSZ			sex;
  PSZ			first;
  PSZ			last;
  PSZ			auth;
  ULONG			age;
  ICQSEARCHRESPONSE	r;
} RECORD, *PRECORD;

/*

  X  0        1           2      3                                           4   5
     ICQ#     Nick        Gender Name                                        Age Authorization

 xxx xxxxxxxx xxxxxxxxxxx xxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx xx  Required

*/

/*---[ Macros ]-----------------------------------------------------------------------------------------*/

 #define HWINDOW(h,w) SHRWINDOW *w = WinQueryWindowPtr(h,0);if(!w) return

 #define LB_FOREGROUND	CLR_BLACK
 #define LB_BACKGROUND	CLR_WHITE


/*---[ Prototipos ]-------------------------------------------------------------------------------------*/

 static void _System shrThread(ICQTHREAD *);
 static void _System stopthread(ICQTHREAD *);
 static void _System event(ICQTHREAD *, ULONG, char, USHORT, ULONG);

 static int  _System insertDialog(HWND,HMODULE,USHORT,const DLGMGR *,USHORT);
 static HWND _System loadDialog(HWND, HICQ, ULONG, HMODULE, USHORT, const DLGMGR *);
 static int  _System addPage(HWND, USHORT, HWND, const char *);
 static HWND _System ajustDlg(HWND,HWND);


 static void 	create(HWND,PCREATESTRUCT);
 static void 	destroy(HWND);
 static void 	paint(HWND);
 static void 	resize(HWND, USHORT, USHORT);
 static void 	start(HWND, HICQ, HWND);
 static void 	action(HWND,USHORT, USHORT);
 static void 	doClick(HWND,USHORT);
 static void 	addResponse(SHRWINDOW *, HWND, ICQSEARCHRESPONSE *);
 static void 	addResult(HWND, ICQSEARCHRESPONSE *);
 static void    ctlContainer(HWND, USHORT, ULONG);
 static void    setButtons(HWND, SHRWINDOW *);
 static void    sendMessage(HICQ, const ICQSEARCHRESPONSE *);
 static void    askForAuthorization(HICQ, const ICQSEARCHRESPONSE *);
 static void    openAboutUser(HICQ, const ICQSEARCHRESPONSE *);

/*---[ Constantes ]-------------------------------------------------------------------------------------*/

 extern const char      *shrClass       = "pwICQSearchWindow";

 static const DLGINSERT dlgInsert       = {     sizeof(DLGINSERT),
                                                insertDialog,
                                                loadDialog,
                                                addPage,
                                                ajustDlg
                                          };

 static const DLGHELPER dlgHelper = {  sizeof(DLGHELPER),
                                       setString,
                                       getString,

                                       setCheckBox,
                                       getCheckBox,

                                       setRadioButton,
                                       getRadioButton,

                                       getLength,
                                       enableControl,
                                       setTextLimit,

                                       NULL,
                                       NULL,

                                       NULL,
                                       NULL,

                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,

                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,

                                       NULL

                                 };


 static const USHORT	buttons[]	= { 	ICQSHRC_CLOSE,
 						ICQSHRC_ADD,
 						ICQSHRC_MESSAGE,
 						ICQSHRC_ABOUT,
 						ICQSHRC_SEARCH,
 						0
 					  };
 					
 static const char	*aboutUserURL   = "http://web.icq.com/whitepages/about_me/1,,,00.html?Uin=%ld";
  					

#ifdef DEBUG_CONTAINER

 static char user1[] = { 0x18, 0x00, 0x20, 0x00, 0x25, 0xe1, 0x8d, 0x01, 0x00, 0x00, 0x00, 0x80, 0x02, 0x16, 0x02, 0x00,
                         0x00, 0x06, 0x00, 0x0f, 0x00, 0x16, 0x00, 0x58, 0x50, 0x54, 0x4f, 0x00, 0x00, 0x4d, 0x61, 0x72,
                         0x63, 0x65, 0x6c, 0x6f, 0x00, 0x00, 0x4c, 0x65, 0x6d, 0x6f, 0x73, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

 static char user2[] = { 0x18, 0x00, 0x3f, 0x00, 0x12, 0xab, 0x9f, 0x01, 0x00, 0x00, 0x00, 0x80, 0x02, 0x23, 0x00, 0x00,
                         0x00, 0x0a, 0x00, 0x14, 0x00, 0x23, 0x00, 0x57, 0x61, 0x72, 0x69, 0x6e, 0x67, 0x65, 0x72, 0x00,
                         0x00, 0x47, 0x65, 0x6f, 0x66, 0x66, 0x72, 0x65, 0x79, 0x00, 0x00, 0x41, 0x62, 0x65, 0x6c, 0x20,
                         0x57, 0x61, 0x72, 0x69, 0x6e, 0x67, 0x65, 0x72, 0x00, 0x00, 0x74, 0x72, 0x65, 0x76, 0x69, 0x7a,
                         0x65, 0x40, 0x7a, 0x61, 0x7a, 0x2e, 0x63, 0x6f, 0x6d, 0x2e, 0x62, 0x72, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
#endif

/*---[ Implementacao ]----------------------------------------------------------------------------------*/

 int EXPENTRY icqOpenSearchWindow(HICQ icq, USHORT id)
 {
    DBGTracex(id);
    icqCreateThread(icq, &shrThread, 32768, sizeof(HWND), (void *) id, "USW"); /* [U]ser [S]earch [W]indow */
    return 0;
 }

 static void _System shrThread(ICQTHREAD *thd)
 {
    HMQ     hmq;
    QMSG    qmsg;
    HAB	    hab;
    HWND    frame;
    HWND    *h	  	 = (HWND *) (thd+1);
    ULONG   ulFrameFlags = FCF_TITLEBAR|FCF_SIZEBORDER|FCF_ICON|FCF_MINMAX|FCF_TASKLIST|FCF_SYSMENU|FCF_NOMOVEWITHOWNER|FCF_ACCELTABLE;

    DBGMessage("Thread de pesquisa iniciada");
    DBGTracex(thd->parm);

    hab = WinInitialize(0);

    if(hab != NULLHANDLE)
    {
       hmq = WinCreateMsgQueue(hab,0);
       if(hmq != NULLHANDLE)
       {

          frame = WinCreateStdWindow(   HWND_DESKTOP,
                               		0,
                               		&ulFrameFlags,
                               		(PSZ) shrClass,
                               		(PSZ) "pwICQ Search",
                               		WS_VISIBLE,
                               		(HMODULE) module,
                               		101,
                               		h );

	  DBGTracex( *h );
	
	  if(*h)
	  {
   	     thd->stopthread = stopthread;
   	     thd->event	     = event;
   	
   	     WinPostMsg(*h,WM_USER+10,(MPARAM) thd->icq, (MPARAM) frame);
   	
             while(WinGetMsg(hab,&qmsg,0,0,0))
                WinDispatchMsg(hab,&qmsg);
          }

          WinDestroyMsgQueue(hmq);
       }
       WinTerminate(hab);
    }

    DBGMessage("Thread de pesquisa terminada");
 }

 static void _System stopthread(ICQTHREAD *thd)
 {
    HWND hwnd = *( (HWND *)(thd+1) );

    DBGMessage("**** Encerrar thread de pesquisa");
    DBGTracex(hwnd);
    if(hwnd != NULLHANDLE)
       WinPostMsg(hwnd,WM_CLOSE,0,0);
 }

 static void _System event(ICQTHREAD *thd, ULONG uin, char id, USHORT event, ULONG parm)
 {
    HWND 	hwnd = *( (HWND *)(thd+1) );

    if(!hwnd)
       return;

    if(id == 'S')
    {
       WinPostMsg(hwnd,WMICQ_EVENT,MPFROMSH2CH(event, id, 0), (MPARAM) parm);
       switch(event)
       {
       case ICQEVENT_STOPPING:
          DBGMessage("ICQEVENT_STOPPING");
          WinPostMsg(hwnd,WM_CLOSE,0,0);
          break;

       case ICQEVENT_ONLINE:
          DBGMessage("ICQEVENT_ONLINE");
          WinPostMsg(hwnd,WM_USER+11,(MPARAM) TRUE, 0);
          break;

       case ICQEVENT_OFFLINE:
          DBGMessage("ICQEVENT_OFFLINE");
          WinPostMsg(hwnd,WM_USER+11, 0, 0);
          break;
       }
    }
 }


 MRESULT EXPENTRY shrDialogProc(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_DESTROY:
       destroy(hwnd);
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    case WM_CREATE:
       DBGTracex(hwnd);
       create(hwnd,PVOIDFROMMP(mp2));
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    case WM_SIZE:
       resize(hwnd, SHORT1FROMMP(mp2), SHORT2FROMMP(mp2));
       break;

    case WM_PAINT:
       paint(hwnd);
       break;

    case WM_COMMAND:
       if(SHORT1FROMMP(mp2) != CMDSRC_MENU)
          action(hwnd,SHORT1FROMMP(mp1),SHORT1FROMMP(mp2));
       break;

    case WM_CONTROL:
       if(SHORT1FROMMP(mp1) == ICQSHRC_CONTAINER)
          ctlContainer(hwnd,SHORT2FROMMP(mp1),LONGFROMMP(mp2));
       break;

    case WM_USER+10:
       start(hwnd,(HICQ) mp1, (HWND) mp2);
       break;

    case WM_USER+11:	// Sistema mudou de estado, ajusta botoes (MP1 = Online)
       setButtons(hwnd, WinQueryWindowPtr(hwnd,0));
       break;

    case WM_USER+12:	// Anexar mais um elemento no container
       addResult(hwnd,(ICQSEARCHRESPONSE *) mp1);
       break;

    case WM_USER+13:	// Mudar o estado de pesquisa MP1=Libera botao, mp2=Limpa Container
       WinEnableControl(hwnd,ICQSHRC_SEARCH,(BOOL) mp1);
       if(mp2)
       {
          DBGMessage("Limpar o container");
          ((SHRWINDOW *) WinQueryWindowPtr(hwnd,0))->selected = NULL;
          WinSendDlgItemMsg(hwnd,ICQSHRC_CONTAINER,CM_REMOVERECORD,0,MPFROM2SHORT(0,CMA_FREE|CMA_INVALIDATE));
          setButtons(hwnd, (SHRWINDOW *) WinQueryWindowPtr(hwnd,0));
       }
       break;

    case WMICQ_EVENT:	// Fazer um broadcast do evento para todos os dialogos
       break;

    case WM_CLOSE:
       icqAbortSearchByWindow( ((SHRWINDOW *) WinQueryWindowPtr(hwnd,0))->icq, hwnd);
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    default:
       return WinDefWindowProc(hwnd,msg,mp1,mp2);
    }

    return 0;
 }

 static void create(HWND hwnd, PCREATESTRUCT c)
 {
    SHRWINDOW   	*ctl;
    char		buffer[0x0100];
    HAB                 hab     	= WinQueryAnchorBlock(hwnd);
    ULONG               bg      =	 CLR_PALEGRAY;
    const USHORT	*id;
    int			f;
    int			bytes;
    HWND		h;
    CNRINFO             cnrinfo;
    char		offset;
    PFIELDINFO  	pFieldInfo,
    			firstFieldInfo;
    FIELDINFOINSERT 	fieldInfoInsert;

    for(f=bytes=0;f<STRING_COUNTER;f++)
    {
       WinLoadString(hab, module, 10+f, 0xFF, buffer);
       bytes += strlen(buffer)+1;
    }

    ctl	= malloc(sizeof(SHRWINDOW)+bytes+STRING_COUNTER);

    DBGTracex(hwnd);
    DBGTracex(ctl);

    WinSetWindowPtr(hwnd,0,ctl);
    if(!ctl)
    {
       WinPostMsg(hwnd,WM_CLOSE,0,0);
       return;
    }

    memset(ctl,0,sizeof(SHRWINDOW));
    ctl->sz      = sizeof(SHRWINDOW);
    ctl->lbMin   = 80;
    ctl->nbMin   = 100;

    for(f=0;f<3;f++)
       ctl->mode[f] = WinLoadPointer(HWND_DESKTOP, module, 400+f);

    for(f=offset=0;f<STRING_COUNTER;f++)
    {
       ctl->offset[f] = offset;
       WinLoadString(hab, module, 10+f, bytes-offset, ctl->text+offset);
       offset += strlen(ctl->text+offset)+1;
    }

#ifdef DEBUG
    for(f=0;f<STRING_COUNTER;f++)
       DBGMessage(ctl->text+ctl->offset[f]);
#endif

    WinSetPresParam(hwnd,PP_BACKGROUNDCOLORINDEX,sizeof(bg),&bg);
    WinSetPresParam(hwnd,PP_DISABLEDBACKGROUNDCOLORINDEX,sizeof(bg),&bg);


    /* Cria botoes */
    for(id = buttons; *id; id++)
    {
       *buffer = 0;
       WinLoadString(hab, module, *id, 0xFF, (PSZ) buffer);
       WinCreateWindow(hwnd, WC_BUTTON, buffer, BS_AUTOSIZE|BS_PUSHBUTTON|WS_VISIBLE|WS_GROUP|WS_TABSTOP,0,0,0,0,hwnd,HWND_BOTTOM,*id,0,0);
       WinEnableControl(hwnd,*id,FALSE);
    }

    WinCreateWindow(hwnd, WC_NOTEBOOK, "", WS_VISIBLE|BKS_BACKPAGESTR|BKS_TABBEDDIALOG|BKS_MAJORTABTOP|BKS_ROUNDEDTABS|BKS_TABTEXTCENTER,0,0,0,0,hwnd,HWND_BOTTOM,ICQSHRC_NOTEBOOK,0,0);

    /* Cria o container */
    h = WinCreateWindow(hwnd, WC_CONTAINER,  "",CCS_READONLY|CCS_SINGLESEL|WS_VISIBLE|WS_GROUP|WS_TABSTOP,0,0,0,0,hwnd,HWND_BOTTOM,ICQSHRC_CONTAINER,0,0);

    memset(&cnrinfo,0,sizeof(cnrinfo));
    cnrinfo.cb                = sizeof( CNRINFO );
    cnrinfo.flWindowAttr      = CV_DETAIL|CA_DETAILSVIEWTITLES;
    cnrinfo.slBitmapOrIcon.cx =
    cnrinfo.slBitmapOrIcon.cy = 18;
    cnrinfo.pszCnrTitle       = "";

    WinSendMsg(h, CM_SETCNRINFO, &cnrinfo, MPFROMLONG(CMA_FLWINDOWATTR|CMA_SLBITMAPORICON|CMA_CNRTITLE));

    firstFieldInfo         =
    pFieldInfo             = WinSendMsg(h, CM_ALLOCDETAILFIELDINFO, MPFROMLONG(8), NULL);

    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_BITMAPORICON  | CFA_CENTER; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_CENTER;
    pFieldInfo->pTitleData = (PVOID) "";
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,mode);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_ULONG | CFA_HORZSEPARATOR | CFA_RIGHT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_RIGHT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[5]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,r.uin);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_STRING | CFA_HORZSEPARATOR | CFA_LEFT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_LEFT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[6]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,nick);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_STRING | CFA_HORZSEPARATOR | CFA_LEFT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_LEFT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[7]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,sex);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_STRING | CFA_HORZSEPARATOR | CFA_LEFT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_LEFT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[8]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,first);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_STRING | CFA_HORZSEPARATOR | CFA_LEFT;
    pFieldInfo->flTitle    = CFA_LEFT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[9]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,last);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_ULONG | CFA_HORZSEPARATOR | CFA_RIGHT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_RIGHT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[10]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,age);

    pFieldInfo             = pFieldInfo->pNextFieldInfo;
    pFieldInfo->cb         = sizeof(FIELDINFO);
    pFieldInfo->flData     = CFA_STRING | CFA_HORZSEPARATOR | CFA_LEFT; // | CFA_SEPARATOR;
    pFieldInfo->flTitle    = CFA_LEFT;
    pFieldInfo->pTitleData = (PVOID) (ctl->text+ctl->offset[11]);
    pFieldInfo->offStruct  = FIELDOFFSET(RECORD,auth);


    memset(&fieldInfoInsert,0,sizeof(FIELDINFOINSERT));
    fieldInfoInsert.cb                   = (ULONG)(sizeof(FIELDINFOINSERT));
    fieldInfoInsert.pFieldInfoOrder      = (PFIELDINFO)CMA_FIRST;
    fieldInfoInsert.cFieldInfoInsert     = 8;
    fieldInfoInsert.fInvalidateFieldInfo = TRUE;

    WinSendMsg(h, CM_INSERTDETAILFIELDINFO,firstFieldInfo,&fieldInfoInsert);

    bg = CLR_PALEGRAY;
    WinSetPresParam(h,PP_BACKGROUNDCOLORINDEX,sizeof(bg),&bg);


 }

 static void destroy(HWND hwnd)
 {
    SHRWINDOW 	*ctl = WinQueryWindowPtr(hwnd,0);
    int		f;

    if(ctl)
    {
       for(f=0;f<3;f++)
          WinDestroyPointer(ctl->mode[f]);
       free(ctl);
       WinSetWindowPtr(hwnd,0,0);
    }
 }

 static void paint(HWND hwnd)
 {
   RECTL        rcl;
   HPS          hps;
   hps = WinBeginPaint(hwnd,NULLHANDLE,&rcl);
   WinFillRect(hps, &rcl, CLR_PALEGRAY);
   WinEndPaint(hps);
 }

 static void start(HWND hwnd, HICQ icq, HWND frame)
 {
    char  	buffer[0x0100];
    ULONG 	page;
    HWND  	notebook;
    HWND  	dlg;
    HPLUGIN     p;
    SWP		swp;
    void        (* _System addSearchDialog)(HICQ, void *, USHORT, HWND, const DLGINSERT *, char *);

    HWINDOW(hwnd,w);

    w->icq   = icq;
    w->frame = frame;
    w->lbMin = icqLoadValue(icq,"search:lbMin",w->lbMin);
    w->nbMin = icqLoadValue(icq,"search:nbMin",w->nbMin);

    /* Set fonts and colors before registering the controller to prevent double saving */
    icqLoadString(icq, "Font:ShrWin", "8.Helv", buffer, 0xFF);
    if(*buffer)
    {
       WinSetPresParam( hwnd,
                        PP_FONTNAMESIZE,
                        (ULONG) strlen(buffer)+1,
                        (PVOID) buffer);
    }

    /* Chama plugins para que eles anexem suas paginas */
    notebook = WinWindowFromID(hwnd,ICQSHRC_NOTEBOOK);

    for(p=icqQueryFirstPlugin(icq);p;p=icqQueryNextPlugin(icq,p))
    {
       if(!icqLoadSymbol(p, "SearchPage", (void **) &addSearchDialog))
          addSearchDialog(icq,icqQueryPluginDataBlock(icq,p),0,hwnd,&dlgInsert,buffer);
    }

    if(WinSendMsg(notebook,BKM_QUERYPAGECOUNT,0,MPFROMSHORT(BKA_END)))
    {
       DBGMessage("Achei pagina de pesquisa, apresento a janela");
       WinQueryWindowPos(WinWindowFromID(hwnd,ICQSHRC_CLOSE),&swp);
       DBGTrace(swp.cy);
       DBGTrace(w->nbCols);
       icqRestoreWindow(frame, icq, 0, "search", w->nbCols+30, w->lbMin+w->nbMin+50+swp.cy);
    }
    else
    {
       /* N�o achou paginas no notebook */
       WinLoadString(WinQueryAnchorBlock(hwnd), module, 1312, 40, buffer+0x81);
       WinLoadString(WinQueryAnchorBlock(hwnd), module, 1313, 0x80, buffer);
       WinMessageBox(	HWND_DESKTOP,
       			hwnd,
       			buffer,
               		buffer+0x81,	// "Can't search",
               		10000,
               		MB_ENTER|MB_ERROR|MB_MOVEABLE );

       WinPostMsg(hwnd,WM_CLOSE,0,0);
    }

    WinEnableControl(hwnd,ICQSHRC_CLOSE,TRUE);
    WinEnableControl(hwnd,ICQSHRC_SEARCH,TRUE);

#ifdef DEBUG_CONTAINER
    CHKPoint();
    addResult(hwnd,(ICQSEARCHRESPONSE *) user1);
    addResult(hwnd,(ICQSEARCHRESPONSE *) user2);
    CHKPoint();
#endif

 }

 static void resize(HWND hwnd, USHORT cx, USHORT cy)
 {
    SWP			swp;
    const USHORT	*id;
    HWND		ctl;
    USHORT		x	= cx;
    USHORT		ySize;
    USHORT		yBottom;

    HWINDOW(hwnd,w);

    ySize = 0;
    for(id = buttons; *id; id++)
    {
       ctl = WinWindowFromID(hwnd,*id);
       WinQueryWindowPos(ctl,&swp);
       x -= swp.cx;

       ySize = swp.cy > ySize ? swp.cy : ySize;
       WinSetWindowPos(ctl, 0, x, 0, 0, 0, SWP_MOVE);
       x -= 2;
   }

   yBottom = ySize+2;

   ySize   = (cy-(yBottom+w->nbMin+4));

   if(ySize < w->lbMin)
      ySize = w->lbMin;

   w->lbCols = cx;
   WinSetWindowPos(WinWindowFromID(hwnd,ICQSHRC_CONTAINER),0,0,yBottom,cx,ySize,SWP_MOVE|SWP_SIZE);

   yBottom += ySize+2;

   ySize    = cy-yBottom;

   if(ySize < w->nbMin)
      ySize = w->nbMin;

   WinSetWindowPos(WinWindowFromID(hwnd,ICQSHRC_NOTEBOOK),0,0,yBottom,cx,ySize,SWP_MOVE|SWP_SIZE);

 }

 static int _System insertDialog(HWND hwnd, HMODULE mod, USHORT id, const DLGMGR *mgr, USHORT pos)
 {
    /* Carrega um dialogo, insere no notebook */

    char       title[80];
    HWND       dlg;
    SHRWINDOW  *w = WinQueryWindowPtr(hwnd,0);

    if(!w)
       return -1;

    dlg = loadDialog(hwnd, w->icq, 0, mod, id, mgr);

    if(!dlg)
       return -2;

    *title = 0;
    WinLoadString(WinQueryAnchorBlock(hwnd), mod, id, 79, title);

    return addPage(hwnd, pos, dlg, title);
 }

 static HWND _System ajustDlg(HWND hwnd, HWND dlg)
 {
    char buffer[0x0100];

    SHRWINDOW  *w = WinQueryWindowPtr(hwnd,0);

    if(!w)
       return NULL;

    if(hwnd && icqLoadValue(w->icq, "AjustDialogFont", 1))
    {
       WinLoadString(WinQueryAnchorBlock(hwnd), module, 1302, 0xFF, buffer);
       DBGMessage(buffer);
       WinSetPresParam(dlg,PP_FONTNAMESIZE,(ULONG) strlen(buffer)+1,(PVOID) buffer);
    }
    return dlg;
 }

 static HWND _System loadDialog(HWND hwnd, HICQ icq, ULONG uin, HMODULE mod, USHORT id, const DLGMGR *mgr)
 {
    /* Carrega e configura um dialogo */

    struct cfgdlgparm   dparm;
    HWND                ret;

    if(mgr && mgr->sz != sizeof(DLGMGR))
       return NULLHANDLE;

    memset(&dparm,0,sizeof(dparm));

    dparm.sz  = sizeof(struct cfgdlgparm);
    dparm.uin = uin;
    dparm.icq = icq;
    dparm.mgr = mgr;

    ret = WinLoadDlg(   hwnd,
                        hwnd,
                        cfgDialogProc,
                        mod,
                        id,
                        &dparm );

    if(!ret)
       return ret;

    return ajustDlg(hwnd,ret);
 }


 static int _System addPage(HWND hwnd, USHORT pos, HWND dlg, const char *title)
 {
    /* Anexa um dialogo pre-carregado no notebook */
    HWND  	notebook 		= WinWindowFromID(hwnd,ICQSHRC_NOTEBOOK);
    char  	buffer[0x0100];
    char  	*ptr;
    ULONG 	page;
    RECTL	rcl;
    SWP	  	swp;
    SHRWINDOW   *w = WinQueryWindowPtr(hwnd,0);

    WinQueryWindowPos(dlg,&swp);
    DBGTrace(swp.cx);
    DBGTrace(swp.cy);

    DBGMessage(title);
    strncpy(buffer,title,0xFF);

    for(ptr=buffer;*ptr && *ptr != '\n';ptr++);

    if(*ptr)
       *(ptr++) = 0;

    DBGMessage(buffer);
    DBGMessage(ptr);

    page = (ULONG) WinSendMsg(notebook,BKM_INSERTPAGE,0,MPFROM2SHORT(BKA_AUTOPAGESIZE|BKA_MAJOR,BKA_LAST));

    WinSendMsg(notebook,BKM_SETPAGEWINDOWHWND,(MPARAM) page, (MPARAM) dlg);
    WinSendMsg(notebook,BKM_SETTABTEXT,(MPARAM) page, MPFROMP(buffer));

    memset(&rcl,0,sizeof(rcl));
    WinSendMsg(notebook,BKM_CALCPAGERECT,MPFROMP(&rcl),0);

    swp.cy += (rcl.yTop-rcl.yBottom);
    swp.cx += rcl.xRight - rcl.xLeft;

    if(w && w->nbCols < swp.cx)
       w->nbCols = swp.cx;

    if(w && w->nbMin < swp.cy)
       w->nbMin = swp.cy;

    return -1;
 }

 static void action(HWND hwnd, USHORT id, USHORT type)
 {
    SHRWINDOW *w = WinQueryWindowPtr(hwnd,0);

    switch(id)
    {
    case ICQMSGC_CLOSE:
       WinPostMsg(hwnd,WM_CLOSE,0,0);
       break;

    case ICQSHRC_ADD:
       if(w->selected)
          askForAuthorization(w->icq, w->selected);
       break;

    case ICQSHRC_ABOUT:
       if(w->selected)
          openAboutUser(w->icq,w->selected);
       break;

    case ICQSHRC_SEARCH:
       doClick(hwnd,id);
       break;

    case ICQSHRC_MESSAGE:
       if(w->selected)
          sendMessage(w->icq, w->selected);
       break;

#ifdef DEBUG
    default:
       DBGPrint("Acao desconhecida: id=%d",id);
#endif
    }

 }

 static void doClick(HWND hwnd, USHORT id)
 {
    HWND  	notebook 	= WinWindowFromID(hwnd,ICQSHRC_NOTEBOOK);
    ULONG 	page 		= (ULONG) WinSendMsg(notebook,BKM_QUERYPAGEID,0,MPFROM2SHORT(BKA_TOP,0));
    HWND	dlg;

    DBGTrace(id);
    DBGTracex(page);

    if(page == BOOKERR_INVALID_PARAMETERS || !page)
       return;

    dlg = (HWND) WinSendMsg(notebook,BKM_QUERYPAGEWINDOWHWND,MPFROMLONG(page),0);

    DBGTracex(dlg);

    if(dlg == BOOKERR_INVALID_PARAMETERS || !dlg)
       return;

    WinPostMsg(dlg,WMICQ_SEARCH,MPFROMSHORT(id),(MPARAM) hwnd);

 }

 static void addResponse(SHRWINDOW *w, HWND hwnd, ICQSEARCHRESPONSE *response)
 {
    int f;

    response->flags |= ICQSR_DLGFLAG;
    WinPostMsg(hwnd,WM_USER+12,(MPARAM) response,0);

//    icqDumpPacket(w->icq,NULL,"Search response block received",response->sz + sizeof(ICQSEARCHRESPONSE), (char *) response);

    for(f=0;f<200 && (response->flags & ICQSR_DLGFLAG);f++)
       DosSleep(10);

    if(response->flags & ICQSR_DLGFLAG)
    {
       icqWriteSysLog(w->icq,PROJECT,"Timeout sending data to the search window");
       icqAbend(w->icq,0);
    }
 }

 int _System searchCallback(HICQ icq, ULONG uin, USHORT sequence, HWND hwnd, const ICQSEARCHRESPONSE *response)
 {
    SHRWINDOW *w = WinQueryWindowPtr(hwnd,0);

    DBGTracex(hwnd);
    DBGTracex(w);

    if(!w)
       return 1;

    DBGTrace(w->sz);
    DBGTracex(w->sz != sizeof(SHRWINDOW));

    if(w->sz != sizeof(SHRWINDOW))
       return 2;

    DBGTracex(response);

    if(response->id != sizeof(ICQSEARCHRESPONSE))
    {
       DBGMessage("Resposta invalida!!!!!!!");
       DBGTrace(response->id);
       DBGTrace(sizeof(ICQSEARCHRESPONSE));
       icqWriteSysLog(icq,PROJECT,"Unexpected search response (version conflict?)");
       return 3;
    }

    DBGTracex(response->flags);

    if(response->flags & ICQSR_BEGIN)
    {
       DBGMessage("Pesquisa iniciada");
       DBGTracex(hwnd);
       WinPostMsg(hwnd,WM_USER+13,(MPARAM)FALSE,(MPARAM)TRUE);
    }

    if(response->flags & ICQSR_END)
    {
       DBGMessage("Pesquisa terminada");
       DBGTracex(hwnd);
       WinPostMsg(hwnd,WM_USER+13,(MPARAM)TRUE,(MPARAM)FALSE);
    }

   if(response->sz)
       addResponse(w, hwnd, (ICQSEARCHRESPONSE *) response);

    return 0;
 }

 static void addResult(HWND hwnd, ICQSEARCHRESPONSE *blk)
 {
    /* Anexa uma nova entrada no container */
    SHRWINDOW 		*w 			= WinQueryWindowPtr(hwnd,0);
    ULONG		    bytes		= sizeof(RECORD)+blk->sz;
    HWND 		    h 			= WinWindowFromID(hwnd,ICQSHRC_CONTAINER);
    PRECORD		    rec;
    RECORDINSERT 	recordInsert;
    char		    *src    	= (char *) (blk);
    char		    *dst;
    int			    f;

    rec = WinSendMsg(h,CM_ALLOCRECORD,MPFROMLONG(bytes),MPFROMSHORT(1));
    DBGTracex(rec);

    if(!rec)
    {
       DBGMessage("Erro ao alocar registro para o container");
       return;
    }


    memset(rec,0,sizeof(RECORD));

    CHKPoint();

    dst = (char *) &rec->r;

    for(f=0;f<(blk->sz+sizeof(ICQSEARCHRESPONSE));f++)
       *(dst++) = *(src++);

    CHKPoint();

    /* Libera a outra thread */
    blk->flags &= ~ICQSR_DLGFLAG;
    blk = NULL;

    CHKPoint();

    rec->recordCore.cb 		= sizeof(RECORDCORE);              /*RBS*/

    rec->recordCore.pszText 	 =
    rec->recordCore.pszIcon 	 =
    rec->recordCore.pszName 	 =
    rec->nick			 = rec->r.text+rec->r.offset[0];
    rec->first			 = rec->r.text+rec->r.offset[1];
    rec->last			 = rec->r.text+rec->r.offset[2];
    rec->sex			 = w->text+w->offset[rec->r.sex % 3];
    rec->auth			 = w->text+w->offset[ rec->r.flags & ICQSR_ALWAYSAUTH ? 4 : 3 ];
    rec->age			 = (ULONG) rec->r.age;

    rec->recordCore.hptrIcon     =
    rec->recordCore.hptrMiniIcon =
    rec->mode			         = w->mode[rec->r.status % 3];

    DBGMessage(rec->nick);
    DBGMessage(rec->sex);

//    rec->recordCore.hptrIcon = hptr;

    memset(&recordInsert,0,sizeof(RECORDINSERT));
    recordInsert.cb 			= sizeof(RECORDINSERT);                   /*RBS*/
    recordInsert.pRecordParent		= NULL;
    recordInsert.pRecordOrder 		= (PRECORDCORE)CMA_END;
    recordInsert.zOrder 		= CMA_TOP;
    recordInsert.cRecordsInsert 	= 1;
    recordInsert.fInvalidateRecord 	= TRUE;

    WinSendMsg(h, CM_INSERTRECORD, (PRECORDCORE) rec, &recordInsert);

 }

 static void setButtons(HWND hwnd, SHRWINDOW *w)
 {
    HUSER	usr	= NULL;
    BOOL	status	= icqIsOnline(w->icq);

    DBGTracex(w);

#ifdef DEBUG
    status = TRUE;
#endif

    if(w->selected)
       usr = icqQueryUserHandle(w->icq,w->selected->uin);
    else
       status = FALSE;

    DBGTracex(usr);

    if(usr)
       WinEnableControl(hwnd,ICQSHRC_ADD,(usr->flags & (USRF_TEMPORARY|USRF_CACHED)) != 0);
    else
       WinEnableControl(hwnd,ICQSHRC_ADD,status);

    WinEnableControl(hwnd,ICQSHRC_ABOUT,status);
    WinEnableControl(hwnd,ICQSHRC_MESSAGE,status);

 }

 static void selected(HWND hwnd, PRECORD rec)
 {
    HWINDOW(hwnd,w);
    w->selected = &rec->r;
    setButtons(hwnd,w);
 }

 static void ctlContainer(HWND  hwnd, USHORT notify, ULONG info)
 {
    switch(notify)
    {
    case CN_ENTER:
       DBGMessage("CN_ENTER");
       break;
    case CN_EMPHASIS:
       DBGMessage("CN_EMPHASIS");
       DBGTracex(((PNOTIFYRECORDEMPHASIS) info)->fEmphasisMask & CRA_CURSORED );
       DBGTracex(((PNOTIFYRECORDEMPHASIS) info)->fEmphasisMask & CRA_INUSE    );
       DBGTracex(((PNOTIFYRECORDEMPHASIS) info)->fEmphasisMask & CRA_SELECTED );

       if(((PNOTIFYRECORDEMPHASIS) info)->fEmphasisMask & CRA_CURSORED )
          selected(hwnd,(PRECORD) ((PNOTIFYRECORDEMPHASIS) info)->pRecord);
       break;

    }

 }

 static void sendMessage(HICQ icq, const ICQSEARCHRESPONSE *rs)
 {
    HUSER usr = icqQueryUserHandle(icq,rs->uin);

    DBGTrace(rs->uin);

    if(!usr)
    {
#ifdef EXTENDED_LOG
       icqWriteSysLog(icq,PROJECT,"Caching search user to send message");
#endif
       usr = icqUpdateUserInfo(icq, rs->uin, FALSE, getSearchNickname(rs),
       						    getSearchFirstname(rs),
       						    getSearchLastname(rs),
       						    getSearchEMail(rs),
       						    rs->flags & ICQSR_ALWAYSAUTH ? FALSE : TRUE);

    }

    DBGMessage("Abrir caixa de mensagem");

    icqNewUserMessage(icq, rs->uin, 0, 0, 0);
 }

 static void openAboutUser(HICQ icq, const ICQSEARCHRESPONSE *rs)
 {
    char key[0x0100];
    char url[0x0180];

    icqLoadProfileString(icq, "MAIN", "aboutUserURL", aboutUserURL, key, 0xFF);

    sprintf(url,key,rs->uin);

    DBGMessage(key);
    DBGMessage(url);

    icqOpenURL(icq, url);

 }

 static void askForAuthorization(HICQ icq, const ICQSEARCHRESPONSE *rs)
 {
    HUSER usr = icqQueryUserHandle(icq,rs->uin);

    DBGTrace(rs->uin);

    if(!usr)
    {
       usr = icqUpdateUserInfo(icq, rs->uin, FALSE, getSearchNickname(rs),
       						    getSearchFirstname(rs),
       						    getSearchLastname(rs),
       						    getSearchEMail(rs),
       						    rs->flags & ICQSR_ALWAYSAUTH ? FALSE : TRUE);

    }

    if(!usr)
       return;

    if(rs->flags & ICQSR_ALWAYSAUTH)
    {
       icqAddUserInContactList(icq, rs->uin);
    }
    else
    {
       usr->flags |= USRF_WAITING;
       icqNewUserMessage(icq, rs->uin, MSG_REQUEST, 0, 0);
    }
 }

