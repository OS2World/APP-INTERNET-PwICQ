/*
 * icqgnome.c - Simple gnome applet for interaction with pwICQ
 */

// #include <config.h>

 #include <applet-widget.h>
 #include <gdk-pixbuf/gdk-pixbuf.h>

 #include <sys/time.h>

 #include <signal.h>

 #include <icqtlkt.h>
 #include <icqqueue.h>

// #define USE_BUTTON
 
/*---[ Macros ]-------------------------------------------------------------------------*/

 #define log(x) DBGMessage(x)

/*---[ Prototipes ]---------------------------------------------------------------------*/

 void onTimer(void);
 
 static void setpixmap(USHORT);
 static void setActive(BOOL);

#ifdef USE_BUTTON
 static void button_clicked(GtkWidget *, void *);
#else
 static gint chkEvent(GtkWidget *, GdkEvent *);
#endif 

 static void modeMenu(AppletWidget *, gpointer);
 static void terminateProgram(AppletWidget *, gpointer);

/*---[ Statics ]------------------------------------------------------------------------*/

 static ULONG		   uin				               = 0;
 
 static GtkWidget	   *applet						      = NULL;
 static GtkWidget	   *imagem        				   = NULL;
 
 static GdkPixmap	   *iPixmap[PWICQICONBARSIZE] 	= { NULL };
 static GdkBitmap    *iBitmap[PWICQICONBARSIZE] 	= { NULL };
 
 static const char	*description					   = "pwICQ Gnome Widget";
 static USHORT       szIcons						      = 0;
 
 static ICQSHAREMEM  *icq         				      = NULL;
 static ICQINSTANCE  *instance				         = NULL;
 
 static USHORT			icon   						      = 0xFFFF;
 
 static ULONG	      eventCounter				      = 0xffffffff;
 
 static const char   *modes[] = { "Online",
											 "Away",
											 "N/A",
	                               "Busy",
	                               "DND",
											 "Free for chat",
	                               "Offline",
	                               NULL
                                };
	  
 
/*---[ Implement ]----------------------------------------------------------------------*/

 int icqApplet_Initialize(void)
 {
 	 /* Inicializacao */
	 char				   buffer[0x0100];
    GdkPixbuf  		*icons;
    GdkPixbuf  		*work;
#ifdef USE_BUTTON
	  GtkWidget  		*button;
#endif	  

    struct itimerval	timer, 
    						otimer;

    int		   		f;
    int        		c;

    /* Carrega tabela de icones */
 	 
    icons = gdk_pixbuf_new_from_file("/usr/share/pwicq/images/icons.gif");
    DBGTracex(icons);

    szIcons = gdk_pixbuf_get_height(icons);

    work    = gdk_pixbuf_new(  gdk_pixbuf_get_colorspace(icons),
    						          gdk_pixbuf_get_has_alpha(icons), 
    						          gdk_pixbuf_get_bits_per_sample(icons),
    						          szIcons, szIcons);
        

    for(f=c=0;f<PWICQICONBARSIZE;f++)
    {
       gdk_pixbuf_copy_area (icons,c,0,szIcons,szIcons,work,0,0);
       gdk_pixbuf_render_pixmap_and_mask(work, &iPixmap[f], &iBitmap[f],1);
       c += szIcons;
    }

    gdk_pixbuf_unref(work);
    gdk_pixbuf_unref(icons);

    /* Cria o applet */
    applet = applet_widget_new("pwICQ-applet");
    
    if(!applet)
    {
    	 log("Unable to start applet widget");
       return -1;
    }

	 icon   = 10;
    imagem = gtk_pixmap_new( iPixmap[icon], iBitmap[icon]);
    gtk_widget_show(imagem);

#ifdef USE_BUTTON

    button = gtk_button_new();
    gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_NONE);

    gtk_container_add(GTK_CONTAINER(button),imagem);
    gtk_widget_show(button);

    gtk_signal_connect(GTK_OBJECT(button),  "clicked", GTK_SIGNAL_FUNC(button_clicked), NULL);
	 
    applet_widget_add(APPLET_WIDGET(applet), button);
	 
#else
	 
    gtk_signal_connect_object(GTK_OBJECT(imagem), "event", GTK_SIGNAL_FUNC(chkEvent),  NULL);
    applet_widget_add_full(APPLET_WIDGET(applet), imagem, TRUE);
	 
#endif	 

    applet_widget_register_callback_dir(APPLET_WIDGET(applet),"Main","Program");
    applet_widget_register_callback(APPLET_WIDGET(applet),"Main/Stop", "Shutdown", terminateProgram, NULL);

    applet_widget_register_callback_dir(APPLET_WIDGET(applet),"Modes","Set online mode");
    for(f=0;modes[f];f++)
	 {
	    sprintf(buffer,"Modes/%s",modes[f]);
		 for(c=6;buffer[c];c++)
		 {
		    if(buffer[c] == '/')
			    buffer[c] = '_';
		 }
       applet_widget_register_callback(APPLET_WIDGET(applet),buffer,modes[f], modeMenu, (gpointer) modes[f]);
	 }
	 
    timer.it_interval.tv_sec  =
    timer.it_value.tv_sec     = 0;
   
    timer.it_interval.tv_usec = 
    timer.it_value.tv_usec    = 100000L;

    signal(SIGALRM,(void *) onTimer);
    setitimer(ITIMER_REAL,&timer,&otimer);

    setActive(FALSE);
	 
    return 0;
 }


 int main(int argc, char **argv)
 {

    /* Initialize the i18n stuff */
/*    
    bindtextdomain(PROJECT, GNOMELOCALEDIR);
    textdomain(PROJECT);
*/    

    /* intialize, this will basically set up the applet, corba and call gnome_init */
    applet_widget_init(description, NULL, argc, argv, NULL,0,NULL);

    icqApplet_Initialize();
    
    /* special corba main loop */
    gtk_widget_show(applet);
    applet_widget_gtk_main ();

	if(icq)
	   icqIPCReleaseSharedBlock(icq);
	 
    return 0;
    
 }

 void onTimer(void)
 {
    if(!icq)
	{
	   /* Nao tem bloco de shared alocado, tenta obter um */
	   icq = icqIPCGetSharedBlock();
	}
	else if(!instance)
	{ 
		/* N�o tem bloco de instancia alocado, procura por um */
	   int f;
		
	   for(f = 0; f < PWICQ_MAX_INSTANCES && !instance; f++)
	   {
	      if( ((icq->i+f)->pid) && (!uin || (icq->i+f)->uin == uin) )
			{
	         instance = icq->i+f;
				eventCounter = instance->eventCounter -1;
		   }
	   }
		
		if(instance)
		{
	      setActive(TRUE);
	   }
		else
		{
			icqIPCReleaseSharedBlock(icq);
		   instance = NULL;
			icq      = NULL;
	      setActive(FALSE);
	   }
	}
	else if(!instance->pid)
   {
	   DBGMessage("pwICQ foi encerrado");
		instance = NULL;
		icqIPCReleaseSharedBlock(icq);
		icq = NULL;
		setActive(FALSE);
   }
	else if(instance->eventCounter != eventCounter)
	{
	   /* Ocorreu um evento, processo-o */
		setpixmap(instance->modeIcon);
		eventCounter = instance->eventCounter;
   }
 }

 static void setpixmap(USHORT code)
 {
    if(code == icon)
	    return;
    gtk_pixmap_set(GTK_PIXMAP(imagem),iPixmap[code],iBitmap[code]);
	 icon = code;
 }

#ifdef USE_BUTTON

 static void button_clicked(GtkWidget *widget, void *dunno)
 {
    CHKPoint();	  
 }	 

#else 
 
 static gint chkEvent(GtkWidget *widget, GdkEvent *event)
 {
 	  CHKPoint();
	 
     switch(event->type)
     {
     case GDK_BUTTON_PRESS:
	 	   CHKPoint();
         break;
       
     case GDK_2BUTTON_PRESS:
		   CHKPoint();
         break;
        
     default: 
        return FALSE;
       
     }
     return TRUE;
	 
 }

#endif
 
 static void setActive(BOOL modo)
 { 
	 char buffer[0x0100];
	  
    if(!modo)
	 {
       applet_widget_set_tooltip(APPLET_WIDGET(applet),"pwICQ is inactive");
	    setpixmap(10);
	 }
	 else if(instance && instance->uin)
	 {
	    sprintf(buffer,"ICQ# %ld",instance->uin);
       applet_widget_set_tooltip(APPLET_WIDGET(applet),buffer);
    }

	 applet_widget_callback_set_sensitive(APPLET_WIDGET(applet),"Modes/",modo);
	 applet_widget_callback_set_sensitive(APPLET_WIDGET(applet),"Main/",modo);
	 
 }
 
 static void modeMenu(AppletWidget *applet, gpointer mode)
{
   CHKPoint();	 
	DBGMessage( (char *) mode);

	if(!instance)
      return;

   icqIPCSetModeByName(instance->uin,(const char *) mode);
	 
}

static void terminateProgram(AppletWidget *applet, gpointer mode)
{
   if(instance)
      instance->pid = 0;
}
