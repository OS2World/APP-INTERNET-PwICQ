/*
 * kdepanel.cc - Cria um panel KDE para o pwICQ
 */

 #include <klocale.h>
 #include <kglobal.h>
 
 #include <pwmacros.h>
 #include <icqtlkt.h>

 #include "kdepanel.h"

/*---[ Implementacao ]---------------------------------------------------------------*/

 extern "C" 
 {
   KPanelApplet* init( QWidget *parent, const QString& configFile )
   {
       KGlobal::locale()->insertCatalogue( "pwICQApplet");

       return new pwICQApplet( configFile, KPanelApplet::Normal,
                                   0, parent, "pwICQApplet");
   }
 }

 
 pwICQApplet::pwICQApplet( const QString& configFile,
                                  Type type, int actions,
                                  QWidget *parent, const char *name )

   : KPanelApplet( configFile, type, actions, parent, name )

 {
   setBackgroundColor( blue );

   setFrameStyle( StyledPanel | Sunken );
 }

 int pwICQApplet::widthForHeight( int h ) const
 {
   return h; // we want to be quadratic
 }

 int pwICQApplet::heightForWidth( int w ) const
 {
   return w; // we want to be quadratic
 }

