/*
 * PLGCONF - Pagina de configuracao para o plugin
 */

#define INCL_WIN
#include <os2.h>

#include <stdio.h>

#include <icqplug.h>
#include <icqwin.h>

#include <pwMacros.h>

#include <icqtlkt.h>

#include "icqwdg.h"

/*---[ Definicoes ]-----------------------------------------------------------------*/

typedef struct _flag
{
   USHORT       id;
   ULONG        flag;
} FLAG;


/*---[ Constantes ]-----------------------------------------------------------------*/

static const FLAG       clsFlags[] =    {       105,    ICQMW_RIGHT,
                                                108,    ICQMW_TEXT,
                                                107,    ICQMW_ANIMATE,
                                                109,    ICQMW_BORDER,
                                                0,      0
                                        };

static const FLAG       evtFlags[] =    {       101,    WDG_SYSCHANGE,
                                                102,    WDG_USERONLINE,
                                                106,    WDG_MSGWAIT,
                                                111,    WDG_USEROFFLINE,
                                                0,      0
                                        };

/*---[ Prototipos ]-----------------------------------------------------------------*/

MRESULT EXPENTRY plgConfDlg(HWND, ULONG, MPARAM, MPARAM);
static void      saveConfig(HWND, DLGINFO *);
static void      loadConfig(HWND, DLGINFO *);

/*---[ Implementacao ]--------------------------------------------------------------*/

void EXPENTRY icqAddConfigPage(HICQ icq, HWND ntbk)
{
   /*
    * Add one page to the pwICQ's main configuration notebook
    */
   ICQMntDialog( ntbk, BKA_MAJOR, plgConfDlg, module, 1200, 1200);
}

/*---[ Implementacao ]--------------------------------------------------------------*/

MRESULT EXPENTRY plgConfDlg(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
{
   /* Dialog procedure */

   switch(msg)
   {
   case WMICQD_HANDLE:
      loadConfig(hwnd,PVOIDFROMMP(mp1));
      break;

   case WMICQ_SAVE:
      saveConfig(hwnd, WinQueryWindowPtr(hwnd,QWL_USER));
      break;

   case WMICQ_CANCEL:
      break;

   default:
      return WinDefDlgProc(hwnd,msg,mp1,mp2);
   }
   return 0;

}

static void loadConfig(HWND hwnd, DLGINFO *dlg)
{
   ULONG        vlr;
   const FLAG   *f;

   WinSetWindowPtr(hwnd,QWL_USER,dlg);

   vlr = ICQLoadLong(dlg->ctl, "icqMSTAT:Style", CLS_DEFAULT);
   for(f=clsFlags;f->id;f++)
   {
      if(vlr & f->flag)
         WinSendDlgItemMsg(hwnd,f->id,BM_SETCHECK,MPFROMSHORT(TRUE),(MPARAM)NULL);
      else
         WinSendDlgItemMsg(hwnd,f->id,BM_SETCHECK,MPFROMSHORT(FALSE),(MPARAM)NULL);
   }

   vlr = ICQLoadLong(dlg->ctl, "icqMSTAT:Events", WDG_DEFAULT);
   for(f=evtFlags;f->id;f++)
   {
      if(vlr & f->flag)
         WinSendDlgItemMsg(hwnd,f->id,BM_SETCHECK,MPFROMSHORT(TRUE),(MPARAM)NULL);
      else
         WinSendDlgItemMsg(hwnd,f->id,BM_SETCHECK,MPFROMSHORT(FALSE),(MPARAM)NULL);
   }

}

static void saveConfig(HWND dlgWin, DLGINFO *dlg)
{
   ULONG        vlr             = 0;
   const FLAG  *f;
   int          counter;

   if(hwnd)
      WinShowWindow(hwnd,FALSE);

   vlr = 0;
   for(f=evtFlags;f->id;f++)
      vlr |= WinQueryButtonCheckstate(dlgWin,f->id) ? f->flag : 0;
   ICQSaveLong(dlg->ctl, "icqMSTAT:Events", eventFlags = vlr);

   vlr = 0;
   for(f=clsFlags;f->id;f++)
      vlr |= WinQueryButtonCheckstate(dlgWin,f->id) ? f->flag : 0;
   ICQSaveLong(dlg->ctl, "icqMSTAT:Style", vlr);

   if(hwnd)
   {
      vlr |= ICQMW_DEFAULT;
      WinSendMsg(hwnd,WM_USER+109,MPFROMLONG(vlr),0);
      WinShowWindow(hwnd,TRUE);
   }
}



