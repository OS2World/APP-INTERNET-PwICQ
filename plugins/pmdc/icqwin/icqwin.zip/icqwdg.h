/*
 * ICQWDG.H - Definicoes para a mini-janela do pwICQ
 */

#define ICQMINIWINDOW "PWICQMINIWIN"

/*---[ Recursos ]----------------------------------------------------------------*/

#define PTR_OFFLINE     7
#define ICQMW_MAXTEXT   256

/*---[ Messages ]----------------------------------------------------------------*/

#ifdef WM_USER
   #define WM_ICQMWQUERYPOS     WM_USER+200             /* Query window pos */
   #define WM_ICQMWSETPOS       WM_USER+201             /* Set Window POS MP1=x,y */
   #define WM_ICQMWRESIZE       WM_USER+102     /* Force auto-resize */
#endif

/*---[ Styles ]------------------------------------------------------------------*/

#define ICQMW_LEFT      0x00000000      /* ICON at Left  */
#define ICQMW_RIGHT     0x00000002      /* ICON at Right */

#define ICQMW_BORDER    0x00000020      /* Draw border */
#define ICQMW_AUTO      0x00000040      /* Process mouse clicks without passing to owner */
#define ICQMW_MOVE      0x00000080      /* Move window on mouse-drag */
#define ICQMW_AUTOSIZE  0x00000100      /* Auto resize */
#define ICQMW_TEXT      0x00000200      /* Accept text */
#define ICQMW_FRAME     0x00000400      /* Move/Resize the frame window */
#define ICQMW_ANIMATE   0x00000800      /* Animate text */

#define ICQMW_DEFAULT   ICQMW_AUTO|ICQMW_FRAME|ICQMW_MOVE|ICQMW_AUTOSIZE

/*---[ Status ]------------------------------------------------------------------*/

#ifdef PLUGIN

   #define WDG_SYSCHANGE   0x00000001
   #define WDG_USERONLINE  0x00000002
   #define WDG_MSGWAIT     0x00000004
   #define WDG_USEROFFLINE 0x00000008

   #define WDG_DEFAULT     0x0000000F
   #define CLS_DEFAULT     ICQMW_RIGHT|ICQMW_TEXT|ICQMW_ANIMATE|ICQMW_BORDER

   extern HWND    hwnd;
   extern ULONG   eventFlags;
   extern HMODULE module;

   void   openMiniWindow(HICQ);

#endif

/*---[ Prototipes ]--------------------------------------------------------------*/

APIRET EXPENTRY icqRegisterMiniWindow(HAB);




