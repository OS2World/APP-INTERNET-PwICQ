/*
 * WINPLG.C - Modulo plugin para a mini-janela de status
 */

#define INCL_WIN
#define INCL_DOSPROCESS
#include <os2.h>

#include <stdio.h>
#include <string.h>

#include <pwicqapi.h>
#include <icqwin.h>
#include <icqplug.h>

#include <pwMacros.h>
#include <icqtlkt.h>

#include "icqwdg.h"

#define PROJECT "ICQMSTAT"

/*----------------------------------------------------------------------------*/

 static void mainThread(HICQ);
 static HWND _System createWindow(HICQ, HWND, void *);

/*----------------------------------------------------------------------------*/

 static ULONG   flags           = 0x00003;
 static HWND    frame           = NULLHANDLE;
 extern ULONG   eventFlags      = WDG_DEFAULT;

 extern HWND    hwnd            = NULLHANDLE;

/*----------------------------------------------------------------------------*/

 int EXPENTRY icqConfigure(HICQ icq, HMODULE mod)
 {
    /*
     *
     * PLUGIN configuration routine, the first called by pwICQ, if returns
     * nonzero the plugin is unloaded
     *
     */
    DBGMessage(PROJECT " loaded (Build " __DATE__ " " __TIME__ ")");

    module = mod;

    CHKPoint();
    icqWriteSysLog(icq, PROJECT " loaded (Build " __DATE__ " " __TIME__ ")");

    return 0;
 }

 void EXPENTRY icqInitialize(HICQ icq,HWND mainWin)
 {
    CHKPoint();
    DBGTracex(icq);

    if(!icqRegisterMiniWindow(WinQueryAnchorBlock(hwnd)))
    {
       icqWriteSysLog(icq, PROJECT ": Error registering mini status window");
       return;
    }

    openMiniWindow(icq);

    DBGTracex(hwnd);
    DBGMessage("Inicializacao completa");

 }

 void openMiniWindow(HICQ icq)
 {
    int f;

    eventFlags = ICQLoadLong(icq, "icqMSTAT:Events", eventFlags);

    ICQOpenWindow(icq, NULLHANDLE, HWND_DESKTOP, NULL, createWindow, &module);

    for(f=0;f<20 && hwnd == NULLHANDLE;f++)
       DosSleep(10);

 }

 void EXPENTRY icqTerminate(HICQ icq)
 {
    DBGTracex(hwnd);
 }

 void EXPENTRY icqSystemEvent(HICQ icq,short eventCode)
 {
    CHKPoint();
    DBGTracex(hwnd);

    if(hwnd && (eventFlags & WDG_SYSCHANGE) )
       WinPostMsg(hwnd,WM_USER+106,MPFROMP(icq),MPFROMSHORT(eventCode));
 }

 void EXPENTRY icqUserEvent(HICQ icq, HUSER usr, short eventCode)
 {

    CHKPoint();

    if(hwnd)
    {
       switch(eventCode)
       {
       case EVT_OFFLINE:
          if(eventFlags & WDG_USEROFFLINE)
             WinPostMsg(hwnd,WM_USER+105,MPFROMLONG(usr->uin),MPFROMSHORT(eventCode));
          break;

       case EVT_ONLINE:
          if(eventFlags & WDG_USERONLINE)
             WinPostMsg(hwnd,WM_USER+105,MPFROMLONG(usr->uin),MPFROMSHORT(eventCode));
          break;

       default:
          WinPostMsg(hwnd,WM_USER+105,MPFROMLONG(usr->uin),MPFROMSHORT(eventCode));
       }
    }
 }

 void EXPENTRY icqMessageChanged(HICQ ctl, ULONG uin, USRMSG *msg)
 {
    CHKPoint();

    if(hwnd && (eventFlags & WDG_MSGWAIT) )
    {
       if(msg)
          WinPostMsg(hwnd,WM_USER+107,MPFROMLONG(uin),MPFROMSHORT(msg->type));
       else
          WinPostMsg(hwnd,WM_USER+107,MPFROMLONG(uin),0);
    }
 }

 HWND _System createWindow(HICQ icq, HWND owner, void *lixo)
 {
    /*
     * Abre caixa de dialogo para edicao de dados de usu�rio
     */
   int    f;
   ULONG  ulFrameFlags  = FCF_TASKLIST|FCF_NOMOVEWITHOWNER|FCF_NOBYTEALIGN;
   ULONG  style         = ICQMW_DEFAULT;
   ULONG  uin           = icqQueryUin(icq);
   SWP    p;
   ULONG  pos;
   char   buffer[40];

   style |= ICQLoadLong(icq, "icqMSTAT:Style", CLS_DEFAULT);

   DBGTracex(icq);
   DBGTracex(owner);
   DBGTracex(lixo);

   frame = WinCreateStdWindow(  HWND_DESKTOP,
                                WS_VISIBLE|WS_TOPMOST,
                                &ulFrameFlags,
                                ICQMINIWINDOW,
                                "pwICQ - Mini Status",
                                style,
                                module,
                                100,
                                &hwnd
                             );

    DBGTracex(frame);

    if(!frame)
    {
       icqWriteSysLog(icq,PROJECT ": Error opening frame window");
       return frame;
    }
    else
    {
       icqWriteSysLog(icq,PROJECT ": Window created");
    }

    ICQLoadString(icq, PROJECT ":Font", 39, buffer, "8.Helv");
    WinSetPresParam(       hwnd,
                           PP_FONTNAMESIZE,
                           (ULONG) strlen(buffer)+1,
                           (PVOID) buffer);

    DBGTracex(hwnd);
    DBGTrace(uin);

    WinSendMsg(hwnd,WM_USER+100,MPFROMLONG(uin),0);
    WinQueryWindowPos(HWND_DESKTOP, &p);

    pos = ICQLoadLong(icq,PROJECT":pos",0xFFFFFFFF);

    DBGTracex(pos);

    if(pos != 0xFFFFFFFF)
       pos = LONGFROMMR(WinSendMsg(hwnd,WM_ICQMWSETPOS,MPFROMLONG(pos),0));

    DBGTrace(SHORT1FROMMR(pos));
    DBGTrace(SHORT2FROMMR(pos));

    if(SHORT1FROMMR(pos) < p.cx && SHORT2FROMMR(pos) < p.cy)
    {
       WinSetWindowPos(frame, 0, SHORT1FROMMR(pos), SHORT2FROMMR(pos), 22, 22, SWP_MOVE|SWP_SIZE);
    }
    else
    {
       if(style & ICQMW_RIGHT)
          WinSetWindowPos(frame, 0, p.cx-22, 25, 22, 22, SWP_MOVE|SWP_SIZE);
       else
          WinSetWindowPos(frame, 0, 0, 25, 22, 22, SWP_MOVE|SWP_SIZE);
    }

    WinSetWindowPos(frame, 0, 100, 2, 22, 22, SWP_ACTIVATE|SWP_SHOW);
    return hwnd; /* Retorna a janela de dados, ela interage com o sistema */
 }

 int EXPENTRY icqExternCMD(HICQ icq, int pid, char *text)
 {
    int conta = 300;

    if(hwnd && *text)
    {
       WinPostMsg(hwnd,WM_USER+108,MPFROMLONG(pid),MPFROMP(text));

       while(conta-- && *text)
          DosSleep(10);

       if(*text)
       {
          icqWriteSysLog(icq,PROJECT ": Timeout passing request to GUI");
          DosSleep(20);
          return -1;
       }

    }
    return 0;
 }


