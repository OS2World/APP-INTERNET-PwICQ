/*
 * ICQWIN.C - Programa principal para a mini-janela do pwICQ
 */

#define INCL_WIN
#define INCL_DOSMODULEMGR
#include <os2.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "icqwdg.h"
#include <pwMacros.h>

#ifndef PROJECT
   #define PROJECT "ICQWin"
#endif

#ifndef WS_TOPMOST
   #define WS_TOPMOST  0x00200000
#endif

/*---[ Definicoes ]--------------------------------------------------------------*/

typedef struct parmStyle
{
   char 	parm;
   ULONG	flag;
} PARMSTYLE;

/*---[ Variaveis estaticas ]-----------------------------------------------------*/

static HAB              hab;
static HMQ              hmq;
static QMSG             qmsg;
static HWND             hwnd    = NULLHANDLE;
static HWND             frame   = NULLHANDLE;
static HSWITCH          hswitch = NULLHANDLE;
static PID              pid;
static SWCNTRL          swctl;
static ULONG            uin     = 0;
static char             buffer[80];
static ULONG		style	= ICQMW_DEFAULT;

/*---[ Prototipos ]-----------------------------------------------------------*/

static void add2Tasklist(void);
static void createFrame(void);
static void processParm(int, char **);

/*---[ Implementacao ]--------------------------------------------------------*/

int main(int numpar, char *param[])
{
   DBGOpen("icqwin");
   DBGMessage(__DATE__ " " __TIME__);

   if(numpar > 1)
      processParm(numpar,param);

   if((hab = WinInitialize(0)) == NULLHANDLE)
      return -1;

   DBGTracex(hab);

   icqRegisterMiniWindow(hab);

   if((hmq = WinCreateMsgQueue(hab,0)) != NULLHANDLE)
   {
      DBGTracex(hmq);
      createFrame();

      if(hwnd != NULLHANDLE)
      {
         WinSetPresParam(       hwnd,
                                PP_FONTNAMESIZE,
                                (ULONG) 7,
                                (PVOID) "8.Helv");

         sprintf(buffer,"mini.%ld",uin);
         if(!WinRestoreWindowPos("pwICQ",buffer,frame))
            WinSetWindowPos(frame, 0, 100, 2, 22, 22, SWP_MOVE);

         WinSetWindowPos(frame, 0, 0, 0, 22, 22, SWP_SIZE|SWP_ACTIVATE);

         WinSetWindowText(hwnd,"pwICQ Mini Status");

         DBGTrace(uin);
         WinPostMsg(hwnd,WM_USER+100,(MPARAM) uin,0);
         while(WinGetMsg(hab,&qmsg,0,0,0))
            WinDispatchMsg(hab,&qmsg);

         WinSetWindowText(hwnd,"");
         sprintf(buffer,"mini.%ld",uin);
         WinStoreWindowPos("pwICQ",buffer,frame);
      }
   }

   WinTerminate(hab);

   return 0;
}

static void createFrame(void)
{
   /* Cria a janela principal, retorna o handle */
   ULONG  ulFrameFlags  =  FCF_TASKLIST|FCF_NOMOVEWITHOWNER|FCF_NOBYTEALIGN;

   if(!WinLoadString(hab, NULLHANDLE, 10,79, buffer))
   {
      DBGTracex(WinGetLastError(hab));
      return;
   }

   frame = WinCreateStdWindow(  HWND_DESKTOP,
                                WS_VISIBLE|WS_TOPMOST,
                                &ulFrameFlags,
                                ICQMINIWINDOW,
                                buffer,
                                style,
                                0,
                                100,
                                &hwnd
                             );

}

static void processParm(int numpar, char **param)
{
   static const PARMSTYLE	parmTable[] = {	'r',	ICQMW_RIGHT,
						't',	ICQMW_TEXT,
						'a',	ICQMW_ANIMATE,
						'b',	ICQMW_BORDER,
				  		0,	0
				      	      };
   const PARMSTYLE *p;				      	


   numpar--;
   do
   {
      param++;
      DBGMessage(*param);

      if(**param == '-' || **param == '/')
      {
         DBGTrace(numpar);
         (*param)++;

         switch(**param)
         {
         case 'u':
            if(numpar > 0)
            {
               param++;
               numpar--;
               uin = atol(*param);
            }
            break;

         default:
            for(p=parmTable;p->parm != **param && p->parm;p++);
            if(p->parm == **param)
               style |= p->flag;
         }
      }
      else
      {
         DBGPrint("Parametro invalido: %s",*param);
         DosBeep(3000,100);
      }
      DBGTrace(numpar);
   } while(--numpar);
}








