/*
 * ICQWIDGET.C - pwICQ Mini-Window
 */

#define INCL_WIN
#define INCL_GPILCIDS
#define INCL_GPIPRIMITIVES
#define INCL_DOSQUEUES
#define INCL_DOSMEMORY
#include <os2.h>

#include <stdio.h>
#include <string.h>

#include <pwicqdef.h>
#include <pwicqmem.h>
#include <icqwin.h>
#include <icqqueue.h>

#ifdef PLUGIN
   #include <pwicqdll.h>
   #include <icqplug.h>
#endif

#include <icqtlkt.h>

#include "icqwdg.h"
#include <pwmacros.h>

/*---[ Structures ]--------------------------------------------------------------*/

typedef struct event
{
   USHORT       code;
   int          string;
} EVENT;

typedef struct icontable
{
   ULONG        key;
   USHORT       icon;
} ICONTABLE;

typedef struct eventtable
{
   ULONG        key;
   USHORT       icon;
} EVENTTABLE;

typedef struct wdgdata
{
   HPOINTER     ptrStatus;
   HPOINTER     ptrEvent;
#ifdef PLUGIN
   HICQ         icq;
#else
   ICQSHAREMEM  *shmArea;
#endif
   ICQINFO      *info;
   ULONG        uin;
   ULONG        lastUIN;        /* The user related with the text */
   USHORT       timer;
   ULONG        mode;
   ULONG        dragPos;
   USHORT       eventCounter;
   USHORT       eventType;
   USHORT       cx;
   UCHAR        Animate;
   int          txtTimer;       /* Counter for the text time */
   int          txtTime;        /* The current text time */
   UCHAR        text[ICQMW_MAXTEXT+1];
} WDGDATA;


/*---[ Defini��es ]--------------------------------------------------------------*/

#ifndef DP_MINI
   #define DP_MINI 0x0004
#endif

#define _STEP_          8
#define _TEXTTIME_      20
#define _SIZE_          22
#define _TIMER2_        70
#define STORAGE sizeof(WDGDATA *)

/*---[ Publics ]-----------------------------------------------------------------*/

extern HMODULE          module          = NULLHANDLE;

/*---[ Prototipos ]--------------------------------------------------------------*/

static void             PaintWin(HWND);
static void             initialize(HWND,PCREATESTRUCT);
static void             setPointer(HWND,WDGDATA *,int);
static void             setEventPointer(HWND,WDGDATA *,int);
static void             configure(HWND,ULONG);
static void             terminate(HWND);
static void             loadInfoBlock(WDGDATA *, ULONG);
static void             ajustMode(HWND, WDGDATA *,ULONG);
static void             processTimer(HWND,USHORT);
static void             Button1Click(HWND,USHORT,USHORT);
static void             Button2Click(HWND);
static void             MoveWindow(HWND, SHORT, SHORT);
static HWND             getBaseWindow(HWND);
static void             ajustEventType(HWND, USHORT);
static void             beginDrag(HWND,ULONG);
static void             stopMove(HWND);
static BOOL             wndParms(HWND,PWNDPARAMS);
static void             autoResize(HWND);
static ULONG            border(HPS, ULONG, PRECTL, ULONG, ULONG, ULONG, ULONG);
static void             ajustPresParam(HWND,ULONG);
static void             Timer1(HWND, WDGDATA *);
static void             Timer2(HWND, WDGDATA *);
static void             openUser(HWND);
static void             setTextAndUIN(HWND, ULONG, PSZ);
static MRESULT          queryPos(HWND);
static MRESULT          setPos(HWND,USHORT,USHORT);
static void             systemEvent(HWND, USHORT);
static void             userEvent(HWND,ULONG,USHORT);
static void             messageStatus(HWND,ULONG,USHORT);
static void             procExternRequest(HWND, ULONG, char *);
static void             reconfig(HWND, ULONG);
static void             openMenu(HWND, ULONG);

#ifdef PLUGIN
   static void          setHandle(HWND,DLGINFO *);
   static void          sendAction(WDGDATA *,ULONG);
#else
   static APIRET        sendSingleCmd(WDGDATA *, ULONG, ULONG);
   static ICQSHAREMEM   *getMemBlock(HWND);
#endif

MRESULT EXPENTRY        icqMiniWindow(HWND, ULONG, MPARAM, MPARAM);

/*---[ Implementacao ]-----------------------------------------------------------*/


APIRET EXPENTRY icqRegisterMiniWindow(HAB hab)
{
   return WinRegisterClass(hab, ICQMINIWINDOW, icqMiniWindow, 0, STORAGE);
}

MRESULT EXPENTRY icqMiniWindow(HWND hwnd, ULONG ulMessage, MPARAM mp1, MPARAM mp2)
{
   switch(ulMessage)
   {
   case WM_CLOSE:
      DBGMessage("WM_CLOSE");
      WinSetWindowText(hwnd,"");
      return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);

   case WM_BUTTON1CLICK:
      Button1Click(hwnd,SHORT1FROMMP(mp1),SHORT2FROMMP(mp1));
      return (MRESULT) TRUE;

   case WM_BUTTON2CLICK:
      openMenu(hwnd, MNU_SETMODE);
      return (MRESULT) TRUE;

   case WM_BUTTON3CLICK:
      openMenu(hwnd, MNU_SYSTEM);
      return (MRESULT) TRUE;

   case WM_PAINT:
      PaintWin(hwnd);
      break;

   case WM_DESTROY:
      terminate(hwnd);
      return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);

   case WM_CREATE:
      initialize(hwnd,PVOIDFROMMP(mp2));
      return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);

   case WM_PRESPARAMCHANGED:
      ajustPresParam(hwnd,LONGFROMMP(mp1));
      break;

   case WM_TIMER:
       processTimer(hwnd,SHORT1FROMMP(mp1));
       break;

   case WM_USER+100:
      DBGTrace(LONGFROMMP(mp1));
      configure(hwnd,LONGFROMMP(mp1));
      break;

   case WM_USER+101:    /* Open window/menu in pwICQ's main program */
      DBGMessage("Open menu");
      #ifndef PLUGIN
         sendSingleCmd(WinQueryWindowPtr(hwnd,0),ICQCMD_ACTION,LONGFROMMP(mp1));
      #else
         sendAction(WinQueryWindowPtr(hwnd,0),LONGFROMMP(mp1));
      #endif
      break;

   case WM_ICQMWRESIZE:    /* Resize Window */
      if( (WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_AUTOSIZE) )
         autoResize(hwnd);
      WinInvalidateRect(hwnd,0,TRUE);
      break;

   case WM_USER+103:    /* Action based on the text */
      openUser(hwnd);
      break;

   case WM_USER+104:    /* Set text and UIN */
      setTextAndUIN(hwnd, LONGFROMMP(mp1), PVOIDFROMMP(mp2));
      break;

   case WM_USER+105:    /* User Event MP1=ULONG UIN MP2=USHORT CODE */
      DBGMessage("User event");
      userEvent(hwnd,LONGFROMMP(mp1),SHORT1FROMMP(mp2));
      break;

   case WM_USER+106:    /* System Event MP1 = HICQ MP2=USHORT CODE */
      DBGMessage("System event");
      systemEvent(hwnd, SHORT1FROMMP(mp2));
      break;

   case WM_USER+107:    /* Message changed MP1=UIN MP2=USHORT Message type */
      DBGMessage("Message changed");
      messageStatus(hwnd,LONGFROMMP(mp1),SHORT1FROMMP(mp2));
      break;

   case WM_USER+108:    /* Extern request MP1=PID, MP2=Text */
      procExternRequest(hwnd,LONGFROMMP(mp1),PVOIDFROMMP(mp2));
      break;

   case WM_USER+109:    /* Reconfigure MP1=Style */
      reconfig(hwnd,LONGFROMMP(mp1));
      break;

   case WM_ICQMWQUERYPOS:
      return MRFROMLONG(queryPos(hwnd));

   case WM_ICQMWSETPOS: /* Adjust window position MP1=x,y */
      DBGMessage("WM_ICQMWSETPOS");
      return setPos(hwnd,SHORT1FROMMP(mp1),SHORT2FROMMP(mp1));

   case WMICQD_HANDLE:
#ifdef PLUGIN
      setHandle(hwnd,PVOIDFROMMP(mp1));
      break;
#endif

/*
   case WMICQ_SYSTEM:
      DBGMessage("WMICQ_SYSTEM");
      ajustMode(hwnd, WinQueryWindowPtr(hwnd,0), LONGFROMMP(mp2));
      break;
*/

   case WM_BEGINDRAG:
      if( !(WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_MOVE) )
         return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);
      beginDrag(hwnd,(ULONG) mp1);
      return (MRESULT) TRUE;

   case WM_MOUSEMOVE:
      MoveWindow(hwnd,SHORT1FROMMP(mp1),SHORT2FROMMP(mp1));
      return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);

   case WM_ENDDRAG:
      DBGMessage("WM_ENDDRAG");
      stopMove(hwnd);
      break;

   case WM_SETWINDOWPARAMS:
      return (MRESULT) wndParms(hwnd, PVOIDFROMMP(mp1));

   default:
      return WinDefWindowProc(hwnd, ulMessage, mp1, mp2);

   }

  return 0;

}

static void initialize(HWND hwnd, PCREATESTRUCT info)
{
   /* Inicializa a janela */
   WDGDATA *ctl;

/*
typedef struct _CREATESTRUCT {
  PVOID     pPresParams;       //  Presentation parameters.
  PVOID     pCtlData;          //  Control data.
  ULONG     id;                //  Window identifier.
  HWND      hwndInsertBehind;  //  Window behind which the window is to be placed.
  HWND      hwndOwner;         //  Window owner.
  LONG      cy;                //  Window height.
  LONG      cx;                //  Window width.
  LONG      y;                 //  Y-coordinate of origin.
  LONG      x;                 //  X-coordinate of origin.
  ULONG     flStyle;           //  Window style.
  PSZ       pszText;           //  Window text.
  PSZ       pszClassName;      //  Registered window class name.
  HWND      hwndParent;        //  Parent window handle.
} CREATESTRUCT;
*/

   if(DosAllocMem((PPVOID) &ctl, sizeof(WDGDATA), PAG_WRITE|PAG_READ|PAG_COMMIT))
   {
      WinPostMsg(hwnd,WM_CLOSE,0,0);
      return;
   }

   memset(ctl,0,sizeof(WDGDATA));

   ctl->ptrStatus = WinLoadPointer(HWND_DESKTOP,module,1000);
   ctl->ptrEvent  = NULLHANDLE;

   ctl->timer     = 0;
#ifdef PLUGIN
   ctl->icq       = 0;
#else
   ctl->shmArea   = 0;
#endif

   ctl->txtTime   = _TEXTTIME_;

   ctl->info      = NULL;
   ctl->uin       = 0;

   ctl->dragPos   =
   ctl->mode      = 0xFFFFFFFF;

   if(info->pszText)
      strncpy(ctl->text,info->pszText,ICQMW_MAXTEXT);

   WinSetWindowPtr(hwnd,0,ctl);
   WinStartTimer(WinQueryAnchorBlock(hwnd), hwnd, 1, 900);
   WinPostMsg(hwnd,WM_USER+102,0,0);
}

static void terminate(HWND hwnd)
{
   WDGDATA *ctl = WinQueryWindowPtr(hwnd,0);

   WinStopTimer(WinQueryAnchorBlock(hwnd), hwnd, 1);

   if(!ctl)
      return;

   WinSetWindowPtr(hwnd,0,NULL);

   if(ctl->ptrStatus)
      WinDestroyPointer(ctl->ptrStatus);

   if(ctl->ptrEvent)
      WinDestroyPointer(ctl->ptrEvent);

#ifndef PLUGIN
   if(ctl->shmArea)
      DosFreeMem(ctl->shmArea);
#endif

   DosFreeMem(ctl);

}

static void PaintWin(HWND hwnd)
{
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   POINTL       p;
   RECTL        rcl;
   HPS          hps;
   ULONG        bg;
   ULONG        style   = WinQueryWindowULong(hwnd,QWL_STYLE);

   hps = WinBeginPaint(hwnd,NULLHANDLE,&rcl);

   WinQueryWindowRect(hwnd, &rcl);

   bg = border(hps, style, &rcl, CLR_DARKGRAY, CLR_BLACK, CLR_WHITE, CLR_BLACK);

   if(ctl->ptrStatus)
   {
      if(style & ICQMW_RIGHT)
      {
         p.x = rcl.xRight - 17;
         rcl.xRight -= 18;
      }
      else
      {
         p.x = 3;
         rcl.xLeft += 20;
      }

      if(ctl->ptrEvent)
      {
         if(ctl->timer&1)
            WinDrawPointer(hps, p.x, 3, ctl->ptrEvent, DP_MINI);
      }
      else
      {
         WinDrawPointer(hps, p.x, 3, ctl->ptrStatus, DP_MINI);
      }
   }

   if((style & ICQMW_TEXT) && ctl->text && rcl.xLeft < (rcl.xRight-2))
   {
      /* Escrever o texto */
      border(hps, style, &rcl, CLR_BLACK, CLR_DARKGRAY, CLR_BLACK, CLR_WHITE);
      rcl.xLeft++;
      WinDrawText(      hps,
                        -1,
                        ctl->text,
                        &rcl,
                        CLR_GREEN,
                        bg,
                        DT_LEFT|DT_VCENTER|DT_ERASERECT );
   }

   WinEndPaint(hps);

}

static ULONG border(HPS hps, ULONG style, PRECTL rcl, ULONG bg, ULONG border, ULONG c1, ULONG c2)
{
   POINTL       p;

   if(style & ICQMW_BORDER)
   {
      WinFillRect(hps, rcl, border);
      rcl->yBottom += 1;
      rcl->yTop    -= 2;
      rcl->xLeft   += 1;
      rcl->xRight  -= 1;
      WinFillRect(hps, rcl, bg);

      p.y = rcl->yTop;
      p.x = rcl->xRight-1;
      GpiMove(hps,&p);
      GpiSetColor(hps,c1);
      p.x = rcl->xLeft;
      GpiLine(hps,&p);
      p.y = rcl->yBottom;
      GpiLine(hps,&p);

      GpiSetColor(hps,c2);
      p.x = rcl->xRight-1;
      GpiLine(hps,&p);
      p.y = rcl->yTop;
      GpiLine(hps,&p);

      rcl->xLeft++;
      rcl->xRight--;
      rcl->yBottom++;

      bg = c2;
   }
   else
   {
      WinFillRect(hps, rcl, bg);
   }

   return bg;

/*
   POINTL       p;

   if(style & ICQMW_BORDER)
   {
      WinFillRect(hps, rcl, c1);

      rcl->yBottom += 2;
      rcl->yTop    -= 2;
      rcl->xLeft   += 1;
      rcl->xRight  -= 2;
      WinFillRect(hps, rcl, c2);

      p.y = rcl->yTop;
      p.x = rcl->xRight-1;
      GpiMove(hps,&p);
      GpiSetColor(hps,fg);
      p.x = rcl->xLeft;
      GpiLine(hps,&p);
      p.y = rcl->yBottom;
      GpiLine(hps,&p);

      GpiSetColor(hps,bg);
      p.x = rcl->xRight-1;
      GpiLine(hps,&p);
      p.y = rcl->yTop;
      GpiLine(hps,&p);

      return c2;
   }
   else
   {
      WinFillRect(hps, rcl, bg);
   }
   return bg;
*/
}


static void configure(HWND hwnd,ULONG uin)
{
   WDGDATA     *ctl     = WinQueryWindowPtr(hwnd,0);
   CHKPoint();
   DBGTrace(uin);
   loadInfoBlock(ctl,uin);
}

static void loadInfoBlock(WDGDATA *ctl, ULONG uin)
{
   int          f;
   ICQSHAREMEM  *shmArea;

   DBGTrace(uin);

   if(!ctl)
      return;

   ctl->uin = uin;
   DBGTrace(ctl->uin);

#ifdef PLUGIN

   if(!ctl->icq)
      return;

   ctl->info = icqQueryInfoBlock(ctl->icq);
   DBGTracex(ctl->info);

#else

   if(!ctl->shmArea)
      return;

   shmArea  = ctl->shmArea;

   if(uin)
      for(f=0;f<PWICQ_MAX_INSTANCES && shmArea->instance[f].uin != uin;f++);
   else
      for(f=0;f<PWICQ_MAX_INSTANCES && !shmArea->instance[f].uin;f++);

   if(f >= PWICQ_MAX_INSTANCES)
      return;

   if(uin && shmArea->instance[f].uin != uin)
      return;

   DBGTrace(shmArea->instance[f].uin);

   ctl->info = shmArea->instance+f;

#endif

   CHKPoint();

   ctl->uin  = ctl->info->uin;

   CHKPoint();
}

static void processTimer(HWND hwnd, USHORT timer)
{
   WDGDATA *ctl = WinQueryWindowPtr(hwnd,0);

   if(!ctl)
      return;

   switch(timer)
   {
   case 1:
      Timer1(hwnd,ctl);
      break;
   case 2:
      Timer2(hwnd,ctl);
      break;
   }
}

static void Timer2(HWND hwnd, WDGDATA *ctl)
{
   HWND         frame = getBaseWindow(hwnd);
   SWP          p;
   LONG         x;

   WinQueryWindowPos(frame, &p);

   x = p.cx;
   if(x > ctl->cx)
   {
      x -= _STEP_;
      if(x < ctl->cx)
         x = ctl->cx;
   }
   else if(x < ctl->cx)
   {
      x += _STEP_;
      if(x > ctl->cx)
         x = ctl->cx;
   }
   else
   {
      DBGMessage("Timer2 parado");
      WinStopTimer(WinQueryAnchorBlock(hwnd),hwnd,2);
      ctl->Animate  = FALSE;
      ctl->txtTimer = ctl->txtTime;
   }

   if(WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_RIGHT)
      p.x -= (x-p.cx);

   WinSetWindowPos(frame, 0, p.x, p.y, x, p.cy, SWP_MOVE|SWP_SIZE);
   WinInvalidateRect(hwnd,0,0);

}

static void Timer1(HWND hwnd, WDGDATA *ctl)
{
   ICQINFO *i;

   i = ctl->info;
   ctl->timer++;

   if(ctl->txtTimer)
   {
      ctl->txtTimer--;
      if(!ctl->txtTimer)
      {
         if(WinQueryWindowULong(hwnd,QWL_STYLE)&ICQMW_ANIMATE)
         {
            /* Ativar animacao para recolher */

            if(!ctl->Animate)
            {
               ctl->Animate = TRUE;
               WinStartTimer(WinQueryAnchorBlock(hwnd), hwnd, 2, _TIMER2_);
            }
            ctl->cx = _SIZE_;
         }
         else
         {
            /* Somente recolher */
            WinSetWindowText(hwnd,"");
         }
      }
   }

#ifdef PLUGIN

   if(!i)
      loadInfoBlock(ctl,ctl->uin);

   if(!i)
      return;
#else
   if(!i)
   {
      CHKPoint();
      if(getMemBlock(hwnd))
         configure(hwnd,ctl->uin);
      return;
   }

   if(i->uin != ctl->uin)
   {
      setPointer(hwnd,ctl,1000);
      loadInfoBlock(ctl,ctl->uin);
      return;
   }

#endif

   if(i->flags & PWICQ_SHM_ONLINE)
   {
      ajustMode(hwnd,ctl,i->mode);

      if(ctl->ptrEvent)
         WinInvalidateRect(hwnd,0,0);

   }
   else
   {
      ajustMode(hwnd,ctl,ICQ_STATUS);
   }

   if( (i->flags & PWICQ_SHM_LOCKED) && WinIsWindowShowing(hwnd))
      i->flags |= PWICQ_SHM_UNLOCK;

   if(i->eventType != ctl->eventType)
      ajustEventType(hwnd,ctl->eventType = i->eventType);

}

static void ajustMode(HWND hwnd, WDGDATA *ctl, ULONG mode)
{
   static const ICONTABLE tbl[] = {     ICQ_STATUS,     1002,
                                        ICQ_AWAY,       1003,
                                        ICQ_OCCUPIED,   1004,
                                        ICQ_DND,        1005,
                                        ICQ_FREECHAT,   1006,
                                        ICQ_PRIVACY,    1007,
                                        ICQ_NA,         1008,
                                        ICQ_ONLINE,     1001
                                  };
   const ICONTABLE      *ptr;

   mode &= ICQ_STATUS;

   if(mode == ctl->mode)
      return;

   ctl->mode = mode;

   for(ptr=tbl;ptr->key && ptr->key != mode;ptr++);

   setPointer(hwnd, ctl,ptr->icon);

}

static void setEventPointer(HWND hwnd, WDGDATA *ctl, int ptrID)
{
   if(ctl->ptrEvent)
      WinDestroyPointer(ctl->ptrEvent);

   if(ptrID)
      ctl->ptrEvent = WinLoadPointer(HWND_DESKTOP,module,ptrID);
   else
      ctl->ptrEvent = 0;

   WinInvalidateRect(hwnd,0,0);
}

static void setPointer(HWND hwnd, WDGDATA *ctl, int ptrID)
{
   if(ctl->ptrStatus)
      WinDestroyPointer(ctl->ptrStatus);

   if(ptrID)
      ctl->ptrStatus = WinLoadPointer(HWND_DESKTOP,module,ptrID);
   else
      ctl->ptrStatus = 0;

   WinInvalidateRect(hwnd,0,0);
}

static HWND getBaseWindow(HWND hwnd)
{
   if( (WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_FRAME) )
      return WinQueryWindow(hwnd, QW_PARENT);
   return hwnd;
}

static void stopMove(HWND hwnd)
{
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   if(ctl)
   {
      WinSetCapture(HWND_DESKTOP,NULLHANDLE);
      ctl->dragPos = 0xFFFFFFFF;
#ifdef PLUGIN
      if(ctl->icq)
         ICQSaveLong(ctl->icq,PROJECT":pos",LONGFROMMR(WinSendMsg(hwnd,WM_ICQMWQUERYPOS,0,0)));
#endif
   }
   WinInvalidateRect(hwnd,0,0);

}

static void MoveWindow(HWND hwnd, SHORT x, SHORT y)
{
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   POINTS       p;
   HWND         frame   = getBaseWindow(hwnd);
   SWP          swp;

   if(!ctl || ctl->dragPos == 0xFFFFFFFF)
      return;

   *( (ULONG *) &p ) = ctl->dragPos;

   x -= p.x;
   y -= p.y;

   if(!WinQueryWindowPos(frame, &swp))
      return;

   swp.x += x;
   swp.y += y;

   WinSetWindowPos(frame, 0, swp.x, swp.y, 0,0, SWP_MOVE);
}

static void openMenu(HWND hwnd, ULONG menu)
{
   USHORT id    = WinQueryWindowUShort(hwnd,QWS_ID);

   DBGTrace(menu);

   if( (WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_AUTO) != 0)
      WinPostMsg(hwnd,WM_USER+101,MPFROMLONG(menu),0);
}

/*
static void Button2Click(HWND hwnd)
{
   USHORT id    = WinQueryWindowUShort(hwnd,QWS_ID);

   if( (WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_AUTO) != 0)
      WinPostMsg(hwnd,WM_USER+101,MPFROMLONG(1),0);
}
*/

static void Button1Click(HWND hwnd,USHORT x,USHORT y)
{
   USHORT id            = WinQueryWindowUShort(hwnd,QWS_ID);
   ULONG  style         = WinQueryWindowULong(hwnd,QWL_STYLE);
   SWP    p;


   if( (style & ICQMW_AUTO) != 0)
   {
      DBGTrace(x);

      if( (style & ICQMW_TEXT) == 0)
      {
         WinPostMsg(hwnd,WM_USER+101,MPFROMLONG(100),0);
      }
      else
      {
         WinQueryWindowPos(hwnd, &p);

         if(style & ICQMW_RIGHT)
         {
            if(x > (p.cx-20))
               WinPostMsg(hwnd,WM_USER+101,MPFROMLONG(100),0);
            else
               WinPostMsg(hwnd,WM_USER+103,0,0);
         }
         else
         {
            if(x < 20)
               WinPostMsg(hwnd,WM_USER+101,MPFROMLONG(100),0);
            else
               WinPostMsg(hwnd,WM_USER+103,0,0);
         }
      }
   }
   else
   {
      WinPostMsg(       WinQueryWindow(hwnd, QW_OWNER),
                        WM_CONTROL,
                        MPFROM2SHORT(id,BN_CLICKED),
                        (MPARAM) hwnd);
   }
}

#ifdef PLUGIN

static void setHandle(HWND hwnd, DLGINFO *dlg)
{
   WDGDATA     *ctl     = WinQueryWindowPtr(hwnd,0);

   if(!ctl)
      WinPostMsg(hwnd,WM_CLOSE,0,0);

   ctl->icq = dlg->ctl;
}

static void sendAction(WDGDATA *ctl,ULONG action)
{
   DBGTracex(ctl);
   DBGTracex(ctl->icq);

   if(ctl && ctl->icq)
      WinPostMsg(icqQueryMainWindow(ctl->icq),WMICQ_ACTION,MPFROMLONG(action),0);
}

#else

static ICQSHAREMEM *getMemBlock(HWND hwnd)
{
   WDGDATA     *ctl     = WinQueryWindowPtr(hwnd,0);

   if(!ctl)
      return NULL;

   if(!ctl->shmArea)
   {
      if(DosGetNamedSharedMem((PPVOID) &ctl->shmArea,PWICQ_SHAREMEM,PAG_READ))
         return NULL;

      if(ctl->shmArea->Version != PWICQ_MEM_VERSION
                   && ctl->shmArea->szCheck != sizeof(ICQINFO)
                   && ctl->shmArea->szBlock != sizeof(ICQSHAREMEM))
         return NULL;

   }

   return ctl->shmArea;
}

static APIRET sendSingleCmd(WDGDATA *ctl, ULONG msg, ULONG cmd)
{
   PID       pid;
   HQUEUE    hq         = NULLHANDLE;
   APIRET    rc;
   char      wrk[0x0100];
   ICQINFO   *i;

   if(!ctl)
      return -1;

   i = ctl->info;

   DBGTracex(i);

   if(!i)
      return -1;

   sprintf(wrk,"\\QUEUES\\%d.ICQ",i->uin);
   DBGMessage(wrk);

   rc = DosOpenQueue(&pid, &hq, wrk);
   DBGTrace(rc);

   if(!rc)
   {
      rc = DosWriteQueue(hq,msg,0,(PVOID) cmd,0);
      DBGTrace(rc);
      DosCloseQueue(hq);
   }

   return rc;
}

#endif

static void ajustEventType(HWND hwnd, USHORT event)
{
   const EVENTTABLE        *ptr;
   static const EVENTTABLE tbl[] = {
                                        MSG_FILE,               2000, /* file.ptr */
                                        MSG_NORMAL,             2001, /* msg.ptr */
                                        MSG_PAGER,              2002, /* pager.ptr */
                                        MSG_URL,                2003, /* urlm.ptr */
                                        MSG_CHAT,               2004, /* chat.ptr */
                                        PWICQ_SHM_NOEVENT,      0
                                   };


   DBGMessage("Novo evento");

   for(ptr=tbl;ptr->key != PWICQ_SHM_NOEVENT && ptr->key != event;ptr++);

   setEventPointer(hwnd,WinQueryWindowPtr(hwnd,0),ptr->icon);
}

static void beginDrag(HWND hwnd,ULONG vlr)
{
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   if(ctl)
   {
      ctl->dragPos = vlr;
      WinSetCapture(HWND_DESKTOP,hwnd);
   }
}

static BOOL wndParms(HWND hwnd, WNDPARAMS *p)
{
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   BOOL         ret;

   CHKPoint();

   if(!ctl || p->fsStatus != WPM_TEXT)
      return FALSE;

   DBGMessage(p->pszText);

   if(p->pszText)
      strncpy(ctl->text,p->pszText,ICQMW_MAXTEXT);
   else
      p->pszText = 0;

   WinPostMsg(hwnd,WM_USER+102,0,0);
   ctl->txtTimer   = ctl->txtTime;

   return TRUE;
}

static void ajustPresParam(HWND hwnd, ULONG parm)
{
   if(parm == PP_FONTNAMESIZE)
   {
      autoResize(hwnd);
      WinInvalidateRect(hwnd,0,0);
   }
}

static void autoResize(HWND hwnd)
{
   /* Reajusta o tamanho da janela */
   WDGDATA      *ctl    = WinQueryWindowPtr(hwnd,0);
   HWND         frame   = getBaseWindow(hwnd);
   ULONG        style   = WinQueryWindowULong(hwnd,QWL_STYLE);
   LONG         sz      = _SIZE_;
   HPS          hps;
   RECTL        rcl;
   SWP          swp;
   LONG         cx;
   POINTL       aptl[TXTBOX_COUNT];

   if(!WinQueryWindowPos(frame, &swp) || !ctl)
      return;

   DBGTracex(frame);
   DBGTracex(hwnd);

   DBGMessage("Reajustar o tamanho da janela");
   WinQueryWindowRect(hwnd, &rcl);              /* Pega o tamanho da janela real, nao do frame */

   cx = rcl.xRight - rcl.xLeft;

   if((style & ICQMW_TEXT) && *ctl->text)
   {
      DBGMessage(ctl->text);

      hps = WinGetPS(hwnd);
      GpiQueryTextBox(  hps,
                        strlen(ctl->text),
                        (char *) ctl->text,
                        TXTBOX_COUNT,
                        aptl);
      WinReleasePS(hps);
      sz += (aptl[TXTBOX_TOPRIGHT].x - aptl[TXTBOX_TOPLEFT].x);
      sz += 10;

   }

   DBGTrace(sz);
   DBGTrace(cx);

   sz -= cx;
   DBGTrace(sz);

   if(!sz)
      return;   /* Nao alterou nada, retorna */

   swp.cx += sz;

   ctl->cx = swp.cx;

   if(style&ICQMW_ANIMATE)
   {
      if(!ctl->Animate)
      {
         ctl->Animate = TRUE;
         WinStartTimer(WinQueryAnchorBlock(hwnd), hwnd, 2, _TIMER2_);
      }
   }
   else
   {
      if(style&ICQMW_RIGHT)
         swp.x -= sz;

      WinSetWindowPos(frame, 0, swp.x, swp.y, swp.cx, swp.cy, SWP_SIZE|SWP_MOVE);

      if(*ctl->text)
         ctl->txtTimer = ctl->txtTime;

      WinInvalidateRect(hwnd,0,0);
   }

}

static void openUser(HWND hwnd)
{
   WDGDATA *ctl = WinQueryWindowPtr(hwnd,0);

   DBGTrace(ctl->lastUIN);

   if(!ctl || !ctl->lastUIN)
      return;

   /* Act as an enter in the ctl->lastUIN user */

#ifdef PLUGIN
   DBGTracex(ctl->icq);
   DBGTracex(ICQQueryUser(ctl->icq,ctl->lastUIN));

   if(ctl->icq)
      ICQUserClick(ICQQueryUser(ctl->icq,ctl->lastUIN), TRUE);
#endif


}

static void setTextAndUIN(HWND hwnd, ULONG uin, PSZ text)
{
   WDGDATA *ctl = WinQueryWindowPtr(hwnd,0);

   if(ctl)
      ctl->lastUIN = uin;

   WinSetWindowText(hwnd,text);
}

static MRESULT queryPos(HWND hwnd)
{
   WDGDATA      *ctl  = WinQueryWindowPtr(hwnd,0);
   HWND         frame = getBaseWindow(hwnd);
   SWP          p;

   if(!ctl)
      return 0;

   if(!WinQueryWindowPos(frame, &p))
      return 0;

   if(p.cx >= 22 && WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_RIGHT)
      p.x += (p.cx - 22);

   DBGTrace(p.x);
   DBGTrace(p.y);

   return MRFROM2SHORT(p.x,p.y);
}

static MRESULT setPos(HWND hwnd, USHORT x, USHORT y)
{
   WDGDATA      *ctl  = WinQueryWindowPtr(hwnd,0);
   HWND         frame = getBaseWindow(hwnd);
   SWP          p;

   if(!ctl)
      return MRFROMLONG(-1);

   DBGTrace(x);
   DBGTrace(y);

   if(!WinQueryWindowPos(frame, &p))
      return MRFROMLONG(-1);

   if(p.cx >= 22 && WinQueryWindowULong(hwnd,QWL_STYLE) & ICQMW_RIGHT)
      x -= (p.cx - 22);

   DBGTrace(x);
   DBGTrace(y);

   return MRFROM2SHORT(x,y);

}


static void systemEvent(HWND hwnd, USHORT event)
{
   static const EVENT tbl[]     = {     EVT_OFFLINE,    1000,
                                        EVT_CONNECT,    1001,
                                        EVT_CONTACT,    1002,
                                        EVT_STARTUP,    1003,
                                        0,              0
                                  };
   const EVENT  *ptr;
   char         buffer[80];

   DBGTracex(event);

   for(ptr=tbl;ptr->code && ptr->code != event;ptr++);

   DBGTrace(ptr->string);

   *buffer = 0;
   if(ptr->string)
   {
      *buffer = 0;
      WinLoadString(    WinQueryAnchorBlock(hwnd),
                        module,
                        ptr->string,
                        79,
                        buffer);
      DBGMessage(buffer);
      WinSendMsg(hwnd,WM_USER+104,0,MPFROMP(buffer));
   }
}

static void userEvent(HWND hwnd, ULONG uin, USHORT event)
{
   static const EVENT tbl[]     = {     EVT_ONLINE,     1050,
                                        EVT_OFFLINE,    1051,
                                        0,              0
                                  };
   const EVENT  *ptr;
   char         buffer[20];
   char         linha[70];
   WDGDATA      *ctl  = WinQueryWindowPtr(hwnd,0);

   DBGTracex(event);

   if(!ctl)
      return;

   for(ptr=tbl;ptr->code && ptr->code != event;ptr++);

   DBGTrace(ptr->string);

   if(ptr->string)
   {
      *buffer = 0;
      WinLoadString(    WinQueryAnchorBlock(hwnd),
                        module,
                        ptr->string,
                        19,
                        buffer);

      if(!*buffer)
         return;

      #ifdef PLUGIN
         sprintf(linha,buffer,ICQQueryUserNick(ICQQueryUser(ctl->icq,uin)));
         WinSendMsg(hwnd,WM_USER+104,MPFROMLONG(uin),MPFROMP(linha));
      /*
      #else

         *** Nesse ponto teria que pegar o nick do usuario - Ideias?

      */
      #endif


   }
}

static void messageStatus(HWND hwnd,ULONG uin, USHORT type)
{
   static const EVENT tbl[]     = {     MSG_NORMAL,     1100, /* Message from */
                                        MSG_URL,        1101, /* URL from */
                                        MSG_CHAT,       1102, /* Chat request from */
                                        MSG_FILE,       1103, /* File from */
                                        MSG_REQ,        1104, /* Authorization request from */
                                        MSG_ADD,        1105, /* Added from */
                                        MSG_AUTHORIZE,  1106, /* Authorized from */
                                        0,              0
                                  };
   const EVENT  *ptr;
   char         buffer[20];
   char         linha[70];
   WDGDATA      *ctl  = WinQueryWindowPtr(hwnd,0);

   DBGTracex(type);

   if(!ctl)
      return;

   for(ptr=tbl;ptr->code && ptr->code != type;ptr++);

   DBGTrace(ptr->string);

   if(ptr->string)
   {
      *buffer = 0;
      WinLoadString(    WinQueryAnchorBlock(hwnd),
                        module,
                        ptr->string,
                        19,
                        buffer);

      if(!*buffer)
         return;

      #ifdef PLUGIN
         sprintf(linha,buffer,ICQQueryUserNick(ICQQueryUser(ctl->icq,uin)));
      /*
      #else

         *** Nesse ponto teria que pegar o nick do usuario - Ideias?

      */
      #endif

      WinSendMsg(hwnd,WM_USER+104,MPFROMLONG(uin),MPFROMP(linha));

   }
}

static void procExternRequest(HWND hwnd, ULONG pid, char *txt)
{
   setTextAndUIN(hwnd,0,txt);
   *txt = 0;
}

static void reconfig(HWND hwnd,ULONG style)
{
   CHKPoint();
   WinSetWindowULong(hwnd,QWL_STYLE,style);
   WinInvalidateRect(getBaseWindow(hwnd),0,TRUE);
}

