/*
 * EXEC.C - Executa pacotes recebidos do servidor
 */

 #include <stdio.h>
 #include <string.h>
 #include <time.h>
 #include <stdlib.h>

 #include "icqv5.h"

/*---[ Tabela de fun�es ]---------------------------------------------------------------------------------*/

 typedef struct cmd
 {
    unsigned short code;
    void (* _System exec)(HICQ, int, void *);
 } CMD;

/*---[ Prototipos das funcoes especiais ]------------------------------------------------------------------*/

 static int  sendContactList(HICQ, USHORT, ULONG, char *, const char *);

/*---[ Prototipos das funcoes de atendimento ]-------------------------------------------------------------*/

 static void _System DoNothing(         HICQ, int, void *);
 static void _System LoginReply(        HICQ, int, LREPLY *);
 static void _System ReplyX1(           HICQ, int, void *);
 static void _System ExecX2(            HICQ, int, long *);
 static void _System UserOnline(        HICQ, int, ONLINE *);
 static void _System UserStatus(        HICQ, int, ULONG *);
 static void _System UserOffline(       HICQ, int, ULONG *);
 static void _System goAway(            HICQ, int, long *);
 static void _System tryAgain(          HICQ, int, long *);
 static void _System UserMsg(           HICQ, int, MSGHEADER *);
 static void _System SysMSG(            HICQ, int, SRVHEADER *);
 static void _System endSearch(         HICQ, int, void *);
 static void _System userFound(         HICQ, int, char *);

/*---[ Tabela de funcoes ]---------------------------------------------------------------------------------*/

 #define FPREFIX (void (* _System)(HICQ, int, void *))

 static const CMD cmd[] =
 {
    LOGIN_REPLY,        FPREFIX         LoginReply,
    REPLY_X1,           FPREFIX         ReplyX1,
    END_MESSAGES,       FPREFIX         ExecX2,
    USER_ONLINE,        FPREFIX         UserOnline,
    STATUS_UPDATE,      FPREFIX         UserStatus,
    USER_OFFLINE,       FPREFIX         UserOffline,
    USER_MESSAGE,       FPREFIX         UserMsg,
    RECEIVE_MESSAGE,    FPREFIX         SysMSG,
    KICKED_OFF,         FPREFIX         goAway,
    ICQ_RETRY,          FPREFIX         tryAgain,
    END_OF_SEARCH,      FPREFIX         endSearch,
    USER_FOUND,         FPREFIX         userFound,

    0, NULL
 };
//    RECEIVE_MESSAGE,    FPREFIX

/*---[ Implementacao ]-------------------------------------------------------------------------------------*/

 void procRecPacket(HICQ icq,INPACKET *pkt, int size)
 {
    const CMD *ptr = cmd;

#ifdef DEBUG
    if(pkt->command == MULTI_PACKET)
       DBGMessage("************* ENTROU PARA PROCESSAR DIRETO UM MPACKET!!!!");

    if(pkt->command == ACK)
       DBGMessage("************* ENTROU PARA PROCESSSAR UM ACK!!!!!");

#endif

    while(ptr->code)
    {
       if(ptr->code == pkt->command)
       {
          ptr->exec(icq,size-sizeof(INPACKET),(pkt+1));
          return;
       }
       ptr++;
    }

    DBGPrint("********** PACOTE DESCONHECIDO: %04x",pkt->command);

    if(icqPacket(icq, 5, pkt, size, 0, 0))
       return;

    icqDumpPacket(icq, NULL, "Unknown V5 packet received", size, (unsigned char *) pkt);

 }

 static void _System LoginReply(HICQ icq, int size, LREPLY *reply)
 {
     int        qtd;
     ULONG 	*onlineFlags = icqQueryOnlineFlags(icq);

     DBGMessage("Login confirmado");

     icqSystemEvent(icq,ICQEVENT_CONFIRMED);

     icqSetLocalIP(icq,reply->ip);
     icqSaveValue(icq,"lastServer",server);

     icqSystemEvent(icq,ICQEVENT_ONLINE);

     if(!(*onlineFlags&ICQF_CONTACTLIST))
     {
        /*
         * Transmite contact-lists
         *
         * ATENCAO: TEM QUE SER A ULTIMA COISA POIS REUTILIZA O BUFFER DE PACOTE RECEBIDO!!!
         *
         */
        *onlineFlags |= ICQF_CONTACTLIST;
        queuePacket(icq,LOGIN_1, NULL, 0);

        sendContactList(icq, CONTACT_LIST, USRF_LIST,      (char *) reply, "Contact-list");
        sendContactList(icq, VIS_LIST,     USRF_VISIBLE,   (char *) reply, "Visible-list");
        sendContactList(icq, INVIS_LIST,   USRF_INVISIBLE, (char *) reply, "Invisible-list");

    }

 }

 static int sendContactList(HICQ icq, USHORT cmd, ULONG flag, char *pkt, const char *txt)
 {
    HUSER u;

    int   qtd   = 0;
    int   max   = 0;
    ULONG *pos  = (ULONG *) (pkt+1);


    DBGMessage("*** ENVIANDO PACOTE COM A CONTACT-LIST ***");

    for(u = icqQueryFirstUser(icq);u;u = icqQueryNextUser(icq,u))
    {
       if( (u->flags & flag) )
       {
          *(pos++) = u->uin;

          if(++qtd == UDP_MAX_CONTACTS)
          {
             DBGTrace(qtd);
             max += qtd;

             *pkt = (char) qtd;
             queuePacket(icq, cmd, pkt, 1+(qtd*4));

             pos = (ULONG *)(pkt+1);
             qtd = 0;
          }
       }
    }

    DBGTrace(qtd);
    if(qtd)
    {
       max += qtd;
       *pkt = (char) qtd;
       queuePacket(icq, cmd, pkt, 1+(qtd * 4));
    }

    DBGMessage("*** CONTACT-LIST ENVIADA ***");

    if(max)
       sprintf(pkt,"%d users in the %s",max,txt);
    else
       sprintf(pkt,"No users in the %s",txt);

    icqWriteSysLog(icq,PROJECT,pkt);

    return max;

 }

 static void _System ReplyX1(HICQ ctl, int sz, void *uin)
 {
    DBGMessage("Contact-List confirmada");
 }

 static void _System ExecX2(HICQ ctl, int sz, long *uin)
 {
    /* Processo o reply X2, com um ACK_MESSAGES */
    ULONG rnd = rand();

    DBGMessage("Lista de mensagems completa");
    icqWriteSysLog(ctl,PROJECT,"Cleaning server's message list");
    queuePacket(ctl, ACK_MESSAGES, &rnd, 4);
 }

 static void _System UserOnline(HICQ icq, int sz, ONLINE *user)
 {
    DBGTracex(user->status);

    icqUserOnline(      icq,
                        user->uin,
                        user->status,
                        user->ip,
                        user->IP,
                        user->port,
                        user->TCPVersion,
                        user->BUILD_DATE );

 }

 static void _System UserStatus(HICQ icq, int sz, ULONG *ptr)
 {
    DBGMessage("Mudan�a de estado");
    DBGTrace(*ptr);
    DBGTracex( *(ptr+1));
    icqSetUserOnlineMode(icq, *ptr, *(ptr+1));
 }

 static void UserOffline(HICQ icq, int size, ULONG *uin)
 {
    icqSetUserOnlineMode(icq, *uin, ICQ_OFFLINE);
 }

 static void _System UserMsg(HICQ icq, int size, MSGHEADER *msg)
 {
    DBGTracex(msg->type);
    DBGTrace(size);
    DBGMessage( (msg+1) );

    icqInsertMessage(icq, msg->uin, msg->type, 0, size - sizeof(MSGHEADER), (const char *) (msg+1));
 }

 static void _System SysMSG(HICQ icq, int size, SRVHEADER *msg)
 {
    struct tm           t;
    char                *ptr = (char *) msg;

    DBGTracex(msg->type);
    DBGMessage( (msg+1) );

    memset(&t,0,sizeof(struct tm));

    t.tm_mday           = msg->day;         /* day of the month [1-31]                */
    t.tm_mon            = msg->month;       /* months since January [0-11]            */
    t.tm_year           = msg->year-1900;   /* years since 1900                       */

    t.tm_hour           = msg->hour;        /* hours since midnight [0-23]            */
    t.tm_min            = msg->minute;      /* minutes after the hour [0-59]          */

    icqInsertMessage(icq, msg->uin, msg->type, mktime(&t), size - sizeof(SRVHEADER), (const char *) (msg+1));

 }

 static void _System goAway(HICQ icq, int sz, long *uin)
 {
    icqWriteSysLog(icq,PROJECT,"Disconnecting by server request");
    icqSystemEvent(icq,ICQEVENT_GOAWAY);
    icqDisconnect(icq);

 }

 static void _System tryAgain(HICQ icq, int sz, long *uin)
 {
    icqWriteSysLog(icq,PROJECT,"Server requested to try again in a few minutes");
    icqSystemEvent(icq,ICQEVENT_RETRY);
    icqDisconnect(icq);
 }

 static void _System endSearch(HICQ icq, int sz, void *temp)
 {
    DBGMessage("Pesquisa completa");
    icqSystemEvent(icq,ICQEVENT_ENDSEARCH);
 }

 static void _System userFound(HICQ icq, int size, char *pkt)
 {
    ULONG       uin             = *( (ULONG *) pkt );
    char        *field[4];
    int         f;
    short       sz;

    DBGMessage("Informacao de usuario recebida");

    pkt += 4;
    sz  -= 4;

    for(f=0;f<4;f++)
    {
       sz = *( (short *) pkt);

       if(sz > size)
       {
          icqWriteSysLog(icq,PROJECT,"Unexpected size in user info packet");
          return;
       }
       *(pkt++) = 0;
       *(pkt++) = 0;

       icqConvertCodePage(icq, TRUE, pkt, sz);
       field[f] = pkt;

       pkt += sz;

       size -= (sz+2);
    }
/*
exec.c(308):    Draven
exec.c(309):    Eric
exec.c(310):    Draven
exec.c(311):    perryw@zaz.com.br
*/
    DBGMessage(field[0]);
    DBGMessage(field[1]);
    DBGMessage(field[2]);
    DBGMessage(field[3]);

    DBGTrace(size);
    DBGTrace(*pkt); /* 1 = No authorization required */

    icqUpdateUserInfo(icq, uin, FALSE, field[0], field[1], field[2], field[3], *pkt != '1');

 }

