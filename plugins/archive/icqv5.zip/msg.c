/*
 * MSG.C - Envio de mensagems
 */

 #define INCL_DOSPROCESS
 #include <icqkernel.h>
 #include <string.h>

 #include "icqv5.h"

/*---[ Prototipos ]---------------------------------------------------------------------------------------------*/

 static USHORT sendMessage2Server(HICQ, ULONG, USHORT, USHORT, UCHAR *, ULONG *);

/*---[ Implementacao ]------------------------------------------------------------------------------------------*/

 USHORT _System icqV5Message(HICQ icq, ULONG uin, USHORT type, UCHAR *txt, ULONG *id)
 {
    return sendMessage2Server(icq, uin, 0, type, txt, id);
 }

 static USHORT sendMessage2Server(HICQ icq, ULONG uin, USHORT cmd, USHORT type, UCHAR *txt, ULONG *id)
 {
    /* Envia mensagem direto ao servidor, coloca o pacote em ID */
    PACKET      *p;
    char        *ptr;
    int         sz;
    OUTPACKET   *out;
    SRVMSG      *msg;

    if(!cmd)
       cmd = icqQueryUserHandle(icq,uin) == NULL ? MSG_TO_NEW_USER : SEND_MESSAGE;

    if(id)
       *id = 0;

    if(!(icq->onlineFlags & ICQF_ONLINE))
       return 1;

    /* Substitui o separador pwICQ pelo separador Mirabilis V5 */

    for(ptr = txt;*ptr;ptr++)
    {
       if(*ptr == ICQ_FIELD_SEPARATOR)
          *ptr = 0xFE;
    }

    DBGMessage(txt);

    sz = strlen(txt)+1;

    if(sz > MSG_SERVER_SIZE)
       return 2;

    p = icqAddElement(c2sPackets,sizeof(OUTPACKET) + sizeof(PACKET) + sizeof(SRVMSG) + sz +5);

    if(!p)
    {
       icqWriteSysLog(icq,PROJECT,"Can't allocate memory for the packet queue");
       icq->ready = FALSE;
       return 3;
    }

    out = (OUTPACKET *) (p+1);
    msg = (SRVMSG *) (out+1);

    /* Formata a mensagem ----------------------------------------------------*/

    strcpy((char *)(msg+1),txt);

    msg->uin  = uin;
    msg->type = type;
    msg->size = sz;

    /* Protocola -------------------------------------------------------------*/
    out->version        = 0x05;

    out->command        = cmd;
    out->x1             = 0x00;
    out->uin            = icqQueryUIN(icq);
    out->session        = session;

    beginCriticalSection();
    p->seq              =
    out->aux_seq        = ++aux_seq;
    out->sequence       = ++sequence;
    endCriticalSection();

    /* Copia cabecalho antes de encriptar */
    p->size             = sz+sizeof(SRVMSG)+sizeof(OUTPACKET);

    /* Encripta  */
    out->checkcode      = checkcode( (char *) out, p->size);

    encript((char *) out, p->size, out->checkcode);

    /* Por �ltimo registra o comando para que a thread de envio possa processar */

    p->snd              =
    p->timer            = 0;
    p->cmd              = cmd;

    if(id)
       *id = (ULONG) p;

    return 0;
 }


