/*
 * USER.C - Fun��es de usuario para o protocolo V5
 */

 #include <icqkernel.h>

 #include "icqv5.h"

/*---[ Implementacao ]---------------------------------------------------------------------------------*/

 int _System requestUserInfo(HICQ icq, ULONG uin)
 {
    if(!(icq->onlineFlags & ICQF_ONLINE))
       return -1;

    DBGMessage("Requisitar informa��o de usu�rio");
    DBGTrace(uin);

    icqSystemEvent(icq,ICQEVENT_BEGINSEARCH);
    return queuePacket(icq, SEARCH_UIN, &uin, 4);
 }

 void _System addUser2List(HICQ icq, HUSER usr)
 {

    if(!(icq->onlineFlags & ICQF_ONLINE))
       return;

    queuePacket(icq, ADD_TO_LIST, &usr->u.uin, 4);

    if( (usr->u.flags & USRF_REFRESH) && !(icq->cntlFlags & ICQFC_SEARCHING) )
    {
       DBGMessage("Requisitar informacoes de usuario");
       icqSystemEvent(icq,ICQEVENT_BEGINSEARCH);
       queuePacket(icq, SEARCH_UIN, &usr->u.uin, 4);
    }

 }

 #pragma pack(1)
 struct userMode
 {
    USHORT      mode;
    USHORT      icon;
 };


 USHORT _System queryModeIcon(HICQ icq, ULONG mode)
 {
//                                                        0x01FF,  7,	// Offline

    const struct userMode        *ptr;
    const static struct userMode tbl[]          = {     0x0000,  5,     // Online
                                                        0x0008, 41,     // Aska.ru
                                                        0x0001,  6,     // Away
                                                        0x0005, 40,     // N/A
                                                        0x0004, 40,     // NA99A
                                                        0x0010, 12,     // Occupied (MAC)
                                                        0x0011, 12,     // Occupied
                                                        0x0013, 42,     // DND
                                                        0x0002, 42,     // DND (LICQ)
                                                        0x0020, 13,     // Free for chat
                                                        0x0100, 14,     // Invisible

                                                        0x0000,  0 };

    mode &= ICQ_STATUS;

    DBGTracex(mode);

    for(ptr = tbl; ptr->icon && ptr->mode != mode; ptr++);
    DBGTracex(ptr->icon);

    return ptr->icon ? ptr->icon : 5;


 }
