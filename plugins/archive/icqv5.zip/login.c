/* 
 * LOGIN.C - Envia o pacote de login 
 */ 
 
 #include <icqkernel.h> 
 
 #include <string.h> 
 #include <time.h> 
 #include <stdlib.h> 
 
 #include "icqv5.h" 
 
/*---[ Estruturas ]---------------------------------------------------------------------------------------*/ 
 
 #pragma pack(1) 
 typedef struct logonHeader 
 { 
    unsigned long        time;          // time(NULL), number of seconds since 1 January 1979 
    unsigned long        port;          // The port you will be listening for TCP connections on 
    unsigned short       size;          // Tamanho da senha 
 } LOGONHEADER;                         // 10 bytes 
 
/* 
 
       3f 01 0b 00             X1              nUnknown -> 0x000B013F 
       ac 11 15 f4             IP 
       04                      Flags           s_nMode 
       02 00 00 00             Status          m_nLogonStatus 
 
       06 00 00 00             TCP Version     m_nTcpVersion 
       00 00 00 00             X2              Always zero 
       02 00                   X3              Colin (ICQ99B) 
       3f 01                   X4 
       50 00 00 00             X5              Always the same 
       03 00 00 00             X6              Always the same 
       eb 03 80 7d             Build Date      LICQ_WITHSSL | INT_VERSION 
 
                               0x7D00 0000     = LICQ 
                               0x7D80 0000     = SSL 
 
                               0x0000 xxxx     = Versao 
 
 
       00 00 00 00             X7              Always zero 
       00 00 00 00             X8              Always zero 
 
 
*/ 
 
 
 
 
 typedef struct logonFooter 
 { 
    unsigned long        X1;             // Unknown, usually 3F 01 0B 00 
    unsigned long        ip;             // Our IP 
    char                 flags;          // Flags 0x01 = Firewall 0x02 = Proxy 0x04 = Enable TCP 
    unsigned long        status;         // Modo atual 
    unsigned long        TCPVersion;     //      User's TCPVersion 
 
    unsigned long        X2;             // Always zero 
 
    unsigned short       X3;             // 02 00 Colin (ICQ99B) 
    unsigned short       X4;             // 3F 01 
 
 
    unsigned long        X5;             // 50 00 00 00 Always the same 
    unsigned long        X6;             // 03 00 00 00 Always the same 
 
    unsigned long        BUILD_DATE;     // Program/Version ID 
 
    unsigned long        X7;             // Always zero 
    unsigned long        X8;             // Always zero 
 
 } LOGONFOOTER;                          // 37 bytes 
 
 #define VALUE_X1       0x000B013F 
 #define VALUE_X2       0x00000000 
 #define VALUE_X3       0x0002 
 #define VALUE_X4       0x013F 
 #define VALUE_X5       0x00000050 
 #define VALUE_X6       0x00000003 
 #define VALUE_X7       0x00000000 
 #define VALUE_X8       0x00000000 
 
 #define PROGRAM_ID     0x3b000000 
 
/*---[ Implementacao ]--------------------------------------------------------------------------------------*/ 
 
 int doLogin(HICQ icq, char *buffer) 
 { 
    LOGONHEADER *header         = (LOGONHEADER *) (buffer); 
    LOGONFOOTER *footer; 
    int         sz; 
    ULONG       *onlineFlags    = icqQueryOnlineFlags(icq); 
 
    CHKPoint(); 
 
    memset(header,0,sizeof(LOGONHEADER)); 
 
    retry          =  icqLoadValue(icq,"retry",MAX_RETRIES); 
    kplTimer       =  0; 
    *onlineFlags   |= ICQF_CONNECTING; 
 
    header->time   =  time(NULL); 
    session        =  random(); 
    aux_seq        =  random() & 0xFFFF; 
 
    header->size   = strlen(icq->pwd)+1; 
    strcpy((char *) (header+1),icq->pwd); 
 
    footer        = (LOGONFOOTER *) ( ((char *)(header+1)) + header->size ); 
    memset(footer,0,sizeof(LOGONFOOTER)); 
 
    footer->X1    = VALUE_X1; 
    footer->ip    = icqGetHostID(); 
 
   /* O correto aqui seria ajustar o modo de acordo com a configuracao */ 
   footer->status    = icq->currentMode; 
 
   DBGTracex(footer->status); 
   if(footer->status == ICQ_OFFLINE) 
      return -1; 
 
    /* Os campos abaixo tem que ser obtidos direto com o plugin de comunicacao TCP */ 
    header->port         = icq->c2sPort; 
    footer->TCPVersion   = 0x00000006;  // 0x00000006; 
 
    /* Ajusta flags */ 
    if(header->port) 
       footer->flags |= 4; 
 
    /* Ajusta o final do pacote */ 
    footer->X2           = VALUE_X2; 
    footer->X3           = VALUE_X3; 
    footer->X4           = VALUE_X4; 
    footer->X5           = VALUE_X5; 
    footer->X6           = VALUE_X6; 
    footer->X7           = VALUE_X7; 
    footer->X8           = VALUE_X8; 
 
    footer->BUILD_DATE   = PROGRAM_ID;          // Identifica como pwICQ 
    footer->BUILD_DATE  |= PWICQVERSIONID;      // Versao atual 
 
    // Os ultimos bits do identificador identificam o sistema operacional 
    #ifdef linux 
       footer->BUILD_DATE |= 0x00000001; 
    #endif 
 
    #ifdef __OS2__ 
       footer->BUILD_DATE |= 0x00000002; 
    #endif 
 
    #ifdef BEOS 
       footer->BUILD_DATE |= 0x00000004; 
    #endif 
 
    #ifdef __WIN32__ 
       footer->BUILD_DATE |= 0x00000008; 
    #endif 
 
    DBGTracex(footer->BUILD_DATE); 
 
    c2sIdle = 0; 
 
    *onlineFlags &= ~ICQF_STARTING; 
 
    sz = header->size+sizeof(LOGONHEADER)+sizeof(LOGONFOOTER); 
 
#ifdef DEBUG 
    icqDumpPacket(icq, NULL, "Login packet", sz, (unsigned char *) header); 
#endif 
 
    queuePacket(icq, LOGIN, header, sz); 
 
    return 0; 
 
 } 
 
 
