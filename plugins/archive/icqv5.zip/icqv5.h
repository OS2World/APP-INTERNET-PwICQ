/*
 * ICQV5.H - Prototipos e definicoes para o plugins de protocolo cliente/server
 */

 #include <icqtlkt.h>
 #include <icqreserved.h>

 #include <pwMacros.h>

 // #define NO_RANDOM_NUMBERS

 #ifndef PROJECT
    #define PROJECT "C2SV5"
 #endif

 #ifdef __OS2__
    #define random rand
 #endif

/*---[ Definicoes ]-----------------------------------------------------------------------*/

 #define BUFFERSIZE            1024
 #define RETRY_TIMER             10
 #define MAX_RETRIES              6
 #define MSG_SERVER_SIZE        350   /* Max. send_thru_server message size     */

/*---[ Mensagems ]------------------------------------------------------------------------*/

 #define ACK              0x000A        // Acknowledgement

 #define GO_AWAY          0x00f0        // "You aren't online, quit sending me messages!"

 // User->Server
 #define SEND_MESSAGE     0x010E        // Send message through server (to offline user)
 #define LOGIN            0x03E8        // Login on server
 #define CONTACT_LIST     0x0406        // Inform the server of my contact list
 #define SEARCH_UIN       0x041A        // Search for user using his/her UIN
 #define SEARCH_USER      0x0424        // Search for user using his/her name or e-mail
 #define KEEP_ALIVE       0x042E        // Sent to indicate connection is still up
 #define KEEP_ALIVE2      0x051E        // Sent to indicate connection is still up
 #define SEND_TEXT_CODE   0x0438        // Send special message to server as text
 #define LOGIN_1          0x044C        // Sent during login (Ready for offline messages)
 #define INFO_REQ         0x0460        // Request basic information about a user
 #define EXT_INFO_REQ     0x046A        // Request extended information about a user
 #define CHANGE_PASSWORD  0x049C        // Change the user's password
 #define STATUS_CHANGE    0x04D8        // User has changed online status (Away etc)
 #define LOGIN_2          0x0528        // Sent during login
 #define UPDATE_INFO      0x050A        // Update my basic information
 #define UPDATE_EXT_INFO  0x04B0        // Update my extended information
 #define ADD_TO_LIST      0x053C        // Add user to my contact list
 #define REQ_ADD_TO_LIST  0x0456        // Request authorization to add to contact list
 #define QUERY_SERVERS    0x04BA        // Query the server about address to other servers
 #define QUERY_ADDONS     0x04C4        // Query the server about globally defined add-ons
 #define NEW_USER_1       0x04EC        // Ask for permission to add a new user
 #define NEW_USER_REG     0x03FC        // Register a new user
 #define NEW_USER_INFO    0x04A6        // Send basic information about a new user
 #define MSG_TO_NEW_USER  0x0456        // Send a message to a user not on my contact list
 #define ACK_MESSAGES     0x0442        // Confirm offline messages
 #define UPDATE_AUTH      0x0514        // Update authorization mode

 #define VIS_LIST         0x06ae
 #define INVIS_LIST       0x06a4
 #define LISTMAINT        0x06b8
 #define WEBPRESENCE_1    0x064a
 #define WEBPRESENCE_2    0x04d8

 #define META_USER        0x064A

 // Server->User
 #define LOGIN_REPLY      0x005A        // Login reply
 #define USER_ONLINE      0x006E        // User on contact list is online/has changed online status
 #define USER_OFFLINE     0x0078        // User on contact list has gone offline
 #define USER_FOUND       0x008C        // User record found matching search criteria
 #define RECEIVE_MESSAGE  0x00DC        // Message sent while offline/through server
 #define END_OF_SEARCH    0x00A0        // No more USER_FOUND will be sent
 #define USER_MESSAGE     0x0104        // Message sent to user through server
 #define INFO_REPLY       0x0118        // Return basic information about a user
 #define EXT_INFO_REPLY   0x0122        // Return extended information about a user
 #define STATUS_UPDATE    0x01A4        // User on contact list has changed online status (Away etc)
 #define REPLY_X1         0x021C        // *Unknown (Done Contact list)
 #define END_MESSAGES     0x00E6
 #define UPDATE_REPLY     0x01E0        // Confirmation of basic information update
 #define UPDATE_FAILURE   0x01EA        // Basic information update failed
 #define UPDATE_EXT_REPLY 0x00C8        // Confirmation of extended information update
 #define NEW_USER_UIN     0x0046        // Confirmation of creation of new user and newly assigned UIN
 #define NEW_USER_REPLY   0x00B4        // Confirmation of new user basic information
 #define QUERY_REPLY      0x0082        // Response to QUERY_SEVERS or QUERY_ADDONS
 #define SYSTEM_MESSAGE   0x01C2        // System message with URL'ed button
 #define BAD_PASSWORD     0x0064        // Bad Password

 #define UPDATE_AUT_OK    0x01F4        // Authorization update ok
 #define UPDATE_AUT_FAIL  0x01FE        // Authorization update fail

 #define BASIC_NOT_FOUND  0x012c        // Basic info not found (user doesn't exist?)
 #define META_RESPONSE    0x03de

 #define REJECTED         0x003C        // Servidor nao te quer aqui
 #define KICKED_OFF       0x0028        // Server tells you that you are now offline (sent if you don't ACK a message after 3 tries)
 #define ICQ_RETRY        0x00fa        // Already on line, try again later
 #define FORCE_DISCONNECT 0x0028
 #define MULTI_PACKET     0x0212

/*---[ Online/offline modes ]-------------------------------------------------------------*/

   #define ICQ_OFFLINE            0xFFFFFFFF       /* Offline                             */
   #define ICQ_ONLINE             0x00000000       /* Online                              */
   #define ICQ_AWAY               0x00000001       /* Away                                */
   #define ICQ_NA                 0x00000005       /* N/A (Extended away)                 */
   #define ICQ_NA99A              0x00000004
   #define ICQ_ASKA_RU            0x00000008       /* Online (ASKA.RU)                    */
   #define ICQ_BUSY               0x00000010       /* Occupied (Mac)                      */
   #define ICQ_OCCUPIED           0x00000011       /* Occupied (Urgent MSGs only)         */
   #define ICQ_DND                0x00000013       /* Do not Disturb                      */
   #define ICQ_DND2               0x00000002       /* Do not Disturb (LICQ)               */
   #define ICQ_FREECHAT           0x00000020       /* Available for chat                  */
   #define ICQ_PRIVACY            0x00000100       /* Privacy (Invisible)                 */


   #define ICQ_STATUS             0x000001FF       /* Mode filter masc                    */
   #define ICQ_WEBPRESENCE        0x00010000       /* WebPresence status                  */
   #define ICQ_HIDEIP             0x00020000
   #define ICQ_PHONEBUSY          0x00040000
   #define ICQ_BIRTHDAY           0x00080000
   #define ICQ_SOCKS              0x00100000       /* Using NAT/Socks                     */
   #define ICQ_WEBSERVER          0x00200000       /* Webserver indicator                 */
   #define ICQ_WEBBIE             0x01000000       /* ICQ Webbie indicator                */

   #define ICQ_KNOWMODES          0x013F01FF       /* Reserved                            */



/*---[ Formatos de pacote ]---------------------------------------------------------------*/

  #pragma pack(1)

  typedef struct InPacket
  {
     unsigned short  version;   // Protocol version
     char            x1;        // Unknown
     unsigned long   session;   // Same as in your login packet.
     unsigned short  command;   // Code for service the server should provide
     unsigned short  aux_seq;   // Starts at random number
     unsigned short  sequence;  // Starts at 1
     unsigned long   uin;       // Destination UIN
     unsigned long   checkcode; // Check-code
  } INPACKET;

  typedef struct OutPacket
  {
     unsigned short version;    // Identifies the packet as an ICQ packet
     unsigned long  x1;         // Just zeros, purpouse unknow
     unsigned long  uin;
     unsigned long  session;
     unsigned short command;    // Code for service the server should provide
     unsigned short aux_seq;    // Starts at random number
     unsigned short sequence;   // Starts at 1
     unsigned long  checkcode;  // Check-code
  } OUTPACKET;

  typedef struct ackpkt
  {
     OUTPACKET           o;
     unsigned long       r;
  } ACKPKT;

  typedef struct packet
  {
     char               timer;
     char               confirm;        // Se diferente de 0 envia evento de confirmacao
     ULONG              uin;            // Usuario a quem confirma
     char               snd;
     unsigned short     cmd;
     unsigned short     seq;
     int                size;
  } PACKET;

  typedef struct lreply
  {
      unsigned long  x1;
      unsigned short x2;
      unsigned short x3;
      unsigned short x4;
      unsigned short x5;
      unsigned long  ip;
      unsigned long  x6;
  } LREPLY;

  typedef struct msgheader               // Mensagem enviada via servidor
  {
     unsigned long  uin;
     unsigned short type;
     unsigned short size;
  } MSGHEADER;

 typedef struct srvheader               // Mensagem enviada enquanto offline
 {
    unsigned long       uin;            // The sending user's UIN
    unsigned short      year;           // The year the message was sent
    unsigned char       month;          // The month the message was sent
    unsigned char       day;            // The day of the month the message was sent
    unsigned char       hour;           // The hour the message was sent in GMT
    unsigned char       minute;         // The minute the message was sent
    unsigned short      type;           // The type of message (message, URL, etc)
    unsigned short      size;           // Length of MESSAGE including NULL
 } SRVHEADER;

 typedef struct online                  // USER_ONLINE (6E 00)  User on contact list is online/has changed online status
 {
    unsigned long       uin;            // UIN fo the user who changed status
    unsigned long       ip;             // The User's IP address
    unsigned long       port;           // The port the user is listening for connections on
    unsigned long       IP;             // User's real IP address
    unsigned char       x1;             // Unknow, usually 04
    unsigned long       status;         // User's status
    unsigned long       TCPVersion;     // User's TCP Version
    unsigned long       x3;
    unsigned long       x4;
    unsigned long       x5;
    unsigned long       x6;
    unsigned long       BUILD_DATE;
  } ONLINE;

  typedef struct srvmsg
  {
     long        uin;    // UIN of the user the message is sent to
     USHORT      type;   // Type of message being sent
     USHORT      size;   // Length of MESSAGE including NULL
  } SRVMSG;

  #define UDP_MAX_CONTACTS 99

/*
  typedef struct cntlist
  {
     UCHAR       qtd;
     ULONG       item[UDP_MAX_CONTACTS+1];
  } CONTACTLIST;
*/

/*---[ Estrutura de controle ]------------------------------------------------------------*/

/*
  typedef struct _icqv5
  {
     HLIST      c2sPackets;
     char       kplTimer;
     long       server;
     ULONG      session;
     USHORT     aux_seq;
     USHORT     sequence;
     USHORT     c2sIdle;
     int        retry;
     ULONG      c2sLastRec;

  } ICQV5;

  extern ICQV5 *icqv5;
*/
 extern HLIST      c2sPackets;
 extern	char       kplTimer;
 extern ULONG      session;
 extern USHORT     aux_seq;
 extern USHORT     sequence;
 extern long	   server;
 extern USHORT	   c2sIdle;
 extern int	   retry;

/*---[ Prototipos ]-----------------------------------------------------------------------*/

  ULONG  _System        setMode(HICQ,ULONG);
  void   _System        udpListener(ICQTHREAD *);
  int    _System        requestUserInfo(HICQ, ULONG);
  USHORT _System        icqV5Message(HICQ, ULONG, USHORT, UCHAR *, ULONG *);
  void   _System        addUser2List(HICQ,HUSER);
  USHORT _System        queryModeIcon(HICQ, ULONG);


  void                  decodePacket(HICQ, int, int, INPACKET *);

  int _System           queuePacket(HICQ, unsigned short, void *, int);
  PACKET *              insertPacket(HICQ, unsigned short, void *, int, BOOL);
  int                   sendPacket(HICQ,int);
  int                   doLogin(HICQ,char *);
  void                  ackPacket(HICQ, int, INPACKET *);

  int                   confirmPacket(HICQ,int,INPACKET *);

  void                  udpLoop(HICQ, char *);
  void                  procRecPacket(HICQ,INPACKET *,int);

  void                  encript(unsigned char *, int, unsigned long);
  unsigned long         checkcode(unsigned char *, short);

  BOOL                  chkVersion(HICQ);



