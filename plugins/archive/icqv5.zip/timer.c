/*
 * TIMER.C - Timer para reenvio de pacotes
 */


 #include <pwMacros.h>

 #include <string.h>

 #include "icqv5.h"
 #include <icqplugins.h>

/*---[ Prototipos ]-------------------------------------------------------*/

 static void PkTimeout(HICQ, PACKET *);

/*---[ Implementacao ]----------------------------------------------------*/

 void EXPENTRY icqv5_Timer(HICQ icq)
 {
    PACKET *p = icqQueryFirstElement(c2sPackets);

    if(p)
       p->timer++;

    kplTimer++;
 }


