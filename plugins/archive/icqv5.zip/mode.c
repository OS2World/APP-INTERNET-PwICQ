/*
 * MODE.C - Ajusta o modo de conexao atual
 */

 #include <stdio.h>
 #include <time.h>
 #include <stdlib.h>
 #include <string.h>

 #include <icqkernel.h>

 #include "icqv5.h"

 /*---[ Estruturas ]---------------------------------------------------------------------------------------*/

 #pragma pack(1)
 typedef struct logonHeader
 {
    unsigned long        time;   // time(NULL), number of seconds since 1 January 1979
    unsigned long        port;   // The port you will be listening for TCP connections on
    unsigned short       size;   // Tamanho da senha
 } LOGONHEADER;                  // 10 bytes


 typedef struct logonFooter
 {
    unsigned long        x1;             // Unknown, usually d5 00 00 00
    unsigned long        ip;             // Our IP
    char                 flags;          // Flags 0x01 = Firewall 0x02 = Proxy 0x04 = Enable TCP
    unsigned long        status;         // Modo atual
    unsigned long        TCPVersion;     //      User's TCPVersion
    unsigned long        x3;             // Unknown, usually 00 00 00 00
    unsigned long        x4;             // Unknown, usually 08 00 d5 00
    unsigned long        x5;             // Unknown, usually 50 00 00 00
    unsigned long        x6;             // Unknown, usually 03 00 00 00
    unsigned long        BUILD_DATE;     // Program/Version ID
 } LOGONFOOTER;                          // 37 bytes

 /*---[ Prototipos ]---------------------------------------------------------------------------------------*/

 static void _System mainThread(ICQTHREAD *);

 /*---[ Implementacao ]------------------------------------------------------------------------------------*/

 ULONG _System setMode(HICQ icq, ULONG mode)
 {
    DBGTracex(mode);
    DBGTracex(icq->onlineFlags);

    if(mode == ICQ_OFFLINE)
    {
       return mode;
    }
    else if(!(icq->srvcStatus & ICQSRVC_C2S))
    {
       icq->currentMode = mode;
       icqCreateThread(icq, &udpListener, 8192, BUFFERSIZE, NULL, "c2s");
    }

    if( !(icq->onlineFlags&ICQF_ONLINE) )
    {
       DBGMessage("Tentou mudar o modo antes de estar online");
       return icq->currentMode;
    }

    DBGMessage("Enviar pacote de mudanca de modo");

    queuePacket(icq, STATUS_CHANGE, &mode, 4);

    return mode;
 }


