/* 
 * DECODE.C - Decodifica um pacote recebido, envia ACK se necessario 
 */ 
 
 #include <stdio.h> 
 
 #include <icqkernel.h> 
 
 #include "icqv5.h" 
 
/*---[ Pacotes especiais ]---------------------------------------------------------------------*/ 
 
 #pragma pack(1) 
 typedef struct v3packet 
 { 
    USHORT      version; 
    USHORT      cmd; 
    ULONG       x1; 
    ULONG       uin; 
    ULONG       x2; 
 } V3PACKET; 
 
/*---[ Prototipos ]----------------------------------------------------------------------------*/ 
 
 static void v3Packet(HICQ, int, int, V3PACKET *); 
 static void v5Packet(HICQ, int, int, INPACKET *); 
 static void unpackPacket(HICQ, int, INPACKET *, int); 
 
/*---[ Implementacao ]-------------------------------------------------------------------------*/ 
 
 static ULONG c2sLastRec = 0xFFFFFFFF;

 void decodePacket(HICQ icq, int sock, int sz, INPACKET *pkt) 
 { 
    c2sIdle = 0; 
 
    switch(pkt->version) 
    { 
    case 0x02: 
       icqDumpPacket(icq, NULL, "Unexpected version 2 packet received", sz, (unsigned char *) pkt); 
       break; 
 
    case 0x03: 
       v3Packet(icq,sock,sz, (V3PACKET *) pkt); 
       break; 
 
    case 0x05: 
       v5Packet(icq,sock,sz,pkt); 
       break; 
 
    default: 
       icqDumpPacket(icq, NULL, "Unexpected packet received", sz, (unsigned char *) pkt); 
    } 
 
 } 
 
 static void v5Packet(HICQ icq, int sock, int sz, INPACKET *pkt) 
 { 
    ULONG seq; 
 
    if(pkt->session != session) 
    { 
       icqWriteSysLog(icq,PROJECT,"Invalid session number received from server"); 
       sendPacket(icq,sock); /* Envia mais um da lista */ 
       return; 
    } 
 
    if(pkt->uin != icq->uin) 
    { 
       sprintf( (char *) pkt,"Received packet for ICQ#%d",pkt->uin); 
       icqWriteSysLog(icq,PROJECT, (char *) pkt); 
       sendPacket(icq,sock); /* Envia mais um da lista */ 
       return; 
    } 
 
    if(pkt->command == ACK) 
    { 
       /* Servidor confirmou o pacote, retiro-o da fila */ 
       confirmPacket(icq,sock,pkt); 
       return; 
    } 
 
    ackPacket(icq,sock,pkt); 
 
    /* Verifico se o pacote ja chegou */ 
 
    seq = pkt->sequence; 
    seq <<= 16; 
    seq |= ((ULONG) pkt->aux_seq); 
 
    if(c2sLastRec == seq) 
    { 
       return; 
    } 
 
    c2sLastRec = seq; 
 
    if(pkt->command == MULTI_PACKET) 
    { 
       unpackPacket(icq,sock,pkt,sz); 
       sendPacket(icq,sock); /* Envia mais um da lista */ 
       return; 
    } 
 
    procRecPacket(icq,pkt,sz); 
 
    sendPacket(icq,sock); /* Envia mais um da lista */ 
 
 } 
 
 static void unpackPacket(HICQ icq, int sock, INPACKET *pkt, int size) 
 { 
    char *ptr = (char *) (pkt+1); 
    int  qtd  = (int) *ptr; 
    int  sz; 
 
    size -= sizeof(INPACKET); 
    ptr++; 
 
    while(qtd--) 
    { 
       sz   = *( (short *) ptr ); 
       ptr += 2; 
 
       if(sz > size) 
       { 
          icqWriteSysLog(icq,PROJECT,"Bad size detected in multi-packet"); 
          return; 
       } 
       size -= sz; 
 
       if( ((INPACKET *) ptr)->command == ACK) 
          confirmPacket(icq, sock, (INPACKET *) ptr); 
       else 
          procRecPacket(icq,(INPACKET *) ptr,sz); 
 
       ptr += sz; 
    } 
 } 
 
 static void v3Packet(HICQ icq, int sock, int sz, V3PACKET *pkt) 
 { 
    DBGTrace(pkt->x1); 
    DBGTrace(pkt->x2); 
    DBGTrace(pkt->uin); 
    DBGTracex(pkt->cmd); 
 
    if(pkt->cmd == BAD_PASSWORD) 
    { 
       icqWriteSysLog(icq,PROJECT,"Invalid password"); 
       icq->currentMode = ICQ_OFFLINE; 
       icqWarning(icq,NULL,ICQMSG_INVALIDPASSWORD); 
       return; 
    } 
 
    icqDumpPacket(icq, NULL, "Unexpected version 3 packet received", sz, (unsigned char *) pkt); 
 
 } 
 
 
 
