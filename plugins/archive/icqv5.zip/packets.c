/*
 * PACKETS.C - Gerenciador de pacotes
 */

 #define INCL_DOSPROCESS
 #include <stdlib.h>

 #include <icqtlkt.h>

 #include "icqv5.h"

/*---[ Prototipos ]-------------------------------------------------------------------------------------------*/


/*---[ Implementacao ]----------------------------------------------------------------------------------------*/

 int _System queuePacket(HICQ icq, unsigned short cmd, void *pkt, int size)
 {
    return insertPacket(icq, cmd, pkt, size, TRUE) != NULL;
 }

 PACKET * insertPacket(HICQ icq, unsigned short cmd, void *pkt, int size, BOOL seq)
 {
    PACKET      *p;
    OUTPACKET   *out;
    ULONG       rValue;
    int         rc;
#ifdef __IBMC__
    int f;
    char *s, *d;
#endif

    if(!pkt)
    {
       rValue = random();
       size   = 4;
       pkt    = &rValue;
    }

    p = icqAddElement(c2sPackets,size + sizeof(OUTPACKET) + sizeof(PACKET) + 5);
    if(!p)
    {
       icqWriteSysLog(icq,PROJECT,"Can't allocate memory for the packet queue");
       icqAbend(icq,0);
       return NULL;
    }
    out = (OUTPACKET *)(p+1);

#ifdef __IBMC__
    s = (char *) (out+1);
    d = (char *) pkt;
    for(f=0;f<size;f++)
       *(s++) = *(d++);
#else
    memcpy( (out+1), pkt, size);
#endif

    /* Protocola */
    out->version        = 0x05;

    out->command        = cmd;
    out->x1             = 0x00;
    out->uin            = icqQueryUIN(icq);
    out->session        = session;

    beginCriticalSection();

    p->seq              =
    out->aux_seq        = ++aux_seq;

    if(seq)
       out->sequence    = ++sequence;
    else
       out->sequence   = 0;

    endCriticalSection();

    /* Copia cabecalho antes de encriptar */
    p->size           = size+sizeof(OUTPACKET);

    /* Encripta  */
    out->checkcode      = checkcode( (char *) out, p->size);

    encript((char *) out, p->size, out->checkcode);


    /* Por �ltimo registra o comando para que a thread de envio possa processar */
    p->cmd              = cmd;

    p->snd              =
    p->timer            = 0;

    return p;
 }

 int confirmPacket(HICQ icq, int sock, INPACKET *pkt)
 {
    PACKET              *p;
    short               cmd;
    int                 rc;
//    ULONG		*onlineFlags	= icqQueryOnlineFlags(icq);

    DBGPrint("ACK do pacote %u recebido",pkt->aux_seq);

    for(        p = icqQueryFirstElement(c2sPackets);
                p && p->seq != pkt->aux_seq;
                p = icqQueryNextElement(c2sPackets,p) );

    if(p)
    {
       /* Pacote foi confirmado */
#ifdef DEBUG
       if(p->seq != pkt->aux_seq)
          DBGMessage("********************* ERRO NA PESQUISA DE PACOTES");
       DBGPrint("Comando %04x confirmado",p->cmd);
#endif
       cmd = p->cmd;

       if(p->confirm)
          icqProcessServerConfirmation(icq, p->uin, (ULONG) p);

       icqRemoveElement(c2sPackets,p);

       /* Processa uma confirmacao de pacote */
       switch(cmd)
       {
       case STATUS_CHANGE:
          icqWriteSysLog(icq,PROJECT,"Online mode changed");
          break;

       case ACK_MESSAGES:
	  icqSystemEvent(icq,ICQEVENT_LOGONCOMPLETE);
          break;

       case LOGIN:
//          *onlineFlags |= ICQF_CONTACTED;
          kplTimer     = 0;
          icqWriteSysLog(icq,PROJECT,"Server contacted");
          icqSystemEvent(icq,ICQEVENT_CONTACT);
          break;

       case LOGIN_1:
          icqWriteSysLog(icq,PROJECT,"System online");
          icqSystemEvent(icq,ICQEVENT_ONLINE);
//          *onlineFlags &= ~ICQF_CONNECTING;
//          *onlineFlags |= ICQF_ONLINE;
          break;

       case CONTACT_LIST:
          icqWriteSysLog(icq,PROJECT,"Contact-list confirmed");
          break;

       case VIS_LIST:
          icqWriteSysLog(icq,PROJECT,"Visible-list confirmed");
          break;

       case INVIS_LIST:
          icqWriteSysLog(icq,PROJECT,"Invisible-list confirmed");
          break;

       }
    }

    /* Transmite o primeiro pacote da fila */
    if(!sendPacket(icq,sock))
       icqSystemEvent(icq, ICQEVENT_PLISTCLEAR);

    return 0;
 }


