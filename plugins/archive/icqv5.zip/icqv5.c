/*
 * ICQV5.C - Modulo de gerenciamento de protocolo UDP versao 5 para o pwICQ
 */

 #include <time.h>
 #include <stdlib.h>
 #include <icqtlkt.h>
 #include <string.h>

 #include <icqplugins.h>

 #include "icqv5.h"

/*---[ Statics ]-----------------------------------------------------------------------------*/

 static ICQMODETABLE mTable[] = {       ICQ_ONLINE,     5,      "Online",
                                        ICQ_AWAY,       6,      "Away",
                                        ICQ_NA,        40,      "N/A",
                                        ICQ_OCCUPIED,  12,      "Busy",
                                        ICQ_DND,       42,      "DND",
                                        ICQ_FREECHAT,  13,      "Free for chat",
                                        ICQ_PRIVACY,   14,      "Invisible",
                                        ICQ_OFFLINE,    7,      "Offline",

                                        0,              0,      NULL
                             };


 static const C2SPROTMGR caps = {       sizeof(C2SPROTMGR),
                                        0x05,
                                        MSG_SERVER_SIZE,
                                        mTable,
                                        setMode,
                                        queuePacket,
                                        requestUserInfo,
                                        icqV5Message,
                                        addUser2List,
                                        queryModeIcon };


/*---[ Prototipos ]--------------------------------------------------------------------------*/

/*---[ Implementacao ]-----------------------------------------------------------------------*/

 int EXPENTRY icqv5_Configure(HICQ icq, HMODULE module)
 {
#ifdef DEBUG
    icqWriteSysLog(icq,PROJECT,"Loading ICQ Version 5 protocol manager " __DATE__ " " __TIME__ " (Debug Version)");
    icqGetHostID();
#else
    icqWriteSysLog(icq,PROJECT,"Loading ICQ Version 5 protocol manager Build " BUILD);
#endif

//    memset(&icqv5,0,sizeof(ICQV5));

    if(!chkVersion(icq))
       return 1;

//    if(!icqCheckIPStackVersion(icq))
//       return 2;

    if(!icqRegisterServerProtocolManager(icq,&caps))
    {
       icqWriteSysLog(icq,PROJECT,"Can't register V5 protocol manager");
       return 3;
    }

    srand(time(NULL));

    return 0;
 }

 int EXPENTRY icqv5_Start(HICQ icq, HWND hwnd)
 {
#ifdef NO_RANDOM_NUMBERS
    char   buffer[0x0100];
    ULONG  f;

    for(f=0;f<0x0100;f++)
       buffer[f] = f;

    f = checkcode(buffer, 0xFF);
    DBGTracex(f);

    if(f  != 0xc734659a)
       DBGMessage("************************* CHECKCODE INESPERADO!!!!!!!!");

#endif
    icqWriteSysLog(icq,PROJECT,"Client<->Server V5 protocol manager started");
    icqReconnect(icq);
    return 0;
 }




