/*
 * ULISTEN.C - Loop de escuta do servidor
 */

 #define INCL_DOSPROCESS

 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>

 #include <icqkernel.h>

 #include "icqv5.h"

/*---[ Prototipos ]----------------------------------------------------------------------------*/

 static void mainLoop(HICQ,char *);
 static int  initialize(HICQ,char *);
 static int  timeout(HICQ, PACKET *);
 static int  cantSend(HICQ, int);
 static void sendDisconnectPkt(int, HICQ, char *);

/*---[ Variaveis estaticas ]-------------------------------------------------------------------*/ 
 
 HLIST      c2sPackets	= NULL;
 char       kplTimer	= 0;
 USHORT     c2sIdle	= 0;
 int        retry	= 0;
 long       server	= 0;
 ULONG      session	= 0;
 USHORT     aux_seq	= 0;
 USHORT     sequence	= 0;

 
/*---[ Implementacao ]-------------------------------------------------------------------------*/

 BOOL chkVersion(HICQ icq)
 {
    if(icq->sz != sizeof(ICQ))
    {
       icqWriteSysLog(icq,PROJECT,"Invalid pwICQ core detected");
       return FALSE;
    }
    return TRUE;
 }

 void _System udpListener(ICQTHREAD *t)
 {
    DBGMessage("Thread de comunicacao UDP iniciada");

    icqSetServiceStatus(t->icq,ICQSRVC_C2S, TRUE);

    mainLoop(t->icq,(char *)(t+1));

    icqSetServiceStatus(t->icq,ICQSRVC_C2S, FALSE);

    DBGMessage("Thread de comunicacao UDP terminada");
 }

 static void mainLoop(HICQ icq, char *buffer)
 {
    /* Loop de comunicacao servidor<->Cliente */
    int 	sock;
    int 	sz;
    ULONG	*onlineFlags	= icqQueryOnlineFlags(icq);

    sock = initialize(icq,buffer);
    if(sock < 0)
       return;

    icqSystemEvent(icq, ICQEVENT_CONNECTING);

    c2sPackets  = icqCreateList();

    icqSetC2SPort(icq,icqGetPort(sock));

    DBGTrace(icq->c2sPort);

#ifdef __OS2__
    DosSetPriority(PRTYS_THREAD,PRTYC_TIMECRITICAL,PRTYD_MINIMUM,0);
#endif

    /* Envia pacote de login */
    doLogin(icq,buffer);

    /* Fica em loop escutando pacotes */
    DBGMessage("Loop de recepcao iniciado");
    sz = icqRecv(sock,buffer,BUFFERSIZE);
    while(icq->ready && sz >= 0 && icq->currentMode != ICQ_OFFLINE)
    {

       if(sz)
          decodePacket(icq,sock,sz,(INPACKET *) buffer);
       else
          sendPacket(icq,sock);

       if(kplTimer > 120)
       {
          kplTimer = 0;
          if(*onlineFlags&ICQF_ONLINE)
          {
             DBGMessage("Enviar keep-alive");
             kplTimer = 0;
             insertPacket(icq, KEEP_ALIVE, NULL, 0, FALSE);
          }
          else if(*onlineFlags&ICQF_CONTACTED)
          {
             icqWriteSysLog(icq,PROJECT,"Login timeout");
             icqDisconnect(icq);
          }
       }

       sz = icqRecv(sock,buffer,BUFFERSIZE);
    }

#ifdef __OS2__
    DosSetPriority(PRTYS_THREAD,PRTYC_REGULAR,PRTYD_MINIMUM,0);
#endif

    if(*onlineFlags & ICQF_ONLINE)
       sendDisconnectPkt(sock,icq,buffer);
 
    icqSystemEvent(icq, ICQEVENT_OFFLINE);

    /* Finalizar */
    icqCloseSocket(sock);
    c2sPackets   = icqDestroyList(c2sPackets);

    DBGMessage("Loop de recepcao terminado");

 }

 static int initialize(HICQ icq, char *buffer)
 {
    int         sock;

    DBGMessage("Iniciando contato com o servidor");

    if(!*icq->pwd)
    {
       icqWriteSysLog(icq,PROJECT,"Can't determine user password");
       return -1;
    }

    c2sIdle      =
    kplTimer     = 0;

    *(icqQueryOnlineFlags(icq)) |= ICQF_STARTING;

    icqWriteSysLog(icq,PROJECT,"Finding server");
    icqLoadString(icq,"server","icq.mirabilis.com",buffer,BUFFERSIZE);

//    strcpy(server,"127.0.0.1");

    DBGMessage(buffer);
    server  = icqGetHostByName(buffer);
    c2sIdle = 0;

    if(!server)
    {
       icqWriteSysLog(icq,PROJECT,"Unable to resolve the server name.");
       server =  icqLoadValue(icq,"lastServer",0);
    }

    if(!server)
       return -1;

    sprintf(buffer,"Connecting to %s",icqFormatIP(server));
    icqWriteSysLog(icq,PROJECT,buffer);

    sock = icqOpenUDP(icqLoadValue(icq,"msgPort",0));

#ifdef CONNECT_SOCK
    DBGMessage("Conectando");
    if(sock > 0)
       sock = icqConnectSock(sock,icq->server, 4000);
    DBGMessage("Conectado");
#endif

    if(sock < 0)
       icqWriteSysLog(icq,PROJECT,"Failure on server connect");

    return sock;
 }

 int sendPacket(HICQ icq, int sock)
 {
    /* Verifica se existe algum pacote para enviar */
    char        buffer[80];
    PACKET      *p = icqQueryFirstElement(c2sPackets);
    int         rc;

    if(!p)
       return 0;

    if(!p->cmd || (p->snd && p->timer < RETRY_TIMER) )
       return 1;

    p->timer = 0;

    if(p->snd)
    {
       sprintf(buffer,"Timeout on command %04x (Seq. %d, %d bytes)",p->cmd,p->seq,p->size);
       icqWriteSysLog(icq,PROJECT,buffer);
    }

    if(p->snd++ > retry)
       return timeout(icq,p);

#ifdef CONNECT_SOCK
    rc = icqSend(sock, (p+1), p->size);
#else
    rc = icqSendTo(sock, server, 4000, (p+1), p->size);
#endif

    DBGTrace(p->size);
    DBGTrace(server);
    DBGTrace(rc);

    if(rc)
       return cantSend(icq, rc);

    return 2;
 }

 static int timeout(HICQ icq, PACKET *pkt)
 {
    char buffer[0x0100];

    switch(pkt->cmd)
    {
    case LOGIN:
       strcpy(buffer,"Unable to contact the server");
       break;

    case KEEP_ALIVE:
       kplTimer = 0;
#ifdef NO_TIMEOUT
       icqWriteSysLog(icq,PROJECT,"Timeout sending keep-alive packet");
       return -1;
#else
       strcpy(buffer,"No response for the keep-alive packet");
       break;
#endif

    case CONTACT_LIST:
       sprintf(buffer,"Contact-list command with %d bytes wasn't confirmed",pkt->size);
       break;

    default:
       sprintf(buffer,"Timeout sending command %04x with %d bytes",pkt->cmd,pkt->size);
    }

    strcat(buffer,", changing to offline");
    icqWriteSysLog(icq,PROJECT,buffer);
    icqDisconnect(icq);

    return -1;
 }

 static int cantSend(HICQ icq, int rc)
 {
    char buffer[0x0100];

    sprintf(buffer,"Error %d when sending packet",rc);
    icqWriteSysLog(icq,PROJECT,buffer);
    return -1;
 }

 void ackPacket(HICQ icq, int sock, INPACKET *in)
 {
    /* Envia confirmacao de pacote ao servidor */
    char                buffer[0x0100];
    ACKPKT              *ack            = (ACKPKT *) buffer;

#ifdef DEBUG
    sprintf(buffer,"Enviar ack para o pacote %04x - %04x",in->aux_seq,in->sequence);
    DBGMessage(buffer);
#endif

    memset(ack,0,sizeof(ACKPKT));
    ack->o.version       = 0x05;
    ack->o.uin           = icqQueryUIN(icq);
    ack->o.session       = session;
    ack->o.command       = ACK;
    ack->o.aux_seq       = in->aux_seq;
    ack->o.sequence      = in->sequence;
    ack->r               = random();

    ack->o.checkcode     = checkcode( (char *) ack, sizeof(ACKPKT));
    encript((char *) ack, sizeof(ACKPKT), ack->o.checkcode);

#ifdef CONNECT_SOCK
    icqSend(sock, ack, sizeof(ACKPKT));
#else
    icqSendTo(sock, server, 4000, ack, sizeof(ACKPKT));
#endif

 }

 static void sendDisconnectPkt(int sock, HICQ icq, char *buffer)
 {
    OUTPACKET           *out            = (OUTPACKET *) (buffer);
    USHORT              *size           = (USHORT *) (out+1);
    int                 sz;
    const char          *txt            = "B_USER_DISCONNECTED";
    int                 qtd             = icqLoadValue(icq,"QDisconn",6);

    icqWriteSysLog(icq,PROJECT,"Disconnecting");

    memset(out,0,sizeof(OUTPACKET));

    out->version       = 0x05;
    out->uin           = icqQueryUIN(icq);
    out->session       = session;
    out->command       = SEND_TEXT_CODE;

    beginCriticalSection();
    out->aux_seq       = ++aux_seq;
    endCriticalSection();

    *size = strlen(txt)+1;
    sz    = sizeof(OUTPACKET) + *size + 2;
    strcpy( (char *) (size+1), txt);

    *( (short *) (buffer+sz) ) = 0x0005;
    sz += 2;

    out->checkcode      = checkcode( (char *) out, sz);
    encript((char *) out, sz, out->checkcode);

    while(qtd--)
    {
#ifdef CONNECT_SOCK
       icqSend(sock, out, sz);
#else
       icqSendTo(sock, server, 4000, out, sz);
#endif
#ifdef __OS2__
       DosSleep(5);
#endif
#ifdef linux
       pthread_yield();
#endif
    }


 }

