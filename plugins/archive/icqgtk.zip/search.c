/*
 * search.c - Janela de pesquisa
 */

 #include <malloc.h>
 #include <stdio.h>
 #include <string.h>

 #include <msgdlg.h>
 #include "icqgtk.h"

/*---[ Defines ]---------------------------------------------------------------------*/

 #define NUM_COLS 8
 
/*---[ Estruturas ]------------------------------------------------------------------*/
 
  #pragma pack(1)
 
 typedef struct _srcConfig
 {
	USHORT 		sz;
	HICQ		icq;
    GtkWidget   *main;
	GtkWidget   *notebook;
	GtkWidget   *list;
	GtkWidget   *button[ICQSHRC_BUTTONS];
 } SHRWINDOW;

/*---[ Prototipos ]------------------------------------------------------------------*/

 static void         destroy( GtkWidget *, SHRWINDOW *);
 static void 		 closeButton(GtkWidget *, SHRWINDOW *);
 static void 		 searchButton(GtkWidget *, SHRWINDOW *);
 static int          newPage(SHRWINDOW *, WIDGET, USHORT, const DLGMGR *, const char *, BOOL);
 static void         addPages(HICQ, USHORT, SHRWINDOW *);
   
 static void _System event(HICQ, ULONG, char, USHORT, ULONG, SHRWINDOW *);
 static int _System  searchCallback(HICQ, ULONG, USHORT, SHRWINDOW *, const ICQSEARCHRESPONSE *);
 
 static int  _System insertPage(SHRWINDOW *, WIDGET, USHORT, const DLGMGR *, const char *);
 static int  _System setTitle(SHRWINDOW *, const char *);
 static int  _System insertTable(HWND,USHORT,const TABLEDEF *, const DLGMGR *, const char *);

/*---[ Constantes ]------------------------------------------------------------------*/

 static gchar *search_titles[NUM_COLS] = 
 {	"",
    "ICQ#",
    "Nickname",
    "Gender",
    "First Name",
    "Last Name",
    "Age",
    "Authorization"
 };

 static gchar *buttonTitles[ICQSHRC_BUTTONS] =
 {
	"Close",
	"Add",
	"Search",
	"About"
 };

  static const DLGINSERT dlgInsert = {	sizeof(DLGINSERT),
 									    (int (*)(HWND, WIDGET, USHORT, const DLGMGR *, const char *)) insertPage,
 									    insertTable,
 									    (int (*)(HWND,const char *)) setTitle
 								   };

/*---[ Implementacao ]---------------------------------------------------------------*/

 int _System icqgtk_OpenSearchWindow(HICQ icq, USHORT type)
 {
    SHRWINDOW   *wnd = malloc(sizeof(SHRWINDOW));
	char      	buffer[0x0100];
    GtkWidget	*box;
    GtkWidget   *temp;
	int			f;
	
	DBGTracex(wnd);
	
	if(!wnd)
	{
	   icqWriteSysLog(icq,PROJECT,"Memory allocation error when creating search window");
	   return -1;
	}
	
    memset(wnd,0,sizeof(SHRWINDOW));
    wnd->sz   = sizeof(SHRWINDOW);
    wnd->icq  = icq; 

    wnd->main = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(wnd->main),"pwICQ Search");
    
    DBGTracex(wnd->main);
    
    sprintf(buffer,"ICQ#%lu",icqQueryUIN(icq));
    sprintf(buffer+0x80,"src%04x",type);
    
    gtk_window_set_wmclass(GTK_WINDOW(wnd->main),buffer+0x80, buffer);
    gtk_signal_connect(GTK_OBJECT(wnd->main), "destroy", GTK_SIGNAL_FUNC(destroy), wnd);
    gtk_widget_realize(wnd->main);

	/* Notebook com as opcoes de pesquisa */
    box = gtk_vbox_new(FALSE,2);
    wnd->notebook = gtk_notebook_new();
    gtk_box_pack_start(GTK_BOX(box), wnd->notebook,TRUE,TRUE,0);

    /* Lista de usuarios */
    temp = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(temp),GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);

    wnd->list = gtk_clist_new_with_titles(NUM_COLS,search_titles);

    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(temp),wnd->list);
    
    gtk_box_pack_start(GTK_BOX(box), temp,     TRUE,  TRUE, 0);

    /* Barra de botoes */
    temp = gtk_hbox_new(FALSE,2);
	
	for(f=0;f<ICQSHRC_BUTTONS;f++)
	{
       wnd->button[f] = gtk_button_new_with_label(buttonTitles[f]);
	   gtk_widget_set_sensitive(wnd->button[f],FALSE);
       gtk_box_pack_end(GTK_BOX(temp),wnd->button[f],FALSE,FALSE,0);
	}
    gtk_box_pack_end(GTK_BOX(box), temp,FALSE,FALSE,0);
    gtk_signal_connect(GTK_OBJECT(wnd->button[ICQSHRC_CLOSE]),  "clicked",    GTK_SIGNAL_FUNC(closeButton), wnd);
    gtk_signal_connect(GTK_OBJECT(wnd->button[ICQSHRC_SEARCH]),  "clicked",   GTK_SIGNAL_FUNC(searchButton), wnd);

    /* Finaliza */
    gtk_widget_set_sensitive(wnd->button[ICQSHRC_CLOSE],TRUE);
    gtk_widget_set_sensitive(wnd->button[ICQSHRC_SEARCH],TRUE);
    gtk_widget_show_all(box);

//  gtk_notebook_set_show_border(GTK_NOTEBOOK(wnd->notebook),FALSE);
//	gtk_notebook_set_tab_border(GTK_NOTEBOOK(wnd->notebook),TRUE);
	
	/* Carrega paginas de pesquisa */
    addPages(icq, type, wnd);
	
    /* E finalize */	
	gtk_container_add(GTK_CONTAINER(wnd->main), box);

    icqAddGuiEventListener(wnd->icq,(EVENTLISTENER) event,wnd);
	
    gtk_widget_show_all(wnd->main);
	
    return 0;
 }
 
 static void destroy( GtkWidget *widget, SHRWINDOW *wnd)
 {
    DBGMessage("Janela de pesquisa destruida");
    
    if(wnd->sz != sizeof(SHRWINDOW))
       return;

	icqRemoveGuiEventListener(wnd->icq,(EVENTLISTENER) event,wnd);

    memset(wnd,0,sizeof(SHRWINDOW));    
    free(wnd);
 }

 static void _System event(HICQ icq, ULONG uin, char type, USHORT eventCode, ULONG parm, SHRWINDOW *wnd)
 {
    /* Processa eventos */
    
 }
 
 static void closeButton(GtkWidget *widGet, SHRWINDOW *wnd)
 {
    icqgtk_StoreWindow(wnd->main, wnd->icq, 0, "shrWindowPos");
    gtk_widget_destroy(wnd->main);
 }
 
 static int _System setTitle(SHRWINDOW *wnd, const char *title)
 {
    gtk_window_set_title(GTK_WINDOW(wnd->main),title);
    return 0;
 }

 
 static int _System insertPage(SHRWINDOW *wnd, WIDGET dlg, USHORT tab, const DLGMGR *mgr, const char *title)
 {
    if(mgr && mgr->sz != sizeof(DLGMGR))
       return -2;
    return newPage(wnd, dlg, tab, mgr, title, FALSE);
 }

 static int _System insertTable(HWND hwnd, USHORT tab, const TABLEDEF *def, const DLGMGR *dlg, const char *title)
 {
    WIDGET table;

    if(dlg && dlg->sz != sizeof(DLGMGR))
       return -2;

    DBGMessage(title);    
    table = icqgtk_MakeTable(((SHRWINDOW *) hwnd)->icq, 0, def, dlg);
	
	DBGTracex(table);
    
    if(!table)
       return -1;
    
    return newPage( (SHRWINDOW *) hwnd, table, tab, dlg, title, TRUE);
 }

 static int newPage(SHRWINDOW *wnd, WIDGET dlg, USHORT tab, const DLGMGR *mgr, const char *title, BOOL isTable)
 {
    /* Insere uma pagina no notebook */ 
	char 		buffer[0x0100];
	char 		*ptr;
	GtkWidget	*label;
	
	if(wnd->sz != sizeof(SHRWINDOW))
	{
	   DBGMessage("Passou identificador de janela invalido");
	   return -1;
	}
	
	if(title)
	   strncpy(buffer,title,0xFF);
	else
	   strcpy(buffer,"No Title\nNoTitle");
	
	for(ptr = buffer;*ptr && *ptr != '\n';ptr++);
	   
	if(*ptr)
	   *(ptr++) = 0;
	
	DBGMessage(buffer);
	DBGMessage(ptr);
	
	label = gtk_label_new(buffer);
	gtk_object_set_user_data(GTK_OBJECT(label), (gpointer) mgr);
	
	CHKPoint();
    gtk_notebook_append_page( GTK_NOTEBOOK(wnd->notebook),
							  dlg,
							  label );
	
	return 0;
 }

// void EXPENTRY icqv8_SearchPage(HICQ icq, void *lixo, USHORT type, HWND hwnd, const DLGINSERT *dlg, char *buffer)
 
 static void addPages(HICQ icq, USHORT type, SHRWINDOW *hwnd)
 {
    void 	(* _System SearchPage)(HICQ, void *, USHORT, HWND, const DLGINSERT *, char *);
	char 	buffer[0x0100];
	HPLUGIN p;

	CHKPoint();
	
	for(p=icqQueryFirstPlugin(icq);p;p=icqQueryNextPlugin(icq,p))
	{
	   if(!icqLoadSymbol(p,"SearchPage", (void **) &SearchPage))
		  SearchPage(icq,icqQueryPluginDataBlock(icq,p),type,(HWND) hwnd,&dlgInsert,buffer);
	}

 }
 
 static void searchButton(GtkWidget *wdg, SHRWINDOW *hwnd)
 {
	char		 buffer[0x0100];
	int 	 	 id     = gtk_notebook_get_current_page(GTK_NOTEBOOK(hwnd->notebook));
	GtkWidget	 *page  = gtk_notebook_get_nth_page(GTK_NOTEBOOK(hwnd->notebook),id);
	GtkWidget	 *label = gtk_notebook_get_tab_label(GTK_NOTEBOOK(hwnd->notebook),page);
    const DLGMGR *mgr;
	
	DBGTrace(id);
	DBGTracex(page);
	DBGTracex(label);
	
	if(!label)
	   return;
	
	mgr = gtk_object_get_user_data(GTK_OBJECT(label));
	
	DBGTracex(mgr);
	
	if(!mgr || mgr->sz != sizeof(DLGMGR))
	   return;
	
	CHKPoint();
	
	if(mgr->sysButton)
	{
       mgr->sysButton(	&icqgtk_tableHelper, 
					    (HWND) page, 
				        hwnd->icq, 
					    0, 
					    (HWND) hwnd, 
						ICQSHRC_SEARCH, 
					    (SEARCHCALLBACK) searchCallback, 
					    buffer);
	   
       gtk_widget_set_sensitive(hwnd->button[ICQSHRC_SEARCH],FALSE);
	}
 }

 static int _System searchCallback(HICQ icq, ULONG uin, USHORT sequence, SHRWINDOW *hwnd, const ICQSEARCHRESPONSE *response)
 {
	CHKPoint();
	
	
	return 0;
 }

 
