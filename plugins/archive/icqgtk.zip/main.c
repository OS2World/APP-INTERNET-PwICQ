/*
 * icqgtk.c - Ponto de entrada
 */

 #include <stdio.h>
 #include <malloc.h>
 #include <string.h>
 #include <stdlib.h>
 #include <unistd.h>

 #include "icqgtk.h"

 #include <gnome.h>

/*---[ Estruturas ]--------------------------------------------------------------------------*/

 #pragma pack(1)
 
 struct menu_option
 {
    MAINWIN	     *wnd;
    USHORT		 menu;
    USHORT 		 id;
    MENUCALLBACK *cbk;
	ULONG        cbkParm;
 };

/*---[ Constantes ]--------------------------------------------------------------------------*/

 static ULONG _System loadSkin(HICQ, STATUSCALLBACK *, int, char **);
 static int   _System executeSkin(HICQ,ULONG);
 static int   _System event(HICQ,ULONG,char,USHORT,ULONG,void *);
 static int   _System insertMenu(HICQ, USHORT, const char *, USHORT, MENUCALLBACK *, ULONG);
 static void  _System view(HICQ, ULONG, HMSG);
 static int   _System validateEdit(USHORT);
 static void  _System newMessage(HICQ,ULONG,USHORT,const char *, const char *);
 static int   _System popupMenu(HICQ, ULONG, USHORT, USHORT, USHORT);
 static int   _System newWithMgr(HICQ, ULONG, const MSGMGR *, HMSG);

 static SKINMGR caps = {       sizeof(SKINMGR),
							   0,				// flags
							   "GTK1",
                               loadSkin,
                               executeSkin,
                               (int (*)(HICQ,void *,char)) icqgtk_guiTimer,
                               NULL,			// warning
                               view,			// view
                               newMessage,	    // newMessage
							   newWithMgr,
                               NULL,			// awayMessage
					           popupMenu,    	// popupmenu
						       NULL,			// popupUserList
                               insertMenu,
                               icqgtk_OpenConfigWindow,
                               validateEdit,
                               event
                       };

/*---[ Prototipos ]--------------------------------------------------------------------------*/

 static void menuAction(const struct menu_option *);
 static void addEvent(MAINWIN *, ULONG, char, USHORT, ULONG);

/*---[ Implementacao ]-----------------------------------------------------------------------*/

 int EXPENTRY icqgtk_Configure(HICQ icq, HMODULE mod)
 {
    static const char *ident = 
#ifdef __DLL__
    "Loading"    
#else
    "Initializing"
#endif    
    " GTK Interface module Build " __DATE__ " " __TIME__ 
#ifdef DEBUG
    " (Debug Version)"
#endif
    ;
	char buffer[10];
	
    icqWriteSysLog(icq,PROJECT,ident);
    
#ifdef EXTENDED_LOG
    icqWriteSysLog(icq,PROJECT,"**** Extensive logging enabled ****");
#endif

    DBGTracex(icq);
    DBGTracex(&caps);

    icqLoadString(icq, "gui", "gtk", buffer, 9);
	
	if(stricmp(buffer,"gtk"))
	{
#ifdef EXTENDED_LOG
	   icqWriteSysLog(icq,PROJECT,"Disabled by configuration");
#endif
	   return -2;
	}
	
    if(!icqRegisterSkinManager(icq,&caps))
    {
       CHKPoint();
       icqWriteSysLog(icq,PROJECT,"Can't register GTK Interface plugin");
       return -1;
    }

    CHKPoint();

    return 0;
 }

 static ULONG _System loadSkin(HICQ icq, STATUSCALLBACK *status, int argc, char **argv)
 {
    MAINWIN *wnd = malloc(sizeof(MAINWIN));

    if(!wnd)
       return 0;

    gtk_set_locale();
    gtk_init(&argc, &argv);
    g_thread_init(NULL);

    /* Inicializa campos basicos */    
    memset(wnd,0,sizeof(MAINWIN));
    wnd->sz        = sizeof(MAINWIN);
    wnd->icq       = icq;
    wnd->fTick     = 
    wnd->aTick     = 0;

    wnd->sTick     =
    wnd->iTick     =
    wnd->aPos      = 0xFFFF;
    wnd->events    = icqCreateList();

    icqSetSkinDataBlock(icq,wnd);

    return (ULONG) wnd;
 }

 static int  _System executeSkin(HICQ icq, ULONG cfg)
 {
    MAINWIN *wnd 	= (MAINWIN *) cfg;

    DBGTracex(cfg);

    if(wnd != icqGetSkinDataBlock(icq))
    {
       icqWriteSysLog(icq,PROJECT,"Unexpected Skin Data Block supplied");
       return -1;
    }

    /* Apresenta a janela e processa */

    if(icqQueryLogonStatus(icq))
       icqEvent(icq,0,'G',0,0);
    else
       icqgtk_login(icq);

//#ifdef DEBUG
//	icqShowPopupMenu(icq,0,2);
//#endif	

    gtk_main();

    wnd->flags &= ~ICQGTK_FLAG_READY;
    usleep(1000);
    icqSetSkinDataBlock(icq,NULL);
    usleep(1000);
    
    icqSysLog(icq,"Stopping");

    /* Finalizacao */
    DBGMessage("Liberando area de trabalho");
    icqDestroyList(wnd->events);
    free(wnd);

    return 0;
 }

 static int _System insertMenu(HICQ icq, USHORT menu, const char *text, USHORT icon, MENUCALLBACK *cbk, ULONG parm)
 {
    MAINWIN *wnd =  icqGetSkinDataBlock(icq);
    icqgtk_addMenuOption(wnd,menu,icon,cbk,text,parm);
    return 0;
 }

 void icqgtk_addMenuOption(MAINWIN *wnd, USHORT id, USHORT icon, MENUCALLBACK *cbk, const char *text, ULONG p)
 {
    GtkWidget 			*box   = gtk_hbox_new(FALSE,5);
    GtkWidget 			*item  = gtk_menu_item_new();
    struct menu_option	parm   = { wnd, id, icon, cbk, p };

    gtk_box_pack_start(GTK_BOX(box), gtk_pixmap_new(wnd->iPixmap[icon],wnd->iBitmap[icon]),  FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), gtk_label_new(text),  FALSE, FALSE, 0);
    
    gtk_container_add(GTK_CONTAINER(item),box);
    gtk_menu_append(GTK_MENU(wnd->menu[id]),item);
    gtk_widget_show_all(item);

    gtk_signal_connect_object(GTK_OBJECT(item), "activate", GTK_SIGNAL_FUNC(menuAction), g_memdup(&parm, sizeof(parm)));

 }
 
 static void addEvent(MAINWIN *wnd, ULONG uin, char type, USHORT event, ULONG parm)
 {
    EVENT *e;
    
    e = icqAddElement( wnd->events, sizeof(EVENT));
    
    if(!e)
    {
       icqWriteSysLog(wnd->icq,PROJECT,"Error adding event in table");
       icqAbend(wnd->icq,0);
       return;
    }

    e->uin   = uin;
    e->event = event;
    e->type  = type;    
    e->parm  = parm;

 }

 static int _System event(HICQ icq, ULONG uin, char type, USHORT event, ULONG parm, void *dataBlock)
 {
    if(!(dataBlock && type))
       return 0;

    if(type == 'G')
    {
       icqgtkEvent_Gui(icq, (MAINWIN *) dataBlock, uin, event, 0);
       return 0;
    }
  
    addEvent((MAINWIN *) dataBlock, uin, type, event, parm);    
    
    return 0;      
 }

 static void _System view(HICQ icq, ULONG uin, HMSG msg)
 {
    if(msg)
       addEvent((MAINWIN *) icqGetSkinDataBlock(icq),uin,'G', 1, (ULONG) msg);
    else
       icqWriteSysLog(icq,PROJECT,"Unexpected view message request");
 }

 static void  _System newMessage(HICQ icq, ULONG uin, USHORT type, const char *txt, const char *url)
 {
    addEvent((MAINWIN *) icqGetSkinDataBlock(icq),uin,'G', 2, (ULONG) type);
 }

 int _System newWithMgr(HICQ icq, ULONG uin, const MSGMGR *mgr, HMSG msg)
 {
	CHKPoint();
    addEvent((MAINWIN *) icqGetSkinDataBlock(icq),uin,'G',4, (ULONG) mgr);
	CHKPoint();
    return 0;
 }

 static int   _System validateEdit(USHORT sz)
 {
    if(sz != sizeof(MSGEDITHELPER))
       return 2;
    return 0;
 }
 
 static void menuAction(const struct menu_option *opt)
 {
    if(opt->cbk)
       opt->cbk(opt->wnd->icq, opt->wnd->selected, opt->id, (ULONG) opt->cbkParm);
 }

#ifdef DEBUG_LOG
 void EXPENTRY icqgtk_lock(MAINWIN *wnd, const char *pgm, int lin)
 {
    char debugLog[0x0100];
#else
 void EXPENTRY icqgtk_lock(MAINWIN *wnd)
 {
#endif 
    int f = 0;
    
#ifdef EXTENDED_LOG
    if(getpid() == wnd->lockOwner)
       icqWriteSysLog(wnd->icq,PROJECT,"Lock request from the same PID");
#endif
    
    while(wnd->flags & ICQGTK_LOCK)
    {
       while (gtk_events_pending())
	      gtk_main_iteration();

       if(f++ > 100)
       {
#ifdef DEBUG_LOG
          sprintf(debugLog,"Semaphore locked by %s(%d), requested by %s(%d). Timeout!",
          						wnd->lockSource,wnd->lockLine,
          						pgm,lin );
          icqWriteSysLog(wnd->icq,PROJECT,debugLog);          						
#else
          icqWriteSysLog(wnd->icq,PROJECT,"Timeout requesting semaphore");
#endif          
          f = 0;
       }
       usleep(100);
    }
    
    wnd->lockOwner  = getpid();

#ifdef DEBUG_LOG
    strncpy(wnd->lockSource,pgm,19);
    wnd->lockLine = lin;
#endif

    wnd->flags     |= ICQGTK_LOCK;
    
 }
 
#ifdef DEBUG_LOG
 void EXPENTRY icqgtk_unlock(MAINWIN *wnd, const char *pgm, int lin)
#else 
 void EXPENTRY icqgtk_unlock(MAINWIN *wnd)
#endif 
 {
    wnd->flags     &= ~ICQGTK_LOCK; 
    wnd->lockOwner  = 0;
 }
  
 void EXPENTRY icqgtk_StoreWindow(GtkWidget *hwnd, HICQ icq, ULONG uin, const char *key)
 {
    gint x,y,width,height;
    char buffer[80];
    
    if( !gdk_window_get_deskrelative_origin(hwnd->window,&x,&y))
       return;

    gdk_window_get_size(hwnd->window,&width,&height);
    
    sprintf(buffer,"%d,%d,%d,%d",x,y,width,height);

    icqSaveString(icq,key,buffer);
 }

 void EXPENTRY icqgtk_RestoreWindow(GtkWidget *hwnd, HICQ icq, ULONG uin, const char *key, short w, short h)
 {
    int x,y,width,height;
    char buffer[80];

    icqLoadString(icq,key,"",buffer,79);
    
    if(!*buffer)    
    {
       gtk_window_set_default_size(GTK_WINDOW(hwnd),w,h);
       return;
    }
    
    DBGMessage(buffer);
    if(sscanf(buffer,"%d,%d,%d,%d",&x,&y,&width,&height) != 4)
    {
       gtk_window_set_default_size(GTK_WINDOW(hwnd),w,h);
       return;
    }

//    gtk_widget_set_uposition(hwnd,x,y);
    gtk_window_set_default_size(GTK_WINDOW(hwnd),width,height);
 }

 static int _System popupMenu(HICQ icq, ULONG uin, USHORT id, USHORT x, USHORT y)
 {
	DBGMessage("Popup Menu request");
	
	if(id > ICQGTK_MENUS)
	{
	   icqWriteSysLog(icq,PROJECT,"Invalid popup menu request");
	   return -2;
	}

    addEvent((MAINWIN *) icqGetSkinDataBlock(icq),uin,'G', 3, (ULONG) id);

	return -1;
 }
