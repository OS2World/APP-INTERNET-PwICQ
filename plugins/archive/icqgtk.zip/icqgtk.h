/*
 * icqgtk.h - Definicoes para o gerenciador de janelas GTK
 */

 #include <gtk/gtk.h>
 #include <gdk-pixbuf/gdk-pixbuf.h>

 #include <pwMacros.h>
 #include <icqtlkt.h>

 #ifdef DEBUG_LOG
    #define EXTENDED_LOG
 #endif
     
 /*---[ Definicoes ]------------------------------------------------------------------------*/

 #define ICQGTK_MENUS 3
 
#ifdef DEBUG_LOG
 #define ICQLOCK(w)   icqgtk_lock(w,__FILE__,__LINE__);
 #define ICQUNLOCK(w) icqgtk_unlock(w,__FILE__,__LINE__);
 #define SETLOCK(w)   strncpy(w->lockSource,__FILE__,19);w->lockLine = __LINE__

#else
 #define ICQLOCK(w)   icqgtk_lock(w);
 #define ICQUNLOCK(w) icqgtk_unlock(w);
 #define SETLOCK(w)   /* setlock(w) */
#endif 

 #define ICQPIXMAP(w,i) w->iPixmap[i],w->iBitmap[i]
 #define ICQREORDER(w) w->flags |= ICQGTK_FLAG_REORDER
 #define ICQMAKEFILTER(w) w->flags |= ICQGTK_FLAG_MAKEFILTER

 #define EVENTLISTENER void (_System *)(HICQ,ULONG,UCHAR,USHORT,ULONG,HWND)

 #define   ICQMENU_SYSTEM  ICQMNU_SYSTEM
 #define   ICQMENU_MODES   ICQMNU_MODES
 #define   ICQMENU_USER    ICQMNU_USER

 /*---[ Estruturas ]------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct mainwin
 {
    USHORT	   sz;
    HICQ	     icq;

    UCHAR		filter;    
    ULONG		flags;
    #define ICQGTK_FLAG_REORDER	0x00000001
    #define ICQGTK_FLAG_MAKEFILTER 0x00000002
    #define ICQGTK_FLAG_MSGICON    0x00000004
    #define ICQGTK_FLAG_SYSICON	0x00000008
    #define ICQGTK_FLAG_READY	  0x00000010
    #define ICQGTK_SAVE		    0x00000020
    #define ICQGTK_SHOW     	   0x00000040
    #define ICQGTK_LOCK			0x00000080

    ULONG		lockOwner;    

#ifdef DEBUG_LOG
    char		 lockSource[20];
    int		  lockLine;
#endif
    
    USHORT	   fTick;
    USHORT	   iTick;
    
    /* SysButton */
    USHORT	   sTick;
    USHORT	   eventIcon;
    USHORT	   readIcon;
    
    /* Dados de controle */
    USHORT	   szIcon;			// Altura da toolbar
    GdkPixmap	*iPixmap[PWICQICONBARSIZE];
    GdkBitmap    *iBitmap[PWICQICONBARSIZE];
    ULONG		selected;

    /* Animacao */
    USHORT	   aTick;
    USHORT	   aPos;
        
    /* Controles */
    GtkWidget    *main;
    GtkWidget	*box;
    GtkWidget	*listBox;
    GtkWidget	*sysMsg;
    GtkWidget	*search;
    GtkWidget    *modeText;

    /* Imagens */
    GtkWidget	 *sysMsgPix;
    GtkWidget 	*modePix;

    /* Parte superior da janela */
    GtkWidget 	*topButton;
    GtkWidget 	*online;
    GtkWidget 	*all;

    /* Menus */
    GtkWidget	*menu[ICQGTK_MENUS];
    
    /* Parte de baixo da janela */
    GtkWidget	*baseButton;
    GtkWidget	*system;
    GtkWidget	*mode;

    /* Eventos pendentes */
    HLIST	    events;
    
 } MAINWIN;

 typedef struct event
 {
    ULONG  uin;
    char   type;
    USHORT event;
    ULONG  parm;
 } EVENT;


/*---[ Tabelas ]---------------------------------------------------------------------------*/

 extern const DLGHELPER icqgtk_tableHelper;
 
/*---[ Entry-points ]----------------------------------------------------------------------*/

 int  EXPENTRY icqgtk_Configure(HICQ, HMODULE);
 void EXPENTRY icqgtk_ConfigPage(HICQ, void *, ULONG, USHORT, HWND,  const DLGINSERT *, char *);
 
 void EXPENTRY icqgtkEvent_User(HICQ, MAINWIN *, ULONG, USHORT, HUSER);
 void EXPENTRY icqgtkEvent_System(HICQ, MAINWIN *, USHORT);

 void EXPENTRY icqgtkEvent_Gui(HICQ, MAINWIN *, ULONG, USHORT, ULONG);

 WIDGET  EXPENTRY icqgtk_MakeTable(HICQ, ULONG, const TABLEDEF *, const DLGMGR *);

 void EXPENTRY icqgtk_StoreWindow(GtkWidget *, HICQ, ULONG, const char *);
 void EXPENTRY icqgtk_RestoreWindow(GtkWidget *, HICQ, ULONG, const char *, short, short);

#ifdef DEBUG_LOG
 void EXPENTRY icqgtk_lock(MAINWIN *, const char *, int);
 void EXPENTRY icqgtk_unlock(MAINWIN *, const char *, int);
#else
 void EXPENTRY icqgtk_lock(MAINWIN *);
 void EXPENTRY icqgtk_unlock(MAINWIN *);
#endif 
  
 void _System  icqgtk_setStartupStage(HICQ,int);
 int  _System  icqgtk_OpenConfigWindow(HICQ, ULONG, USHORT, PAGELOADER *);
 int  _System  icqgtk_OpenSearchWindow(HICQ, USHORT);

 void          icqgtk_login(HICQ);

 int _System   icqgtk_guiTimer(HICQ, MAINWIN *,char);
 void          icqgtk_addMenuOption(MAINWIN *, USHORT, USHORT, MENUCALLBACK *, const char *, ULONG);

 int _System   icqgtk_unknownMsgFormatter(const MSGEDITHELPER *, hWindow, HICQ, ULONG, USHORT, BOOL, HMSG);


/*---[ Prototipos ]------------------------------------------------------------------------*/

 int       icqgtk_createMainWindow(HICQ icq, MAINWIN *);

 int	   icqgtk_sysmenu(HICQ,ULONG,USHORT,ULONG);
 int	   icqgtk_modemenu(HICQ,ULONG,USHORT,ULONG);
 int	   icqgtk_usermenu(HICQ,ULONG,USHORT,ULONG);

 int	   icqgtk_setMainWindowTitle(HICQ,MAINWIN *);

 int       icqgtk_msgWindow(HICQ, ULONG, USHORT);

 int       icqgtk_openMessageWindow(HICQ, ULONG, USHORT, BOOL, HMSG, const MSGMGR *);

 void      icqgtk_searchButton( GtkWidget *, MAINWIN *);
 void      icqgtk_systemMessageButton( GtkWidget *, MAINWIN *);

 void      icqgtk_addUserInListBox(MAINWIN *, HUSER);

