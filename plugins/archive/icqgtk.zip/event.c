/*
 * EVENT.C - Processa eventos de interface grafica
 */
 
 #include <unistd.h>
 
 #include "icqgtk.h"

/*---[ Prototipos ]------------------------------------------------------------------------*/

 
/*---[ Implementacao ]---------------------------------------------------------------------*/

 void _System icqgtk_setStartupStage(HICQ icq, int sts)
 {
    DBGTrace(sts);
 }

 void EXPENTRY icqgtkEvent_Gui(HICQ icq, MAINWIN *wnd, ULONG uin, USHORT event, ULONG parm)
 {
    switch(event)
    {
    case 0:	/* Pronto para iniciar */
       icqgtk_createMainWindow(icq, wnd);
       if(icqInitialize(icq,(STATUSCALLBACK *) icqgtk_setStartupStage))
       {
          gtk_main_quit();
          return;
       }
       wnd->filter = icqLoadValue(icq,"wndFilterMode",0);
       gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(wnd->filter ? wnd->online : wnd->all), TRUE);
       icqgtk_setMainWindowTitle(icq,wnd);
       icqgtk_RestoreWindow(wnd->main,wnd->icq,0,"mainWindowPos",150,375);
       icqReconnect(wnd->icq);
       break;
       
    }

 }

