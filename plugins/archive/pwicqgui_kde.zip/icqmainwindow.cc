
 #include <klocale.h>
 #include <kbuttonbox.h>

 #include <qtextview.h>
 #include <qvbox.h>
 #include <qhbox.h>
 #include <qbuttongroup.h>
 #include <qlistbox.h>
 #include <qpixmap.h> 
 #include <qimage.h>

 #include <icqtlkt.h>
 #include "icqkde.h"
 #include "icqevent.h"
 #include "icqlistboxitem.h"
 #include "icqmodemenu.h" 
 #include "icqmainwindow.h"
 #include "icqmessageevent.h"

/*---[ Implementacao ]---------------------------------------------------------------*/

ICQMainWindow::ICQMainWindow( const char *name, HICQ icq ) 
: KMainWindow ( 0L, name )
{
   char buffer[0x0100];
   
   DBGTracex(icq);
   
   this->icq 	  = icq;
   
   anModeButton   = -1;
   anDivider      = 0;
   
   setCaption(name);
   
   /* Carrega o arquivo de imagem */
   icqQueryPath(icq,"images/icons.gif",buffer,0xFF);

#ifdef USE_ICONTABLE   
   
   QImage *icons = new QImage(buffer);
   Q_CHECK_PTR(icons);
   
   iconSize      = icons->height();

   int c;
   int f;
   for(f = c = 0; f < PWICQICONBARSIZE; f++)
   {
	  iconTable[f] = QPixmap( icons->copy(c,0,iconSize,iconSize) );
	  c += iconSize;
   }
   
   delete icons;
   
#else
   
   icons = new QImage(buffer);
   Q_CHECK_PTR(icons);

#endif

   CHKPoint();
   
   icqSetSkinDataBlock(icq,this);
   
   /* Cria controles */

   QVBox * VBox = new QVBox( this );

   /* Botoes da parte superior */
   QHBox * topButtons  = new QHBox(VBox);

   all    = new QPushButton( icqkde_pixmap(15), "&All",    topButtons);
   online = new QPushButton( icqkde_pixmap(43), "&Online", topButtons);
   
   all->setToggleButton(TRUE);
   online->setToggleButton(TRUE);

   // Lista de usuarios
   DBGTracex(icq);
#ifdef USE_ICQLISTBOX	  
   listBox = new ICQListBox(VBox,icq);
#else
   listBox = new KListBox(VBox);
#endif   

   Q_CHECK_PTR(listBox);
   
   QPushButton *search = new QPushButton( icqkde_pixmap(11), "Search/&Add", VBox);
   QPushButton *system = new QPushButton( icqkde_pixmap(10), "&System",     VBox);

   KButtonBox  *baseButtons  = new KButtonBox(VBox);

   QPushButton *sysbutton    = baseButtons->addButton("pw&ICQ",TRUE);

   modebutton  = baseButtons->addButton("Offline");
   modebutton->setIconSet(icqkde_pixmap(7));

   // Cria menus
   sysMenu   = new ICQSysMenu(icq, 0, sysbutton);
   modeMenu  = new ICQModeMenu(icq, 0, modebutton);
   userMenu  = new ICQUserMenu(icq, "User");

   // Faz as conexoes
   connect( all,    SIGNAL(toggled(bool)), this, SLOT(showAll(bool)) );
   connect( online, SIGNAL(toggled(bool)), this, SLOT(showOnline(bool)) );
  
   // Inicializa
   all->setOn(TRUE);
   
   // Finaliza
   setCentralWidget( (QWidget *) VBox );

   timer = new QTimer( this );
   connect( timer, SIGNAL(timeout()), SLOT(doTimer()) );

//   connecting();

}

ICQMainWindow::~ICQMainWindow( )
{
   CHKPoint();
   icqSetSkinDataBlock(icq,NULL);
}

void ICQMainWindow::showAll(bool modo)
{
   bool atual = (bool) icqLoadValue(icq,PROJECT":showOffline",1);
   online->setOn(!modo);
   if(atual != modo)
   {
	  icqEvent(icq,0,'G',1,0);
	  icqSaveValue(icq,PROJECT":showOffline",modo);
   }
}

void ICQMainWindow::showOnline(bool modo)
{
   all->setOn(!modo);
}

void ICQMainWindow::doTimer()
{
   if(icqIsActive(icq))
      icqkrnl_Timer(icq);
   
   anDivider++;
   
   if( !(anDivider % 5) && (anModeButton >= 0) )
   {
      modebutton->setIconSet(icqkde_pixmap(18+anModeButton++));
	  anModeButton &= 0x07;
   }
   
   icqEvent(icq,0,'G',4, anDivider);

}


bool ICQMainWindow::eventFilter( QObject *obj, QEvent *evt )
{
   Q_CHECK_PTR(evt);
   
   if(evt->type() == QEvent::User && obj == this) 
   {
	  ICQEvent *ev = (ICQEvent *) evt;

      Q_CHECK_PTR(listBox);

#ifdef USE_ICQLISTBOX	  
      listBox->procEvent(ev);
#endif
	  
	  if(ev->isSystem())
	     systemEvent(ev);
	  else if(ev->getType() == 'G')
		 internalEvent(ev);
	  
	  return TRUE;
   }
   return KMainWindow::eventFilter( obj, evt );
}

void ICQMainWindow::internalEvent(ICQEvent *evt)
{
   switch(evt->getEventCode())
   {
   case 2:
	  DBGMessage("Encerrar operacao");
      close();
      break;
   
   case 5:
	  DBGMessage("Abrir janela de mensagems");
      ((ICQMessageEvent *) evt)->open();
      break;
   
   case 3:
      ICQMenu *menu = getMenu(evt->getParm());
      if(menu)
	  {
         Q_CHECK_PTR(menu);
		 menu->exec(evt->getUIN());
	  }
      break;
   }
   
}

void ICQMainWindow::systemEvent(ICQEvent *evt)
{
   /*
    * Take actions based on pwICQ Events
    */
   Q_CHECK_PTR(evt);
   
   switch(evt->getEventCode())
   {
   case ICQEVENT_ONLINE:			// System online
   case ICQEVENT_OFFLINE:			// System offline
   case ICQEVENT_CHANGED:		   	// Mode changed
	  onlineModeChanged();
      break;

   case ICQEVENT_ABEND:		   		// Abend - Terminate program
	  close();
      break;

   case ICQEVENT_FINDINGSERVER:
   case ICQEVENT_CONNECTING:
	  connecting();
      break;
   
   case ICQEVENT_MESSAGECHANGED:	// Ajust system message button
	  systemMessage();
      break;
   
   case ICQEVENT_TIMER:
	  break;

   case ICQEVENT_SECONDARY:			// Secondary startup-stage complete!
	  
      userMenu->loadOptions();
      modeMenu->loadOptions();
	  sysMenu->loadOptions();
	  
      show();
      timer->start( 100 );
	  
#ifndef USE_ICQLISTBOX	  
      for(HUSER usr = icqQueryFirstUser(icq);usr;usr=icqQueryNextUser(icq,usr))
		 new QListBoxText(listBox, icqQueryUserNick(usr));
#endif	  
	  
	  break;

   }
}

void ICQMainWindow::onlineModeChanged()
{
   ULONG 				current	= icqQueryOnlineMode(icq);
   const ICQMODETABLE 	*mode;
   
   DBGMessage("Online mode changed...");
   anModeButton = -1;
   
   for(mode=icqQueryModeTable(icq);mode && mode->mode != current && mode->descr; mode++);
	  
   if(!mode || !mode->descr)
   {
      modebutton->setText("Failed!");
	  return;
   }

   modebutton->setText(mode->descr);
   modebutton->setIconSet(icqkde_pixmap(mode->icon));

}

void ICQMainWindow::connecting()
{
   anModeButton = 0;
   modebutton->setText("Connecting");
}

void ICQMainWindow::systemMessage()
{
   DBGMessage("System message status changed...");   
}

const QPixmap ICQMainWindow::getPixmap(USHORT id)
{
   if(id > PWICQICONBARSIZE)
   {
	  icqWriteSysLog(icq,PROJECT,"Unexpected icon request");
	  id = 0;
   }
   
#ifdef USE_ICONTABLE   
   DBGTrace(id);

   return iconTable[id];
#else   
   int iconSize = getIconSize();
   Q_CHECK_PTR(icons);
   return QPixmap( icons->copy(iconSize*id,0,iconSize,iconSize) );
#endif   

}

USHORT ICQMainWindow::getIconSize()
{
   return icons->height();
}

ICQMenu * ICQMainWindow::getMenu(USHORT menu)
{
   switch(menu)
   {
   case ICQMENU_USER:
      return userMenu;
   
   case ICQMENU_MODES:
	  return modeMenu;
   
   case ICQMENU_SYSTEM:
	  return sysMenu;
   }
   
   return NULL;
}
