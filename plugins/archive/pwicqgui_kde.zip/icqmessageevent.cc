/*
 * icqevent.cc - pwICQ event's dispatcher
 */

 #include <malloc.h>
 #include <kaboutkde.h>
 #include "icqmessageevent.h"
 #include "icqmsgwindow.h"

/*---[ Implementacao ]---------------------------------------------------------------*/

 ICQMessageEvent::ICQMessageEvent(HICQ icq, ULONG uin, HMSG msg)
 : ICQEvent(icq,uin,'G',5,0)
 {
	DBGTracex(msg);
	DBGTracex(msg->type);
	DBGMessage( (char *) (msg+1) );

	this->msg     = msg;
	this->msgType = msg->type;
	
	this->text    = 
	this->url     = NULL;
 }

  ICQMessageEvent::~ICQMessageEvent()
 {
	DBGMessage("Evento de mensagem destruido");
	if(text)
	   free(text);
	if(url)
	   free(url);
 }
 

 ICQMessageEvent::ICQMessageEvent(HICQ icq, ULONG uin, USHORT type, const char *text, const char *url)
 : ICQEvent(icq,uin,'G',5,0)
 {
	
	this->msg     = NULL;
	this->msgType = type;
	
	if(text)
	   this->text = strdup(text);
	else
	   this->text = NULL;
	
	if(url)
	   this->url = strdup(url);
    else
	   this->url = NULL;
 }

 void ICQMessageEvent::open()
 {
	ICQMessageWindow *hwnd = new ICQMessageWindow((QWidget *) icqGetSkinDataBlock(getICQ()), this);
	Q_CHECK_PTR(hwnd);
	hwnd->show();
 }
