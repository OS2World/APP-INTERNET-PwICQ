/*
 * icqevent.h - icqEventObject
 */

#ifndef ICQMESSAGEEVENT_INCLUDED

   #define ICQMESSAGEEVENT_INCLUDED 1

   #include "icqevent.h"
   #include <icqtlkt.h>
   
   #pragma pack()
   
   class ICQMessageEvent : public ICQEvent
   {

   public:
   
      ICQMessageEvent(HICQ, ULONG, HMSG);
      ICQMessageEvent(HICQ, ULONG, USHORT, const char *, const char *);
	  
      ~ICQMessageEvent();
	  
	  void open();
	  
   private:
	  
	  USHORT	msgType;
	  HMSG		msg;
	  char 		*text;
	  char		*url;
	  
   };
   
#endif   


