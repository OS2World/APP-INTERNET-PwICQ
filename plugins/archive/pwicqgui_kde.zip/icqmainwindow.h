
#ifndef ICQMAINWINDOW_INCLUDED

   #define ICQMAINWINDOW_INCLUDED 1

   #include <kmainwindow.h>
   #include <qpushbutton.h>
   #include <qtimer.h>
   #include <qiconset.h>
   #include <qpopupmenu.h> 
   #include <qimage.h>
   
   #include <icqtlkt.h>
 
   #include "icqevent.h" 
   #include "icqlistbox.h"
   #include "icqmenu.h"
   #include "icqmodemenu.h"
   #include "icqsysmenu.h"
   #include "icqusermenu.h"

   #define USE_ICQLISTBOX

   class ICQMainWindow : public KMainWindow
   {
      Q_OBJECT

   public:

      ICQMainWindow( const char *, HICQ );
      ~ICQMainWindow();
   
	  void			 onlineModeChanged();
	  void			 connecting();
	  void			 systemMessage();
	  
	  const QPixmap  getPixmap(USHORT);
	  USHORT		 getIconSize();
	  ICQMenu *		 getMenu(USHORT);
	  
   protected:
      bool 			 eventFilter( QObject *, QEvent * );   
		
   private slots:
      void 			 showAll(bool); 
 	  void 			 showOnline(bool);
      void 			 doTimer();
	  
   private:

	  void			 systemEvent(ICQEvent *);
	  void			 internalEvent(ICQEvent *);
	  
      short			 anModeButton;
	  short			 anDivider;

      HICQ        	 icq;
      QTimer      	 *timer;

      /* Controles da janela principal */
      QPushButton 	 *all;
      QPushButton 	 *online;
      QPushButton 	 *modebutton;
#ifdef USE_ICQLISTBOX	  
      ICQListBox  	 *listBox;
#else
      KListBox       *listBox;
#endif

      ICQModeMenu	 *modeMenu;
	  ICQSysMenu	 *sysMenu;
	  ICQUserMenu	 *userMenu;
	  
	  /* Componentes */
#ifdef USE_ICONTABLE   
	  USHORT		 iconSize;
	  QPixmap        iconTable[PWICQICONBARSIZE];
#else
      QImage         *icons;
#endif	  
	  
   };

#endif

