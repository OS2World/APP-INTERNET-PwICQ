/*
 * icqmenu.h - Classe para gerenciamento de menus
 */

#ifndef ICQSYSMENU_INCLUDED

   #define ICQSYSMENU_INCLUDED 1
   
   #include "icqmenu.h"
   
   class ICQSysMenu : public ICQMenu
   {
      Q_OBJECT
	  
   public:
	  
	  ICQSysMenu( HICQ icq, const char *text=0, QPushButton *button=0 );
	  
	  int  loadOptions();

   public slots:
	    
	  void configure();
	  void disconnect();
	  void updateAll();
	  void shutdown();
	  
   };

#endif


 
