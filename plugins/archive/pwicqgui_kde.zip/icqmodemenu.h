/*
 * icqmenu.h - Classe para gerenciamento de menus
 */

#ifndef ICQMODEMENU_INCLUDED

   #define ICQMODEMENU_INCLUDED 1
   
   #include "icqmenu.h"
   
   class ICQModeMenu : public ICQMenu
   {
      Q_OBJECT
	  
   public:
	  
	  ICQModeMenu( HICQ icq, const char *text=0, QPushButton *button=0 );
	  
	  int  loadOptions();
	  
   public slots:
	  
	  void setOnlineMode();
	  
   };

#endif


 
