/*
 * icqmenu.h - Classe para gerenciamento de menus
 */

#ifndef ICQUSERMENU_INCLUDED

   #define ICQUSERMENU_INCLUDED 1
   
   #include "icqmenu.h"
   
   class ICQUserMenu : public ICQMenu
   {
      Q_OBJECT
	  
   public:
	  
	  ICQUserMenu( HICQ icq, const char *text=0, QPushButton *button=0 );
	  
	  int  loadOptions();
	  
   public slots:
	  void sendMessage();
	  void updateUser();
	  void deleteUser();
	  
   };

#endif


 
