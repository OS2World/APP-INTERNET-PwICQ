/*
 * icqListBoxItem.h - Defines for pwICQ's Listbox item
 */
 
#ifndef ICQLISTBOXITEM_INCLUDED

   #define ICQLISTBOXITEM_INCLUDED 1
   
   #include <qlistbox.h>
   #include <qpainter.h>
   #include "icqevent.h"
   #include "icqlistbox.h"
   #include "icqkde.h"

   #pragma pack()
   
   class ICQListBoxItem : public QListBoxItem 
   {
   
   public:
      ICQListBoxItem( ICQListBox *, HICQ, HUSER );
      ~ICQListBoxItem();

	  void 	userEvent(ICQEvent *);
	  
	  ULONG 		getUIN();
	  HUSER 		getUser();
      const char *	getNickname();
      int 			getIconSize() const;
	  bool			getBlink();

	  void		    setIcon(USHORT);
	  bool			setBlink(bool);

	  QString 		text() const;
      const QPixmap pixmap();

	  void 			paint(QPainter *);
	  int 			height( const QListBox * ) const;
	  void			updateKey();
      ICQListBox *  listBox() const;
	  
	  void			messageChanged();
	  
	  void			popupMenu();
	  void			executed();

   private:
   
      HICQ			icq;
      HUSER			usr;
	  ULONG 		uin;
	  USHORT		icon;
	  bool			blink;
	  char			key[20];
	  
   };

#endif 
