/* * icqlistbox.cc 
 */
 
 #include "icqlistbox.h"
 #include "icqlistboxitem.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 

 ICQListBox::ICQListBox( QWidget *parent, HICQ icq ) 
 : KListBox ( parent )
 {
	CHKPoint();
	this->icq     = icq;
	pendingUpdate = 0;
	animate		  = -1;
	 
	connect(	this,
				SIGNAL(rightButtonPressed(QListBoxItem *, const QPoint &)),
				this,
				SLOT(showUserMenu(QListBoxItem *)) );
	
	connect(	this,
				SIGNAL(executed(QListBoxItem *, const QPoint &)),
				this,
				SLOT(executed(QListBoxItem *)) );
	
	setBlinkON();
	
 }
 
 void ICQListBox::insert(HUSER usr)
 {
#ifdef USE_ICQLISTBOXITEM	
    if(!(usr->flags& USRF_HIDEONLIST))
       new ICQListBoxItem(this, icq, usr);
#endif	
 }

 ICQListBox::~ICQListBox()
 {
	CHKPoint();
 }

 void ICQListBox::procEvent(ICQEvent *ev)
 {
    Q_CHECK_PTR(ev);
	
    switch( ev->getType())
	{
	case 'S':
	   systemEvent(ev);
	   break;

	case 'U':
	   userEvent(ev);
	   break;
	
	case 'G':
	   internalEvent(ev);
	   break;
		 
    }
 }

 void ICQListBox::internalEvent(ICQEvent *evt)
 {
   switch(evt->getEventCode())
   {
   case 1:
	  DBGMessage("Mudar o modo de filtragem");
      break;
   
   case 4:	/* Blink */
	  if( (animate >= 0) && !(evt->getParm()%5))
	     doBlink();
	  break;
   
   }
	
 }

 void ICQListBox::systemEvent(ICQEvent *evt)
 {
   /*
    * Take actions based on pwICQ Events
    */
   switch(evt->getEventCode())
   {
   case ICQEVENT_ONLINE:
   case ICQEVENT_OFFLINE:
	  updateUsers();
      break;
	  
   case ICQEVENT_SECONDARY:		
      for(HUSER usr = icqQueryFirstUser(icq);usr;usr=icqQueryNextUser(icq,usr))
	     insert(usr);
	  break;

   case ICQEVENT_TIMER:
	  delayedUpdate();
      break;
   }
 }

 void ICQListBox::userEvent(ICQEvent *evt)
 {
#ifdef USE_ICQLISTBOXITEM	
	
    for(unsigned int i = 0; i < count(); i++ ) 
	{
	   ICQListBoxItem *itn = (ICQListBoxItem *) item(i);
	   
       Q_CHECK_PTR(itn);
	   
	   if(evt->getUIN() == itn->getUIN())
	   {
	      itn->userEvent(evt);
		  return;
	   }
	}
	
#endif	
	
	/* Verifica se e necessario anexar usuario a lista */
	
 }

 void ICQListBox::setBlinkON()
 {
	if(animate < 0)
	{
	   DBGMessage("Iniciar piscagem");
	   animate = 0;
	}
 }
 
 void ICQListBox::userPosChanged()
 {
	pendingUpdate |= 1;
 }
 
 void ICQListBox::userIconChanged()
 {
	pendingUpdate |= 2;
 }

 void ICQListBox::delayedUpdate()
 {
	if(pendingUpdate & 1)
	{
	   DBGMessage("Reordenar a lista");
       sort();
       repaintContents(FALSE);
	}
	else if(pendingUpdate & 2)
	{
	   DBGMessage("Repintar a janela");
       repaintContents(FALSE);
    }
	pendingUpdate = 0;
	
 }  
 
 void ICQListBox::updateUsers()
 {
    CHKPoint();
#ifdef USE_ICQLISTBOXITEM	
	
    for ( unsigned int i = 0; i < count(); i++ ) 
	{
	   ICQListBoxItem *itn = (ICQListBoxItem *) item(i);
       Q_CHECK_PTR(itn);
	   itn->updateKey();
	}
	
#endif	
 }

 void ICQListBox::showUserMenu( QListBoxItem *itn )
 {
	if(!itn)
	   return;
	
#ifdef USE_ICQLISTBOXITEM	
	( (ICQListBoxItem *) itn )->popupMenu();
#endif	
	
 }

 void ICQListBox::executed( QListBoxItem *itn )
 {
	if(!itn)
	   return;
	
#ifdef USE_ICQLISTBOXITEM	
	( (ICQListBoxItem *) itn )->executed();
#endif	
	
 }
 
 void ICQListBox::doBlink()
 {
	bool blink = false;
	
    for ( unsigned int i = 0; i < count(); i++ ) 
	{
	   ICQListBoxItem *itn = (ICQListBoxItem *) item(i);
       Q_CHECK_PTR(itn);
       blink |= itn->setBlink(animate);
	}

	if(!blink)
	{
	   DBGMessage("Encerrar animacao");
	   animate = -1;
	}
	else
	{
       animate ^= 1;
       repaintContents(FALSE);
	}
 }
