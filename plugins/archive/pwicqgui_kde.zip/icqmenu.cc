/*
 * icqmenu.cc
 */

 #include <string.h>
 #include <stdio.h>
 
 #include "icqmenu.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 

 ICQMenu::ICQMenu( HICQ icq, const char *text, QPushButton *button ) : QWidget( 0, 0 )
 {

	this->icq = icq;
	
    popup = new KPopupMenu( this );
	
    Q_CHECK_PTR( popup );

	if(text)
       popup->insertTitle(text,0);
	   
	if(button)
	   button->setPopup(popup);
	
    connect(popup, SIGNAL(activated(int)), this, SLOT(setSelected(int)));	
 }
 
 void ICQMenu::setTitle(const char *text)
 {
	return popup->changeTitle(0, text);
 }

 int ICQMenu::insertItem( USHORT icon, const char *descr, const QObject *receiver, const char *member)
 {
	return popup->insertItem(icqkde_pixmap(icon), descr, receiver, member);
 }

 void ICQMenu::setSelected(int id)
 {
    this->selected = id;
 }
 
 int ICQMenu::loadOptions()
 {
	DBGMessage("ICQMenu::loadOptions()");
    return 0;
 }

 int  ICQMenu::getSelected()
 {
	return selected;
 }

 HICQ ICQMenu::getICQ()
 {
	return icq;
 }
 
 KPopupMenu * ICQMenu::getPopup()
 {
	return popup;
 }

 void ICQMenu::log(const char *text)
 {
	icqWriteSysLog(icq,PROJECT,text);
 }

 void ICQMenu::exec()
 {
    popup->exec(QCursor::pos());
 }

 void ICQMenu::exec(ULONG uin)
 {
	setUIN(uin);
	exec();
 }

 ULONG ICQMenu::getUIN()
 {
	return uin;
 }

 HUSER ICQMenu::getUser()
 {
	return icqQueryUserHandle(icq,uin);
 }

 void ICQMenu::setUIN(ULONG uin)
 {
	HUSER usr = icqQueryUserHandle(icq,uin);
	char  buffer[0x0100];
	
	this->uin = uin;
	
	if(usr)
	{
	   strncpy(buffer,icqQueryUserNick(usr),80);
	   sprintf(buffer+strlen(buffer)," (ICQ#%ld)",usr->uin);
	   setTitle(buffer);
	}
	
 }

