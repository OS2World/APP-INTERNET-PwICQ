/*
 * icqevent.cc - pwICQ event's dispatcher
 */

 #include <qthread.h>
 
 #include "icqmainwindow.h"

/*---[ Implementacao ]---------------------------------------------------------------*/
 
 ICQEvent::ICQEvent(HICQ icq, unsigned long uin, char type, unsigned short event, unsigned long parm )
 : QEvent ( QEvent::User ) 
 {
	this->icq   = icq;
	this->uin   = uin;
	this->type  = type;
	this->event = event;
	this->parm  = parm;

 }
 
 int ICQEvent::post()
 {
    ICQMainWindow *wnd = (ICQMainWindow *) icqGetSkinDataBlock(icq);
	if(wnd)
	{
       QThread::postEvent( wnd, this);
	   return 0;
	}
	return -1;
 }
 
 bool ICQEvent::isUser()
 {
    return type == 'U';	
 }
	
 bool ICQEvent::isSystem()
 {
    return type == 'S';	
 }

 int ICQEvent::getType()
 {
	return (int) type;
 }
 
 int ICQEvent::getEventCode()
 {
	return (int) event;
 }
 
 unsigned long ICQEvent::getUIN()
 {
	return uin;
 }

 unsigned long ICQEvent::getParm()
 {
	return parm;
 }

 HUSER ICQEvent::getUser()
 {
	return icqQueryUserHandle(icq,getUIN());
 }  

 HICQ ICQEvent::getICQ()
 {
	return icq;
 }
 
