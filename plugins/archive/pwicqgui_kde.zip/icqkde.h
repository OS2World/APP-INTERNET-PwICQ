/*
 * icqkde.h - Definitions for the pwICQ KDE Interface plugin
 */
 
#ifndef ICQKDE_INCLUDED 

 #define ICQKDE_INCLUDED 1
 
 #include <qpixmap.h>
 
 #include <stdio.h>
 #include <icqtlkt.h>

#ifdef __cplusplus
   extern "C" {
#endif

   int 			 icqkde_register(HICQ);
   const QPixmap icqkde_pixmap(USHORT);
   int			 icqkde_getIconSize(void);
   

   #define STATIC_REGISTER(i) icqkde_register(i)
	  
#ifdef __cplusplus
   }
#endif

   extern HICQ pwICQHandler;
   
   
#endif
