/*
 * icqlistbox.h
 */
 
#ifndef ICQLISTBOX_INCLUDED

   #include <klistbox.h>

   #define ICQLISTBOX_INCLUDED 1

   #include "icqevent.h"
   #include "icqkde.h"

   #pragma pack()
   

   #define USE_ICQLISTBOXITEM

   class ICQListBox : public KListBox
   {
      Q_OBJECT

   public:

      ICQListBox( QWidget *, HICQ );
	  ~ICQListBox();
	  
	  void insert(HUSER usr);
	  void userPosChanged();
	  void userIconChanged();
	  void delayedUpdate();
      void updateUsers();
	  void setBlinkON();

	  void procEvent(ICQEvent *);

   public slots:
	  
	  void showUserMenu( QListBoxItem * );
	  void executed( QListBoxItem * );
	  
   private:
	  
      HICQ      icq;
	  int		pendingUpdate;
	  short 	animate;

	  void 		userEvent(ICQEvent *);
	  void 		systemEvent(ICQEvent *);
	  void      internalEvent(ICQEvent *);
	  void		doBlink();

	  
   };

#endif   
