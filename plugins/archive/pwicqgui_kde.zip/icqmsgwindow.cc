/*
 * icqmessagewindow.cc
 */
 
 #include <qpushbutton.h>
 #include <qlabel.h>
 #include <qlayout.h>
 #include <qframe.h>
 #include <qvbox.h>
 #include <klineedit.h>
 #include <qgroupbox.h>
 #include <qhgroupbox.h> 
 
 #include "icqmsgwindow.h"
 
 #include "icqkde.h"

/*---[ Constants ]-------------------------------------------------------------------*/

 static const char *stringtable[] = { "Close",
    							      "ICQ#:",
    							      "",
     							     "Nick:",
    							      "",
    							      "Name:",
    							      "",
    						          "E-Mail:",
    							      "",
    							      "",
    							      "",
    							      "",
    							      "",
    							      "Accept",
    							      "Reject",
    							      "Refuse",
    							      "Reply",
    							      "Add user",
    							      "",
    							      "Browse",
    							      "Subject:",
    							      "",
    							      "Next",
    							      "Send",
    							      "Open",
    							      "Send to",
    							      
    							      "Date:",
    							      "Auto-Open",
    							      "Urgent",
    							      "Authorize"
 							   };

 static const USHORT topLabel[] = { ICQMSGC_STATICUIN,
                                     ICQMSGC_STATICNICK,
                                     ICQMSGC_STATICNAME,
                                     ICQMSGC_STATICEMAIL,
                                     0
                                   };

 static const USHORT topField[] = { ICQMSGC_UIN, 
 							         ICQMSGC_NICKNAME, 
 							         ICQMSGC_NAME, 
 							         ICQMSGC_EMAIL, 
 							         0 
 							      };
    
 static const USHORT buttons[]   = { ICQMSGC_NEXT,
 									 ICQMSGC_ACCEPT,
 									 ICQMSGC_REJECT,
 									 ICQMSGC_REFUSE,
 									 ICQMSGC_REPLY,
 									 ICQMSGC_ADD,
 									 ICQMSGC_SEND,
 									 ICQMSGC_BROWSE,
 									 ICQMSGC_OPEN,
 									 ICQMSGC_SENDTO,
 									 0
 								   };
							   
/*---[ Implementacao ]---------------------------------------------------------------*/

 ICQMessageWindow::ICQMessageWindow( QWidget *parent, ICQMessageEvent *evt)
 : KMainWindow( parent )
 {
	CHKPoint();

	this->uin = evt->getUIN();
    this->icq = evt->getICQ();
	
	resize(300,200);
	createChilds();
	
 }

 ICQMessageWindow::~ICQMessageWindow()
 {
	DBGMessage("Message Window Closed");
	
 }
 
 const char *ICQMessageWindow::getString(USHORT id)
 {
	return stringtable[id];
 }

 QWidget *ICQMessageWindow::getWidget(USHORT id)
 {
	return wnd[id];
 }
 
 void ICQMessageWindow::createChilds()
 {
	/* Topo da tela */
	QGridLayout *topLayout = new QGridLayout(this,3,4);

	/* Cria labels */
	for(int f=0;topLabel[f];f++)
	   wnd[topLabel[f]] = new QLabel(getString(topLabel[f]),this);
	
	/* Cria texts-boxes */
	for(int f=0;topField[f];f++)
	   wnd[topField[f]] = new KLineEdit(getString(topField[f]),this);

    topLayout->addWidget( getWidget(ICQMSGC_STATICNICK),  0, 0, Qt::AlignLeft|Qt::AlignVCenter);
    topLayout->addWidget( getWidget(ICQMSGC_NICKNAME),    0, 1, 0);
    topLayout->addWidget( getWidget(ICQMSGC_STATICNAME),  0, 2, Qt::AlignLeft|Qt::AlignVCenter);
    topLayout->addWidget( getWidget(ICQMSGC_NAME),        0, 3, 0);

    topLayout->addWidget( getWidget(ICQMSGC_STATICUIN),   1, 0, Qt::AlignLeft|Qt::AlignVCenter);
    topLayout->addWidget( getWidget(ICQMSGC_UIN),         1, 1, 0);
    topLayout->addWidget( getWidget(ICQMSGC_STATICEMAIL), 1, 2, Qt::AlignLeft|Qt::AlignVCenter);
    topLayout->addWidget( getWidget(ICQMSGC_EMAIL),       1, 3, 0);
	/* Caixa central */

	/* Caixa inferior */
	
 }

 
 
 
