/*
 * icqmenu.cc
 */

 #include "icqmainwindow.h"
 #include "icqsysmenu.h"
 #include "icqkde.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 

 ICQSysMenu::ICQSysMenu( HICQ icq, const char *text, QPushButton *button )
 : ICQMenu( icq, text, button ) 
 {
 }
 
 int ICQSysMenu::loadOptions()
 {
	DBGMessage("ICQSysMenu::loadOptions()");

	insertItem( 27, "Configure", 		this, SLOT(configure()));
	insertItem( 38, "Disconnect", 		this, SLOT(disconnect()));
	insertItem( 16, "Update all users", this, SLOT(updateAll()));
	insertItem( 17, "Shutdown", 		this, SLOT(shutdown()));
	
	return 0;
 }

 void ICQSysMenu::configure()
 {
	log("Opening configuration window");
//	icqOpenConfigDialog(getICQ(),0,ICQCONFIGW_SYSTEM,NULL);
 }
 
 void ICQSysMenu::disconnect()
 {
	log("Disconnecting by user request");
	icqDisconnect(getICQ());
 }
 
 void ICQSysMenu::updateAll()
 {
	HICQ icq = getICQ();
	
	log("Updating all users");
	
	for(HUSER usr = icqQueryFirstUser(icq);usr;usr=icqQueryNextUser(icq,usr))
	   usr->flags |= USRF_REFRESH;
 }
 
 void ICQSysMenu::shutdown()
 { 
    icqEvent(getICQ(),0,'G',2,0);
 }

