
#ifndef ICQMESSAGEWINDOW_INCLUDED

   #define ICQMESSAGEWINDOW_INCLUDED 1

   #include <qwidget.h>
   #include <kmainwindow.h>
   
   #include "icqmessageevent.h"
   
   #include <msgdlg.h>
   
   #define USE_ICQLISTBOX
   
   #pragma pack()

   class ICQMessageWindow : public KMainWindow
   {
      Q_OBJECT

   public:
	  
	  ICQMessageWindow(QWidget* parent, ICQMessageEvent *);
	  ~ICQMessageWindow();
	  
	  QWidget    *getWidget(USHORT);
	  const char *getString(USHORT);
	  
	  
   private:

	  void createChilds();

	  QWidget			*wnd[ICQMSGC_WIDGETS];
      HICQ				icq;
      unsigned long		uin;
	  
   };

#endif

