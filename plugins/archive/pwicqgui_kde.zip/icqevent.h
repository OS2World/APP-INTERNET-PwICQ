/*
 * icqevent.h - icqEventObject
 */

#ifndef ICQEVENT_INCLUDED

   #define ICQEVENT_INCLUDED 1

   #include <qevent.h>
   #include <icqtlkt.h>
   
   class ICQEvent : public QEvent
   {
   public:
   
      ICQEvent(HICQ, unsigned long, char, unsigned short, unsigned long  );
   
	  int  			post();
	  bool 			isUser();
	  bool 			isSystem();

	  int  			getType();
	  int   		getEventCode();
	  unsigned long getUIN();
      HUSER 		getUser();
	  unsigned long getParm();
	  HICQ			getICQ();

   private:

      HICQ				icq;
      unsigned long		uin;
      char				type;
      unsigned short	event;
      unsigned long		parm;

	  
   };
   
#endif   


