/*
 * tools.cc - Ferramentas de apoio
 */
 
 #include "icqmainwindow.h"
 #include "icqkde.h"
 
/*---[ Implementacao ]-----------------------------------------------------------*/ 

 const QPixmap icqkde_pixmap(USHORT id)
 {
	ICQMainWindow *wnd = (ICQMainWindow *) icqGetSkinDataBlock(pwICQHandler);
    Q_CHECK_PTR( wnd );
	return wnd->getPixmap(id);
 }

 int icqkde_getIconSize(void)
 {
	ICQMainWindow *wnd = (ICQMainWindow *) icqGetSkinDataBlock(pwICQHandler);
    Q_CHECK_PTR( wnd );
	return wnd->getIconSize();
 }
