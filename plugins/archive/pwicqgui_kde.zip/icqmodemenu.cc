/*
 * icqmenu.cc
 */
 
 #include "icqmodemenu.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 

 ICQModeMenu::ICQModeMenu( HICQ icq, const char *text, QPushButton *button )
 : ICQMenu( icq, text, button ) 
 {
 }
 
 int ICQModeMenu::loadOptions()
 {
    KPopupMenu *popup = getPopup();
	
	DBGMessage("ICQModeMenu::loadOptions()");
	
    for(const ICQMODETABLE *mode = icqQueryModeTable(getICQ()); mode && mode->descr; mode++)
       popup->insertItem( icqkde_pixmap(mode->icon), mode->descr, this, SLOT(setOnlineMode()), 0, (int) mode->mode );

	return 0;
 }

 void ICQModeMenu::setOnlineMode()
 {
	DBGTracex(getSelected());
	icqSetOnlineMode(getICQ(),getSelected());
 }
 
