/*
 * icqmenu.cc
 */
 
 #include "icqusermenu.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 

 ICQUserMenu::ICQUserMenu( HICQ icq, const char *text, QPushButton *button )
 : ICQMenu( icq, text, button ) 
 {
 }
 
 int ICQUserMenu::loadOptions()
 {
    KPopupMenu *popup = getPopup();

	DBGMessage("ICQUserMenu::loadOptions()");
	
/*
   icqgtk_addMenuOption(wnd, ICQMENU_USER,  0, icqgtk_usermenu, "Send Message");
   icqgtk_addMenuOption(wnd, ICQMENU_USER,  2, icqgtk_usermenu, "Send URL");
   icqgtk_addMenuOption(wnd, ICQMENU_USER,  8, icqgtk_usermenu, "Ask for authorization");
   icqgtk_addMenuOption(wnd, ICQMENU_USER, 29, icqgtk_usermenu, "Send authorization");
   icqgtk_addMenuOption(wnd, ICQMENU_USER, 16, icqgtk_usermenu, "Update basic info");
   icqgtk_addMenuOption(wnd, ICQMENU_USER, 17, icqgtk_usermenu, "Remove from list");
*/

    popup->insertItem( icqkde_pixmap(0),  "Send Message",           this, SLOT(sendMessage()), 0, (int) 0 );
    popup->insertItem( icqkde_pixmap(2),  "Send URL",               this, SLOT(sendMessage()), 0, (int) MSG_URL );
    popup->insertItem( icqkde_pixmap(8),  "Ask for Authorization",  this, SLOT(sendMessage()), 0, (int) MSG_REQUEST );
    popup->insertItem( icqkde_pixmap(29), "Send Authorization",     this, SLOT(sendMessage()), 0, (int) MSG_AUTHORIZED );

    popup->insertItem( icqkde_pixmap(16), "Update basic info",      this, SLOT(updateUser()), 0, (int) 10000 );
    popup->insertItem( icqkde_pixmap(17), "Remove from list",       this, SLOT(deleteUser()), 0, (int) 10001 );

	return 0;
 }
 
 void ICQUserMenu::sendMessage()
 {
	icqNewUserMessage(getICQ(),getUIN(),getSelected(),0,0);
 }

 void ICQUserMenu::updateUser()
 {
	icqRequestUserUpdate(getICQ(),getUIN());
 }
 
 void ICQUserMenu::deleteUser()
 {
	CHKPoint();
 } 


