/*
 * execute.cc
 */
 
 #include <kapp.h>
 #include <qpixmap.h>
 #include <qimage.h>
 #include <pwmacros.h>

 #include "icqmainwindow.h"
 #include "icqkde.h" 
 #include "icqevent.h"
 #include "icqmessageevent.h"
 
/*---[ Entry points ]------------------------------------------------------------*/ 

extern "C" {

 static ULONG _System icqkde_load(HICQ, STATUSCALLBACK *, int, char **);
 static int   _System icqkde_execute(HICQ,ULONG);
 static int   _System icqkde_event(HICQ,ULONG,char,USHORT,ULONG,void *);
 static int   _System icqkde_validateEdit(USHORT);
 static int   _System icqkde_insertListener(HICQ, void (_System *)(HICQ,ULONG,char,USHORT,ULONG,void *),void *);
 static int   _System icqkde_removeListener(HICQ, void (_System *)(HICQ,ULONG,char,USHORT,ULONG,void *),void *);
   
 static int   _System popupMenu(HICQ, ULONG, USHORT);
 static void  _System view(HICQ, ULONG, HMSG);
 static void  _System newMessage(HICQ,ULONG,USHORT,const char *, const char *);

 static  const SKINMGR icqkde_entry = {      
						 sizeof(SKINMGR),
						 SKINMGR_HASTIMER,		// flags
						 "KDE3",
						 icqkde_load,			// loadSkin,
						 icqkde_execute,		// executeSkin,
						 NULL,					// timer,
						 NULL,					// warning
						 view,					// view
						 newMessage,   			// newMessage
						 NULL,					// awayMessage
						 popupMenu, 			// popupmenu
						 NULL,					// popupUserList
						 NULL,					// insertMenu,
						 NULL,					// openConfig,
						 icqkde_validateEdit,	// validateEdit,
						 icqkde_event 			// event,
                       };
	  
	  
 }

 static KApplication 	*apps  		 = NULL;
 HICQ 					pwICQHandler = 0;

/*---[ Implementacao ]-----------------------------------------------------------*/ 
 
 int icqkde_register(HICQ icq)
 {
	char buffer[10];

	pwICQHandler = icq;
    icqLoadString(icq, "gui", "kde", buffer, 9);

	if(stricmp(buffer,"kde"))
	   return -2;
	
	
    CHKPoint();
    return icqRegisterSkinManager(icq,&icqkde_entry);
 }
 
 static ULONG _System icqkde_load(HICQ icq, STATUSCALLBACK *status, int numpar, char **param)
 {
	apps = new KApplication(numpar,param,"pwICQ");
	
	DBGTracex(apps);
	
	if(!apps)
	   return 0;
	
	/* Cria a janela principal */
	
	ICQMainWindow *mainWindow = new ICQMainWindow( "pwICQ", icq );
	Q_CHECK_PTR(mainWindow);
	if(!mainWindow)
	   return 0;

	mainWindow->resize( 70, 300);
    apps->setMainWidget(mainWindow);

	if(icqInitialize(icq,status))
	   return 0;

	return (ULONG) apps;
 }
 
 static int _System icqkde_execute(HICQ icq, ULONG app )
 {
	KApplication  *a 		= (KApplication *) app;
    return a->exec();
 }

 static int _System icqkde_event(HICQ icq, ULONG uin, char type, USHORT event, ULONG parm, void *dataBlock)
 {
    return (new ICQEvent(icq, uin, type, event, parm))->post();
 }

 static int _System icqkde_validateEdit(USHORT sz)
 {
    if(sz != sizeof(MSGEDITHELPER))
       return 2;
    return 0;
 }

 int _System icqkde_insertListener(HICQ icq, void (_System *callBack)(HICQ,ULONG,char,USHORT,ULONG,void *),void *dataBlock)
 {
	
	NOT_IMPLEMENTED
	
	return 0;
 }
 
 int _System icqkde_removeListener(HICQ icq, void (_System *callBack)(HICQ,ULONG,char,USHORT,ULONG,void *),void *dataBlock)
 {
	
	NOT_IMPLEMENTED
	
	return 0;
 }

 static int _System popupMenu(HICQ icq, ULONG uin, USHORT id)
 {
    return (new ICQEvent(icq, uin, 'G', 3, (unsigned long) id))->post();
 }
 
 static void  _System view(HICQ icq, ULONG uin, HMSG msg)
 {
    ICQMessageEvent *evt = new ICQMessageEvent(icq, uin, msg);
	evt->post();
 }
 
 static void _System newMessage(HICQ icq, ULONG uin, USHORT type, const char *text, const char *url)
 {
    ICQMessageEvent *evt = new ICQMessageEvent(icq, uin, type, text, url);
	evt->post();
 }

