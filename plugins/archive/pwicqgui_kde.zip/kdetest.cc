/*
 * kdetest.c - Teste de uso do KDE
 */
 
 #include <kapp.h>
 
 #include "icqkde.h"

/*---[ Prototipos ]------------------------------------------------------------------*/


/*---[ Implementacao ]---------------------------------------------------------------*/

 int main( int argc, char **argv )
 {
    KApplication a( argc, argv, PROJECT);
 
    ICQMainWindow *window= new ICQMainWindow( "Teste KDE", NULL );
	
    window->resize( 140, 300 );
 
    a.setMainWidget( window );
    window->show();
 
    return a.exec();
 }

