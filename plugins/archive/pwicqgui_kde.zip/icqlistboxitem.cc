/*
 * icqlistboxitem.cc
 */

 #include <qapp.h>
 #include "icqlistboxitem.h"

/*---[ Implementacao ]-----------------------------------------------------------*/ 
 
 ICQListBoxItem::ICQListBoxItem(ICQListBox *listbox, HICQ icq, HUSER usr ) 
 :  QListBoxItem( listbox )
 {
    this->icq     = icq;
	this->usr     = usr;
	this->uin     = usr->uin;
	this->icon    = usr->modeIcon;
	updateKey();
	messageChanged();
 }

 ICQListBoxItem::~ICQListBoxItem()
 {

 }
 
 ULONG ICQListBoxItem::getUIN()
 {
	return uin;
 }
 
 HUSER ICQListBoxItem::getUser()
 {
	return usr;
 }

 QString ICQListBoxItem::text() const
 {
	return key;
 } 

 const char * ICQListBoxItem::getNickname()
 {
    return icqQueryUserNick(getUser());
 } 
 
 const QPixmap ICQListBoxItem::pixmap()
 {
    return icqkde_pixmap(icon);
 }  
 
 void ICQListBoxItem::paint(QPainter *painter)
 {
    painter->drawPixmap (2,2, pixmap());
	
	if(blink)
       painter->drawPixmap(2,2, icqkde_pixmap(usr->eventIcon));

    QFontMetrics fm = painter->fontMetrics();
    painter->drawText( getIconSize(), fm.ascent() +  (fm.leading()+1)/2 + 1, getNickname() );
 }

 int ICQListBoxItem::height( const QListBox * lb ) const
 {
    int h   = lb ? lb->fontMetrics().lineSpacing() + 2 : 0;
	int ret = QMAX( h, QApplication::globalStrut().height() );
	return QMAX(ret, getIconSize());
 }

 int ICQListBoxItem::getIconSize() const
 {
    return icqkde_getIconSize()+4;
 }

 void ICQListBoxItem::updateKey()
 {
	ICQListBox *lb = (ICQListBox *) listBox();

    Q_CHECK_PTR(lb);

	*key = usr->index + 'A';
	strncpy((key+1),getNickname(),18);
	
    lb->userPosChanged();
	
 }

 void ICQListBoxItem::setIcon(USHORT icon)
 {
    ICQListBox *lb = (ICQListBox *) listBox();

    Q_CHECK_PTR(lb);
	
    this->icon = icon;
    lb->userIconChanged();
 }  
 
 void ICQListBoxItem::messageChanged()
 {
	if(getBlink())
	{
       ICQListBox *lb = (ICQListBox *) listBox();
       Q_CHECK_PTR(lb);
	   lb->setBlinkON();
	}
 }

 ICQListBox * ICQListBoxItem::listBox() const
 {
	return (ICQListBox *) QListBoxItem::listBox();
 }
 
 bool ICQListBoxItem::getBlink()
 {
    return usr->modeIcon != usr->eventIcon;
 }

 bool ICQListBoxItem::setBlink(bool blink)
 {
	if(!getBlink())
	{
	   this->icon = usr->modeIcon;
	   return false;
	}
	this->blink = blink;
	return true;
 }
 
 void ICQListBoxItem::userEvent(ICQEvent *evt)
 {
    Q_CHECK_PTR(evt);

    switch(evt->getEventCode())
	{
    case ICQEVENT_UPDATED:
	   usr = icqQueryUserHandle(icq,uin);
   	   updateKey();
	   break;
	   
    case ICQEVENT_ONLINE:
    case ICQEVENT_POSCHANGED:
   	   updateKey();
	   break;
	   
    case ICQEVENT_ICONCHANGED:
	   setIcon(usr->modeIcon);
	   break;
	   
    case ICQEVENT_OFFLINE:
    case ICQEVENT_SETOFFLINE:
	   setIcon(usr->offlineIcon);
   	   updateKey();
	   break;
	
    case ICQEVENT_HIDE:
    case ICQEVENT_DELETED:
	   delete this;
	   break;

    case ICQEVENT_MESSAGECHANGED:
	   DBGTrace(usr->modeIcon);
	   DBGTrace(usr->eventIcon);
	   messageChanged();
       break;

	}
 }

 void ICQListBoxItem::popupMenu()
 {
	icqShowPopupMenu(icq,uin,ICQMENU_USER);
 }

 void ICQListBoxItem::executed()
 {
	icqOpenUserMessageWindow(icq,icqQueryUserHandle(icq,uin));
 }
 
