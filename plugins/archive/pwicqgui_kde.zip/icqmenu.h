/*
 * icqmenu.h - Classe para gerenciamento de menus
 */

#ifndef ICQMENU_INCLUDED

   #define ICQMENU_INCLUDED 1
   
   #include <kpopupmenu.h>
   #include <qpushbutton.h>
   #include <qcursor.h>

   #include "icqevent.h"
   #include "icqkde.h"

   #pragma pack()
   
   class ICQMenu : public QWidget
   {
      Q_OBJECT
	  
   public:

	  ICQMenu( HICQ icq, const char *text=0, QPushButton *button=0 );
	  
	  int  			loadOptions();
	  
	  int  			getSelected();
	  HICQ 			getICQ();
	  KPopupMenu * 	getPopup();
	  ULONG			getUIN();
	  HUSER			getUser();
	  void			setTitle(const char *);
	  
	  void			setUIN(ULONG);
	  
	  void			log(const char *);
	  void			exec();
	  void			exec(ULONG);
    
      int  insertItem(USHORT, const char *, const QObject *, const char *);
	  
   private:
	  
	  HICQ		 icq;
	  ULONG		 uin;
	  KPopupMenu *popup;
	  int		 selected;
	  
   public slots:
	  
	  void setSelected(int);
	  
   };

#endif


 
