/*
 * wxuserlist.cc - pwICQ userlist class implementation for wxWindows
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/

 BEGIN_EVENT_TABLE( pwICQUserList, wxListCtrl)
//    EVT_SIZE( pwICQUserList::OnResize )
 END_EVENT_TABLE()

/*---[ Prototipes ]---------------------------------------------------------------*/


/*---[ Implementation ]-----------------------------------------------------------*/

 // http://www.lpthe.jussieu.fr/~zeitlin/wxWindows/docs/wxwin237.htm
 
 pwICQUserList::pwICQUserList(pwICQWindow *hwnd, USHORT id)
 : wxListView(hwnd,id,wxDefaultPosition,wxDefaultSize,wxLC_REPORT|wxLC_NO_HEADER|wxLC_SINGLE_SEL) // wxLC_REPORT wxLC_LIST
 {
    pwICQapp *app = (pwICQapp *) icqGetSkinDataBlock(icq);
     
    SetImageList(app->getIcons(),wxIMAGE_LIST_SMALL); 
     
    InsertColumn(0, _T("ICQ Users"));
    SetColumnWidth(0,300);
     
    start();

 }

 pwICQUserList::~pwICQUserList()
 {
    stop();
 }
 
 void pwICQUserList::insertUser(HUSER usr)
 {
    int pos = GetItemCount();
    InsertItem(pos, icqQueryUserNick(usr), usr->modeIcon);
     
    SetItemData(pos, (long) usr);
 }
 
/*
 void pwICQUserList::OnResize( wxSizeEvent &evt )
 {
     wxSize sz = evt.GetSize();
     
     DBGTrace(sz.GetWidth());
     DBGTrace(sz.GetHeight());
     SetColumnWidth(0, sz.GetWidth());

 }
*/
