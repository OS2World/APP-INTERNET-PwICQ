/*
 * pwicqframe.cc - pwICQ frame class implementation
 */
 
 #include "pwicqgui.h" 

 #include <wx/event.h>
 
/*---[ Definitions ]--------------------------------------------------------------*/

/*---[ Event processing ]---------------------------------------------------------*/

 class pwICQEvent : public wxEvent
 {
 public:
     
    unsigned long  uin;
    char           id;  
    unsigned short event;
    unsigned long  parm;
     
    pwICQEvent();
    pwICQEvent(unsigned long, char, unsigned short, unsigned long);

    wxEvent * Clone(void) const;
        
 private:        

    DECLARE_DYNAMIC_CLASS( pwICQEvent )
 
 };

 typedef void (wxEvtHandler::*pwicqEventFunction)(pwICQEvent&);    
    
 BEGIN_DECLARE_EVENT_TYPES()
    DECLARE_EVENT_TYPE(wxEVT_PWICQEVENT, 7777)
 END_DECLARE_EVENT_TYPES()

 DEFINE_EVENT_TYPE(wxEVT_PWICQEVENT)

 #define EVT_PWICQ(fn) \
           DECLARE_EVENT_TABLE_ENTRY( \
           wxEVT_PWICQEVENT, wxID_ANY, -1, \
           (wxObjectEventFunction)(wxEventFunction)(pwicqEventFunction)&fn, \
           (wxObject *) NULL \
           ),

 BEGIN_EVENT_TABLE( pwICQFrame, wxFrame)
    EVT_BUTTON( ID_MODE, pwICQFrame::OnMode     ) 
    EVT_PWICQ(           pwICQFrame::OnICQEvent )
 END_EVENT_TABLE()

/*---[ Event class implementation ]-----------------------------------------------*/

 IMPLEMENT_DYNAMIC_CLASS( pwICQEvent, wxEvent )

 pwICQEvent::pwICQEvent()
 {
    CHKPoint();
    SetEventType( wxEVT_PWICQEVENT );
    SetEventObject( this );
 }

 pwICQEvent::pwICQEvent(unsigned long uin, char id, unsigned short event, unsigned long parm)
 {

    this->uin   = uin;
    this->id    = id;
    this->event = event;
    this->parm  = parm;
     
    SetEventType( wxEVT_PWICQEVENT );
    SetEventObject( this );
 }
 
 wxEvent * pwICQEvent::Clone(void) const 
 { 
    return new pwICQEvent(uin, id, event, parm); 
 }

/*---[ Frame class implementation ]----------------------------------------------*/

 pwICQFrame::pwICQFrame()  : wxFrame((wxFrame *)NULL, -1, "pwICQ", wxPoint(5,5), wxSize(160,400))
 {
     
    CHKPoint();
     
    panel = new wxPanel(  this, 
                          10, 
                          wxDefaultPosition, 
                          wxDefaultSize, 
                          wxTAB_TRAVERSAL, 
                          "pwICQ_MainPanel");
    /* Create the buttons */     

#ifdef ENABLE_WXTOGGLE_BUTTONS     
    allButton    = new wxToggleButton(panel, ID_ALL,    "All" );
    onlineButton = new wxToggleButton(panel, ID_ONLINE, "Online" );
#endif     
     
    cfgButton  = new pwICQButton(panel, ID_CONFIG,   0, "Config"  );
    modeButton = new pwICQButton(panel, ID_MODE,     0, "Offline" );

    /* Top box */
#ifdef ENABLE_WXTOGGLE_BUTTONS     
    top = new wxBoxSizer(wxHORIZONTAL);

    top->Add(     allButton,
                  1,
                  wxEXPAND|wxALL,
                  0,
                  NULL );
                  
    top->Add(     onlineButton,
                  1,
                  wxEXPAND|wxALL,
                  0,
                  NULL );
#endif

    /* Bottom box */ 
    bottom = new wxFlexGridSizer(1, 2, 2, 2);
    bottom->AddGrowableCol(1);     

    bottom->Add(  cfgButton,
                  0,
                  wxALL,
                  0,
                  NULL );
    bottom->Add(  modeButton,
                  0,
                  wxEXPAND,
                  0,
                  NULL );
     
    /* Vertical box */
#ifdef ENABLE_WXTOGGLE_BUTTONS     

    rows = new wxFlexGridSizer(5, 1, 2, 2);
    rows->AddGrowableRow(1);     
    rows->AddGrowableCol(0);     

    rows->Add(  top,
                1,
                wxEXPAND,
                0,
                NULL );

#else    

    rows = new wxFlexGridSizer(4, 1, 2, 2);
    rows->AddGrowableRow(0);     
    rows->AddGrowableCol(0);     
    
#endif

    userList =  new pwICQUserList(panel, ID_USERLIST);

    rows->Add(  userList,
                0,
                wxEXPAND,
                0,
                NULL );

    rows->Add(  new pwICQButton(panel, ID_SYSTEM, 0, "System"),
                0,
                wxEXPAND,
                0,
                NULL );

    rows->Add(  new pwICQButton(panel, ID_SEARCH, 0, "Search/Add"),
                0,
                wxEXPAND,
                0,
                NULL );
                
    rows->Add(  bottom,
                1,
                wxEXPAND,
                0,
                NULL );
     
    panel->SetSizer( rows );      // use the sizer for layout
    
    ((pwICQapp *) icqGetSkinDataBlock(icq))->setFrame(this);
    
//    menu[0] = new wxMenu("Test");
    
    DBGMessage("Main window created");
 }

 pwICQFrame::~pwICQFrame()
 { 
    CHKPoint();
    
    ((pwICQapp *) icqGetSkinDataBlock(icq))->setFrame(NULL);

/*    
    delete userList;

#ifdef ENABLE_WXTOGGLE_BUTTONS     
    delete allButton;
    delete onlineButton;
    delete top;
#endif     

    delete bottom;
    delete rows;
    delete panel;
    delete cfgButton;
    delete modeButton;
*/
    
    DBGMessage("Main Window destroyed");
 }
 
 void pwICQFrame::OnICQEvent( wxEvent & event)
 {
    pwICQEvent *evt = (pwICQEvent *) event.GetEventObject();
     
    if(evt->id == 'S') 
       SystemEvent(evt->event,evt->parm);
     
    icqExecuteGuiListeners(icq, evt->uin, evt->id, evt->event, evt->parm);
 }

 void pwICQFrame::OnMode( wxCommandEvent & event )
 {
    CHKPoint();   
 }
  
 void pwICQFrame::postICQEvent(unsigned long uin, char id, unsigned short event, unsigned long parm)
 {
    pwICQEvent evtObject(uin,id,event,parm);
    AddPendingEvent(evtObject);
 } 

/* 
	Hi,

	I'm trying to add a popup menu in my first wxWindows application but, when compiling I'm getting the error below:

/usr/bin/ld: wxicqgtk.so: undefined versioned symbol name wxMenuItemList::~wxMenuItemList [in-charge]()@@WXGTK_2.4
/usr/bin/ld: failed to set dynamic section sizes: Bad value
collect2: ld returned 1 exit status
make: *** [wxicqgtk.so] Error 1

	Any clues?
*/
