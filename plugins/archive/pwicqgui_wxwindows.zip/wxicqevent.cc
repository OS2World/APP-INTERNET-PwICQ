/*
 * wxicqevent.cc - pwICQ event class implementation
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/

/*---[ Prototipes ]---------------------------------------------------------------*/

/*---[ Implementation ]-----------------------------------------------------------*/

 IMPLEMENT_DYNAMIC_CLASS( pwICQEvent, wxEvent )

 pwICQEvent::pwICQEvent()
 {
    CHKPoint();
    SetEventType( wxEVT_PWICQEVENT );
 }

 pwICQEvent::pwICQEvent(wxWindow* win)
 {
    CHKPoint();
    SetEventType( wxEVT_PWICQEVENT );
    SetEventObject( win );
 }
 
 pwICQEvent::pwICQEvent(wxWindow* win, unsigned long uin, char id, unsigned short event, unsigned long parm)
 {
    DBGTracex(win);
     
    this->uin   = uin;
    this->id    = id;
    this->event = event;
    this->parm  = parm;
     
    SetEventType( wxEVT_PWICQEVENT );
    SetEventObject( win );
 }
 
 wxEvent * pwICQEvent::Clone(void) const 
 { 
    CHKPoint();
    return new pwICQEvent((wxWindow *) GetEventObject(), uin, id, event, parm); 
 }

/*
 void MyEvent::CopyObject( wxObject& obj_d ) const
 {
    wxEvent::CopyObject( obj_d );
 }
*/
