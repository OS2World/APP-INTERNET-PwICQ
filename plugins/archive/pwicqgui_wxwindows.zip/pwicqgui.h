/*
 * pwicqgui.h - pwICQ Classes for GUI interface module
 *
 * References:
 *
 * http://www.wxwindows.org/hello.htm
 *
 */
 
#ifndef PWICQGUI_INSTALLED  

/*---[ Define GUI Toolkit ]---------------------------------------------------------*/

 #ifdef WXWINDOWS 

    #include <wx/wx.h> 
    #include <wx/button.h> 
    #include <wx/listctrl.h>
    #include <wx/imaglist.h> 
    #include <wx/image.h>
    #include <wx/menu.h>
    #include <wx/menuitem.h>
    #include <wx/tglbtn.h>

    #define PWICQGUI_INSTALLED wxVERSION_STRING

    #define PARENT_APP         wxApp
    #define PARENT_FRAME       wxFrame
    #define PARENT_USERLIST    wxListView
    #define PARENT_BUTTON      wxButton
    #define PARENT_MENU        wxMenu
    
    #define pwICQWindow        wxWindow
    
//    #define ENABLE_WXTOGGLE_BUTTONS 1

 #endif 

/*---[ Verification/Includes ]------------------------------------------------------*/

 #ifndef PWICQGUI_INSTALLED  
    #error No GUI Toolkit defined
 #endif

 #include <icqtlkt.h>

/*---[ Plugin tables ]--------------------------------------------------------------*/

 extern const SKINMGR pwICQ_SKINMGRCAPS;

/*---[ Public variables ]-----------------------------------------------------------*/

 extern HICQ icq;
 
/*---[ Macros functions ]-----------------------------------------------------------*/

 #define writeSysLog(x)     icqWriteSysLog(icq,PROJECT,x)

 #ifdef EXTENDED_LOG
    #define writeExtendedLog(x) icqWriteSysLog(icq,PROJECT,x)
 #else
    #define writeExtendedLog(x) /* x */
 #endif
 
/*---[ Window elements ]------------------------------------------------------------*/

 #define ID_CONFIG          1000
 #define ID_MODE            1001
 #define ID_SYSTEM          1002
 #define ID_SEARCH          1003
 #define ID_ALL             1004
 #define ID_ONLINE          1005
 #define ID_USERLIST        1006
 
/*---[ Main application class ]-----------------------------------------------------*/

 class pwICQButton: public PARENT_BUTTON
 {
     
 public:
     pwICQButton(pwICQWindow *, USHORT, USHORT, const char *);
     
 #ifdef WXWINDOWS 
    DECLARE_EVENT_TABLE()
 #endif
     
 };
 
 class pwICQUserList: public PARENT_USERLIST
 {

 public:
    
    pwICQUserList(pwICQWindow *, USHORT);
    ~pwICQUserList(void);

    void UserEvent(ULONG, USHORT, ULONG);
    void SystemEvent(USHORT, ULONG);
    void loadUsers(void);
    void insertUser(HUSER);
     
 #ifdef WXWINDOWS 
    DECLARE_EVENT_TABLE()
 #endif
     
 private:
     
    int start(void);
    int stop(void);

 };

 class pwICQFrame: public PARENT_FRAME
 {
 private:
     
    pwICQUserList *userList;

 #ifdef ENABLE_WXTOGGLE_BUTTONS     
    wxToggleButton *allButton;
    wxToggleButton *onlineButton;
    wxBoxSizer     *top;
 #endif     

 #ifdef WXWINDOWS 
    wxFlexGridSizer *rows;
    wxFlexGridSizer *bottom;
    wxMenu          *menu[3];
    wxPanel         *panel;
 #endif    
    
    pwICQButton *cfgButton;
    pwICQButton *modeButton;

 public:

    pwICQFrame();
    ~pwICQFrame();
     
    void SystemEvent(USHORT, ULONG);
    void postICQEvent(unsigned long, char, unsigned short, unsigned long);
     
 #ifdef WXWINDOWS 
    void OnMode( wxCommandEvent& );
    void OnICQEvent( wxEvent & );
    DECLARE_EVENT_TABLE()
 #endif
    
     
 };

 class pwICQapp: public PARENT_APP
 {

 #ifdef WXWINDOWS 
     virtual bool OnInit();
     virtual int  OnExit();
 #endif

 public:

   int          start(void);
   int          stop(void);
   int          setFrame(pwICQFrame *);
   pwICQFrame * getFrame();
   void         postICQEvent(unsigned long, char, unsigned short, unsigned long);
   int          getIconHeight();

 #ifdef WXWINDOWS 
   wxImageList  *getIcons();
   wxBitmap     getBitmap(unsigned short);
 #endif
     
 private:
     
 #ifdef WXWINDOWS 
   wxImage      *baseIcons;
   wxImageList  *icons;
 #endif
     
   int          iconHeight;
     
   pwICQFrame *mainWindow;
     
   int initialize(int, char **);
   int terminate(void);
     
 };

#endif /* PWICQGUI_DEFINED */
 
