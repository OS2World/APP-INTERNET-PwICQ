/*
 * main.cc - wxWindows loader for pwicq
 */
 
 #include "pwicqgui.h" 

extern "C" {

/*---[ Prototipes ]---------------------------------------------------------------*/
    
 int EXPENTRY pwICQ_Configure(HICQ, HMODULE);
    
 static int   _System icqskin_execute(HICQ, ULONG);
 static ULONG _System icqskin_load(HICQ, STATUSCALLBACK *, int, char **);
 static int   _System icqskin_event(HICQ,ULONG,char,USHORT,ULONG,void *);

 static int           argc   = 0;
 static char          **argv = NULL;

/*---[ Entry points ]---------------------------------------------------------------*/

 const SKINMGR pwICQ_SKINMGRCAPS = {   sizeof(SKINMGR),
							           0,			        // flags
							           MODULE_ID,
                                       icqskin_load,        // load
                                       icqskin_execute,     // execute
                                       NULL,                // timer
                                       NULL,		        // warning
                                       NULL,		        // view
                                       NULL,	            // newMessage
                                       NULL,		        // awayMessage
					                   NULL,    	        // popupmenu
						               NULL,		        // popupUserList
                                       NULL,                // insertMenu
                                       NULL,                // openConfig
                                       NULL,                // validateEditHelper
                                       icqskin_event        // event
                                   };

 }


/*---[ Prototipes ]---------------------------------------------------------------*/



/*---[ Implementation ]-----------------------------------------------------------*/

 int EXPENTRY pwICQ_Configure(HICQ i, HMODULE module)
 {
    static const char *ident = "Initializing GUI Manager build " __DATE__ " " __TIME__ " (Using " PWICQGUI_INSTALLED ")"; 
     
    icq = i;
    icqWriteSysLog(icq,PROJECT,ident);

    if(!icqRegisterSkinManager(icq,&pwICQ_SKINMGRCAPS))
    {
       CHKPoint();
       writeSysLog("Can't register GUI Manager");
       return -1;
    }
    
    return 0;
 }

 static ULONG _System icqskin_load(HICQ i, STATUSCALLBACK *status, int numpar, char **param)
 {
    argc = numpar;
    argv = param;
    return 1;
 }
 
 static int _System icqskin_execute(HICQ i, ULONG id )
 {
    writeExtendedLog("Starting main loop");
     
    wxEntry(argc, argv);
     
    writeExtendedLog("Main loop terminated");
     
    return 0;
 }

 static int _System icqskin_event(HICQ icq, ULONG uin, char type, USHORT event, ULONG parm, void *dataBlock)
 {
    pwICQapp *app = (pwICQapp *) icqGetSkinDataBlock(icq);
    if(app)
       app->postICQEvent(uin, type, event, parm);
    return 0;
 }   
 
