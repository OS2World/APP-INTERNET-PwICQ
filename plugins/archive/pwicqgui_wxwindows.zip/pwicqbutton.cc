/*
 * pwicqbutton.cc - pwICQ button class implementation
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/


/*---[ Prototipes ]---------------------------------------------------------------*/


/*---[ Implementation ]-----------------------------------------------------------*/

 pwICQButton::pwICQButton(pwICQWindow *hwnd, USHORT id, USHORT bitmap, const char *txt)
 : wxButton(hwnd, id, txt, wxPoint(0,0))
 {
     
 }
