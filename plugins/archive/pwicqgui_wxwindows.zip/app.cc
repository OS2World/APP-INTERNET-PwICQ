/*
 * app.cc - pwICQFrame initialization (GUI Independent part)
 */
 
 #include "pwicqgui.h" 
 
/*---[ Publics ]------------------------------------------------------------------*/

 HICQ icq = NULL;

/*---[ Prototipes ]---------------------------------------------------------------*/


/*---[ Implementation ]-----------------------------------------------------------*/

 extern "C" {

 void _System icqGui_setStartupStage(HICQ icq, int sts)
 {
    DBGTrace(sts);
 }

 }
 
 int pwICQapp::initialize(int numpar, char **param)
 {
     DBGMessage(PWICQGUI_INSTALLED);
     DBGTracex(icq);
     DBGTracex(this);
     icqSetSkinDataBlock(icq,this);
     return 0;
 }

 int pwICQapp::terminate(void)
 {
     CHKPoint();
     
     
     return 0;
 }

 int pwICQapp::start(void)
 {
     CHKPoint();
     icqInitialize(icq,(STATUSCALLBACK *) icqGui_setStartupStage);
     return 0;
 }

 int pwICQapp::stop(void)
 {
     CHKPoint();
     icqSetSkinDataBlock(icq,NULL);
     
     
     return 0;
 }
 
 int pwICQapp::setFrame(pwICQFrame *frame)
 {
     mainWindow = frame; 
     return 0;
 }
 
 pwICQFrame * pwICQapp::getFrame(void)
 {
    return mainWindow;
 }   
 
 void pwICQapp::postICQEvent(unsigned long uin, char id, unsigned short event, unsigned long parm)
 {
    if(mainWindow)
       mainWindow->postICQEvent(uin, id, event, parm);
 } 

 int pwICQapp::getIconHeight()
 {
    return iconHeight;
 }
