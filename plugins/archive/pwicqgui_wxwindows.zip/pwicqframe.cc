/*
 * pwicqframe.cc - pwICQ frame class implementation
 */
 
 #include "pwicqgui.h" 

 #include <wx/tglbtn.h>
 
/*---[ Definitions ]--------------------------------------------------------------*/

 BEGIN_EVENT_TABLE( pwICQFrame, wxFrame)
 END_EVENT_TABLE()

/*---[ Prototipes ]---------------------------------------------------------------*/


/*---[ Implementation ]-----------------------------------------------------------*/

 pwICQFrame::pwICQFrame()  : wxFrame((wxFrame *)NULL, -1, "pwICQ", wxPoint(5,5), wxSize(160,400))
 {
     
    CHKPoint();
     
    wxPanel *panel = new wxPanel(  this, 
                                   10, 
                                   wxDefaultPosition, 
                                   wxDefaultSize, 
                                   wxTAB_TRAVERSAL, 
                                   "pwICQ_MainPanel");
    /* Create the buttons */     

#ifdef ENABLE_TOGGLE_BUTTONS     
    wxToggleButton *allButton    = new wxToggleButton(panel, ID_ALL,    "All" );
    wxToggleButton *onlineButton = new wxToggleButton(panel, ID_ONLINE, "Online" );
#endif     
     
    pwICQButton *cfgButton    = new pwICQButton(panel, ID_CONFIG,   0, "Config"  );
    pwICQButton *modeButton   = new pwICQButton(panel, ID_MODE,     0, "Offline" );

    /* Top box */
#ifdef ENABLE_TOGGLE_BUTTONS     
    wxBoxSizer *top      = new wxBoxSizer(wxHORIZONTAL);

    top->Add(     allButton,
                  1,
                  wxEXPAND|wxALL,
                  0,
                  NULL );
                  
    top->Add(     onlineButton,
                  1,
                  wxEXPAND|wxALL,
                  0,
                  NULL );
#endif

    /* Bottom box */ 
    wxFlexGridSizer *bottom = new wxFlexGridSizer(1, 2, 2, 2);
    bottom->AddGrowableCol(1);     

    bottom->Add(  cfgButton,
                  0,
                  wxALL,
                  0,
                  NULL );
    bottom->Add(  modeButton,
                  0,
                  wxEXPAND,
                  0,
                  NULL );
     
    /* Vertical box */
#ifdef ENABLE_TOGGLE_BUTTONS     

    wxFlexGridSizer *rows = new wxFlexGridSizer(5, 1, 2, 2);
    rows->AddGrowableRow(1);     
    rows->AddGrowableCol(0);     

    rows->Add(  top,
                1,
                wxEXPAND,
                0,
                NULL );

#else    

    wxFlexGridSizer *rows = new wxFlexGridSizer(4, 1, 2, 2);
    rows->AddGrowableRow(0);     
    rows->AddGrowableCol(0);     
    
#endif

    rows->Add(  new pwICQButton(panel, 12, 0, "bbb"),
                0,
                wxEXPAND,
                0,
                NULL );

    rows->Add(  new pwICQButton(panel, ID_SYSTEM, 0, "System"),
                0,
                wxEXPAND,
                0,
                NULL );

    rows->Add(  new pwICQButton(panel, ID_SEARCH, 0, "Search/Add"),
                0,
                wxEXPAND,
                0,
                NULL );
                
    rows->Add(  bottom,
                1,
                wxEXPAND,
                0,
                NULL );
     
    panel->SetSizer( rows );      // use the sizer for layout
    
    CHKPoint();
    
 }

 
 

 
