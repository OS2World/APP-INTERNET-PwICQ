/*
 * wxicqapp.cc - pwICQ class implementation for wxWindows
 */

 #include "pwicqgui.h"

/*---[ Implementation ]-----------------------------------------------------------*/

 IMPLEMENT_APP_NO_MAIN(pwICQapp)

 bool pwICQapp::OnInit()
 {
    if(initialize(argc,argv))
        return FALSE;

    /* Load icon bar */
    char fileName[0x0100];

    icqLoadString(icq,"image-files","",fileName,0xFF);

    if(!*fileName)
       icqQueryProgramPath(icq,"images",fileName,0xFF);

    strncat(fileName,"icons.gif",0xFF);
    DBGMessage(fileName);

    wxInitAllImageHandlers();

             baseIcons  = new wxImage(fileName);
             iconHeight = baseIcons->GetHeight();
    int      iconCount  = baseIcons->GetWidth()/iconHeight;
             icons      = new wxImageList(iconHeight,iconHeight,TRUE,iconCount);

    for(int f = 0; f < iconCount;f++)
       icons->Add(getBitmap(f)); 

    /* Create and initialize frame Window */
    pwICQFrame *frame = new pwICQFrame();
    start();
    SetTopWindow(frame);

    return TRUE;
 }

 int pwICQapp::OnExit()
 {
    DBGTracex(icq);
    terminate();
    return 0;
 }

 wxImageList *pwICQapp::getIcons()
 {
    return icons;
 }

 wxBitmap pwICQapp::getBitmap(unsigned short pos)
 {
    wxRect rect = wxRect(pos*iconHeight, 0, iconHeight, iconHeight);
    return wxBitmap(baseIcons->GetSubImage(rect));
 }

