/*
 * wxicqmenu.cc - Implements pwICQMenu for wxWindows
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/


/*---[ Event Table ]--------------------------------------------------------------*/


BEGIN_EVENT_TABLE(pwICQMenu,wxMenu)
END_EVENT_TABLE()

/*---[ Implementation ]-----------------------------------------------------------*/

 pwICQMenu::pwICQMenu(const char *title)
 : wxMenu(title)
 {
    
 }

 
