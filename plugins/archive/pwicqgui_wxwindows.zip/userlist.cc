/*
 * userlist.cc - pwICQ userlist class implementation
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/

/*---[ Prototipes ]---------------------------------------------------------------*/

/*---[ Implementation ]-----------------------------------------------------------*/

 extern "C" {

 static void _System eventListener(HICQ icq, ULONG uin, char id, USHORT event, ULONG parm, HWND h)
 {
    switch(id)
    {
    case 'S':
       ( (pwICQUserList *) h )->SystemEvent(event,parm);
       break;
    
    case 'U':
       ( (pwICQUserList *) h )->UserEvent(uin,event,parm);
       break;
    }
    
 }
 
 }

 int pwICQUserList::start(void)
 {
    DBGMessage("User list was created");
    icqAddGuiEventListener(icq,eventListener,(HWND) this);
    return 0;
 }

 int pwICQUserList::stop(void)
 {
    DBGMessage("User list was destroyed");
    icqRemoveGuiEventListener(icq,eventListener,(HWND) this);
    return 0;
 }

 void pwICQUserList::SystemEvent(USHORT event, ULONG parm)
 {

 }

 void pwICQUserList::UserEvent(ULONG uin, USHORT event, ULONG parm)
 {

 }

 void pwICQUserList::loadUsers(void)
 {
    for(HUSER usr = icqQueryFirstUser(icq);usr;usr = icqQueryNextUser(icq,usr))
    {
       if(!(usr->flags&USRF_HIDEONLIST))
          insertUser(usr);
    }
 }
 
 
