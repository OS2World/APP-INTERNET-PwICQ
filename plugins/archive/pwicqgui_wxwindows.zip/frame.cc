/*
 * frame.cc - pwICQ main Window class implementation (Common)
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/

/*---[ Prototipes ]---------------------------------------------------------------*/

/*---[ Implementation ]-----------------------------------------------------------*/

 void pwICQFrame::SystemEvent(USHORT event, ULONG parm)
 {
     switch(event)
     {
     case ICQEVENT_SECONDARY:
         userList->loadUsers();
         Show(TRUE);
         break;
     
     }
 }
