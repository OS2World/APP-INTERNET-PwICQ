/*
 * pwicqapp.cc - pwICQ class implementation
 */
 
 #include "pwicqgui.h" 
 
/*---[ Definitions ]--------------------------------------------------------------*/


/*---[ Prototipes ]---------------------------------------------------------------*/


/*---[ Implementation ]-----------------------------------------------------------*/

 bool pwICQapp::OnInit()
 {
    if(initialize(argc,argv))
        return FALSE;
     
    pwICQFrame *frame = new pwICQFrame();
     
    frame->Show(TRUE);
     
    SetTopWindow(frame);
     
    return TRUE;
 }

 int pwICQapp::OnExit()
 {
    terminate();
    return 0;
 }
 
