/////////////////////////////////////////////////////////////////////////////
// Name:        wxCustomButton based on wxCustomToggleCtrl.cpp
// Purpose:     a toggle button - eg of a wxWindow ver. 2 custom control
// Author:      Bruce Phillips, modifed by John Labenski
// Modified by:
// Created:     11/05/2002
// RCS-ID:
// Copyright:   (c) Bruce Phillips, John Labenki
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifdef __GNUG__
    #pragma implementation "toggle.h"
#endif

#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "wx/event.h"
#include "wx/defs.h"
#include "wx/control.h"
#include "wx/settings.h"
#include "wx/image.h"
#include "wx/bitmap.h"
#include "wx/timer.h"
#include "toggle.h"

#include "wx/tglbtn.h"


// ==========================================================================
// event table (the events wxCustomButton ** RECEIVES **)
// ==========================================================================

BEGIN_EVENT_TABLE(wxCustomButton,wxControl)
    EVT_MOUSE_EVENTS ( wxCustomButton::OnMouseEvents )
    EVT_PAINT        ( wxCustomButton::OnPaint )
	EVT_TIMER		 ( -1, wxCustomButton::OnTimer) 
END_EVENT_TABLE()

// ==========================================================================
// implemetation
// ==========================================================================

IMPLEMENT_DYNAMIC_CLASS( wxCustomButton, wxControl )

wxCustomButton::~wxCustomButton()
{
	if (HasCapture()) ReleaseMouse();
	if (m_timer) delete m_timer;
}

void wxCustomButton::Init()
{
    m_focused = FALSE;
    m_marginX = m_marginY = 2;
    m_down = 0;
	m_timer = NULL;
	m_eventType = 0;
	m_button_style = wxCUSTBUT_BUTTON;
}

bool wxCustomButton::Create(wxWindow* parent,
                            wxWindowID id,
                            const wxString& label,
                            const wxBitmap &bitmap,
                            const wxPoint& pos,
                            const wxSize& size,
                            long style,
                            const wxValidator& val,
                            const wxString& name)
{
	int styles = 0;
	if (style & wxCUSTBUT_BUTTON) styles++;
	if (style & wxCUSTBUT_TOGGLE) styles++;
	if (style & wxCUSTBUT_BUT_DCLICK_TOG) styles++;
	if (style & wxCUSTBUT_TOG_DCLICK_BUT) styles++;
	wxCHECK_MSG(styles <= 1, FALSE, "Only one wxCustomButton style allowed")
	
	// set button_style and remove it so it doesn't get set in wxControl::Create()
	if (style & wxCUSTBUT_BUTTON)
	{
		style ^= wxCUSTBUT_BUTTON;
	}
	else if (style & wxCUSTBUT_TOGGLE)
	{
		m_button_style = wxCUSTBUT_TOGGLE;
		style ^= wxCUSTBUT_TOGGLE;
	}
	else if (style & wxCUSTBUT_BUT_DCLICK_TOG)
	{
		m_button_style = wxCUSTBUT_BUT_DCLICK_TOG;
		style ^= wxCUSTBUT_BUT_DCLICK_TOG;
	}
	else if (style & wxCUSTBUT_TOG_DCLICK_BUT)
	{
		m_button_style = wxCUSTBUT_TOG_DCLICK_BUT;
		style ^= wxCUSTBUT_TOG_DCLICK_BUT;
	}
	
    style |= wxNO_BORDER; // wxMSW adds a simple border, not required for wxGTK

    m_bmpNormal   =
    m_bmpDisabled =
    m_bmpFocus    =
    m_bmpSelected = bitmap;

    wxControl::Create(parent,id,pos,size,style,val,name);

    wxControl::SetLabel(label);

    if (size == wxDefaultSize) SetSize(DoGetBestSize());

    SetBackgroundColour(parent->GetBackgroundColour());
    SetForegroundColour(parent->GetForegroundColour());
    SetFont(parent->GetFont());

    if (bitmap.Ok())
    {
        wxImage imgDis = m_bmpDisabled.ConvertToImage();
        unsigned char br = GetBackgroundColour().Red();
        unsigned char bg = GetBackgroundColour().Green();
        unsigned char bb = GetBackgroundColour().Blue();
		
		bool mask = FALSE;
		unsigned char mr=0, mg=0, mb=0;
		if (imgDis.HasMask())
		{
			mask = TRUE;
			mr = imgDis.GetMaskRed();
			mg = imgDis.GetMaskGreen();
			mb = imgDis.GetMaskBlue();
		}
		
		unsigned char *r, *g, *b;
		
        int w = imgDis.GetWidth();
        int h = imgDis.GetHeight();
        unsigned char *disData = imgDis.GetData();

        for (int j=0; j<h; j++)
        {
            for (int i=j%2; i<w; i+=2)
            {
				r = &disData[(j*w+i)*3]; 
				g = r+1; 
				b = r+2;
				
				if (!mask || ((*r!=mr)&&(*b!=mb)&&(*g!=mg)))
				{
					*r = br; *g = bg; *b = bb;
				}
            }
        }
        m_bmpDisabled = wxBitmap(imgDis);

/*      // FIXME why bother creating focused wxCustomButton's bitmap
		wxImage imgFoc = m_bmpFocus.ConvertToImage();
        unsigned char *focData = imgFoc.GetData();
		r = imgFoc.GetData();
		g = imgFoc.GetData() + 1;
		b = imgFoc.GetData() + 2;
        for (int j=0; j<h; j++)
        {
            for (int i=0; i<w; i++)
            {
				if ((!mask || ((*r!=mr)&&(*b!=mb)&&(*g!=mg))) &&
					((*r<236)&&(*b<236)&&(*g<236)))
				{
					*r += 20; *g += 20; *b += 20;
				}
				r += 3; g += 3; b += 3;
			}
        }
		m_bmpFocus = wxBitmap(imgFoc);
*/
    }

	CalcSize();
	
    return (TRUE);
}

void wxCustomButton::SetValue(bool depressed)
{
	if (m_button_style == wxCUSTBUT_BUTTON) return;
	
	m_down = depressed ? 1 : 0;
    Refresh(FALSE);
}

void wxCustomButton::SetButtonStyle(wxCustomButton_Style style)
{
	m_button_style = style;
	if (m_button_style == wxCUSTBUT_BUTTON) m_down = 0;
	
	Refresh(FALSE);
}

void wxCustomButton::SetLabel( const wxString &label )
{
    wxControl::SetLabel(label);
	Refresh(FALSE);
}

// sequence of events in GTK is up, dclick, up.

void wxCustomButton::OnMouseEvents(wxMouseEvent& event)
{
	bool repaint = FALSE;
	
	if (event.LeftDown())
	{
		if (!HasCapture()) CaptureMouse(); // keep depressed until up
		//printf("LeftDown %d\n", m_down); fflush(stdout);
		m_down++;
		repaint = TRUE;
	}
	else if (event.LeftDClick())
	{
		//printf("LeftDclick %d\n", m_down); fflush(stdout);
		m_down++; // GTK eats second down event
		repaint = TRUE;
	}
	else if (event.LeftUp())
	{
		if (HasCapture()) ReleaseMouse();
		
		m_eventType = wxEVT_LEFT_UP;
		
		//printf("LeftUp %d\n", m_down); fflush(stdout);
		if (wxRect(wxPoint(0,0), GetSize()).Inside(event.GetPosition()))
		{
			if (!m_timer)
			{
				m_timer = new wxTimer(this, m_down+1);
				m_timer->Start(200, TRUE);
			}
			else
			{
				m_eventType = wxEVT_LEFT_DCLICK;
			}

			if ((m_button_style != wxCUSTBUT_TOGGLE) && 
				(m_button_style != wxCUSTBUT_TOG_DCLICK_BUT)) m_down++;

			repaint = TRUE;
		}

		if (m_button_style & wxCUSTBUT_BUTTON) m_down = 0;
	}
	else if (event.RightDown())
	{
		if (!HasCapture()) CaptureMouse(); // keep depressed until up
		//printf("RightDown %d\n", m_down); fflush(stdout);
		m_down++;
		repaint = TRUE;
	}
	else if (event.RightDClick())
	{
		//printf("RightDclick %d\n", m_down); fflush(stdout);
		m_down++; // GTK eats second down event
		repaint = TRUE;
	}
	else if (event.RightUp())
	{
		if (HasCapture()) ReleaseMouse();
		
		m_eventType = wxEVT_RIGHT_UP;
		//printf("RightUp %d\n", m_down); fflush(stdout);
		if (wxRect(wxPoint(0,0), GetSize()).Inside(event.GetPosition()))
		{
			m_down++;
			
			if (!m_timer)
			{
				m_timer = new wxTimer(this, m_down);
				m_timer->Start(250, TRUE);
			}
			else
			{
				m_eventType = wxEVT_RIGHT_DCLICK;
			}
		}

		if (m_button_style == wxCUSTBUT_BUTTON) m_down = 0;

		repaint = TRUE;
	}
	else if (event.MiddleUp())
	{
// FIXME this is just for debugging
		
		if (m_button_style == wxCUSTBUT_BUTTON)
		{
			m_button_style = wxCUSTBUT_TOGGLE;
			printf("Now wxCUSTBUT_TOGGLE\n"); fflush(stdout);
		}
		else if (m_button_style == wxCUSTBUT_TOGGLE)
		{
			m_button_style = wxCUSTBUT_BUT_DCLICK_TOG;
			printf("Now wxCUSTBUT_BUT_DCLICK_TOG\n"); fflush(stdout);
		}
		else if (m_button_style == wxCUSTBUT_BUT_DCLICK_TOG)
		{
			m_button_style = wxCUSTBUT_TOG_DCLICK_BUT;
			printf("Now wxCUSTBUT_TOG_DCLICK_BUT\n"); fflush(stdout);
		}
		else 
		{
			m_button_style = wxCUSTBUT_BUTTON;
			printf("Now wxCUSTBUT_BUTTON\n"); fflush(stdout);
		}
		
		if (m_button_style == wxCUSTBUT_BUTTON) m_down = 0;
	}
	else if (event.Entering())
	{
		m_focused = TRUE;
		if ((event.LeftIsDown() || event.RightIsDown()) && HasCapture()) 
			m_down++;
		
		repaint = TRUE;
	}
	else if (event.Leaving())
	{
		m_focused = FALSE;
		if ((event.LeftIsDown() || event.RightIsDown()) && HasCapture())
			m_down--;
		
		repaint = TRUE;
	}

	if (repaint)
	{
        wxClientDC dc(this);
		Paint(dc);
	}
}

void wxCustomButton::OnTimer( wxTimerEvent &event )
{
	m_timer->Stop();
	delete m_timer;
	m_timer = NULL;
	//printf("OnTimer m_down %d, id %d\n", m_down, event.GetId()); fflush(stdout);
	
	// Clean up the button presses 
	//      GTK eats second left down for a DClick, who know about the others?
	if (m_button_style == wxCUSTBUT_BUTTON) 
	{
		m_down = 0;
	}
	else if (m_button_style == wxCUSTBUT_TOGGLE)
	{
		if (m_eventType == wxEVT_LEFT_UP)
			m_down = bool(event.GetId()%2) ? 0 : 1;
		else
			m_down = bool(event.GetId()%2) ? 1 : 0;
	} 
	else if (m_button_style == wxCUSTBUT_BUT_DCLICK_TOG) 
	{
		if (m_eventType == wxEVT_LEFT_DCLICK)
			m_down = bool(event.GetId()%2) ? 0 : 1;
		else
			m_down = bool(event.GetId()%2) ? 1 : 0;
	}
	else if (m_button_style == wxCUSTBUT_TOG_DCLICK_BUT) 
	{
		if (m_eventType == wxEVT_LEFT_UP)
			m_down = bool(event.GetId()%2) ? 0 : 1;
		else
			m_down = bool(event.GetId()%2) ? 1 : 0;
	}

	Refresh(FALSE);
	SendEvent();
}

void wxCustomButton::SendEvent()
{
	printf("SendEvent m_down %d\n", m_down); fflush(stdout);

	//m_down = m_down%2;	
	
	if (((m_button_style == wxCUSTBUT_TOGGLE) && (m_eventType == wxEVT_LEFT_UP)) || 
		((m_button_style == wxCUSTBUT_BUT_DCLICK_TOG) && (m_eventType == wxEVT_LEFT_DCLICK)) ||
		((m_button_style == wxCUSTBUT_TOG_DCLICK_BUT) && (m_eventType == wxEVT_LEFT_UP)))
	{
		printf("Toggle event, %d %d\n", m_eventType, m_down); fflush(stdout);
		wxCommandEvent eventOut(wxEVT_COMMAND_TOGGLEBUTTON_CLICKED, GetId());
	    eventOut.SetInt(bool(m_down%2) ? 1 : 0);
		eventOut.SetExtraLong(m_eventType);
		eventOut.SetEventObject(this);
		GetEventHandler()->ProcessEvent(eventOut);
	}
	else
	{
		printf("Button event, %d %d\n", m_eventType, m_down); fflush(stdout);
		wxCommandEvent eventOut(wxEVT_COMMAND_BUTTON_CLICKED,GetId());
	    eventOut.SetInt(0);
		eventOut.SetExtraLong(m_eventType);
		eventOut.SetEventObject(this);
		ProcessEvent(eventOut);
	}
}

void wxCustomButton::OnPaint(wxPaintEvent& WXUNUSED(event))
{
    wxPaintDC dc(this);
	Paint(dc);
}

void wxCustomButton::Paint( wxDC &dc )
{
    int w, h;
    GetSize(&w,&h);

    wxColour backColour;
    if (m_focused)
    {
        wxColour c = GetBackgroundColour();
        if ((c.Red()<245) && (c.Green()<245) && (c.Blue()<245))
            backColour.Set(c.Red()+10, c.Green()+10, c.Blue()+10);
    }
    else
        backColour = GetBackgroundColour();

    wxBrush brush(backColour,wxSOLID);
    dc.SetBackground(brush);		// brush for dc.Clear()
    dc.SetBrush(brush);
	
    dc.BeginDrawing();
    dc.Clear();

    wxString label = GetLabel();

    if (IsEnabled())
    {
		if (GetValue() && m_bmpSelected.Ok())
			dc.DrawBitmap(m_bmpSelected, bmpPos.x, bmpPos.y, TRUE );
		else if (m_focused && m_bmpFocus.Ok())
			dc.DrawBitmap(m_bmpFocus, bmpPos.x, bmpPos.y, TRUE );
        else if (m_bmpNormal.Ok()) 
			dc.DrawBitmap(m_bmpNormal, bmpPos.x, bmpPos.y, TRUE );

        if (label != wxEmptyString)
        {
			dc.SetFont(GetFont());
			dc.SetTextBackground(backColour);
            dc.SetTextForeground(GetForegroundColour());
            dc.DrawText(label, txtPos.x, txtPos.y);
        }
    }
    else
    {
        if (m_bmpDisabled.Ok()) 
			dc.DrawBitmap(m_bmpDisabled, bmpPos.x, bmpPos.y );
        else if (m_bmpNormal.Ok()) 
			dc.DrawBitmap(m_bmpNormal, bmpPos.x, bmpPos.y, TRUE );

        if (label != wxEmptyString)
        {
			dc.SetFont(GetFont());
			dc.SetTextBackground(backColour);
            dc.SetTextForeground(wxSystemSettings::GetColour(wxSYS_COLOUR_GRAYTEXT));
            dc.DrawText(label, txtPos.x, txtPos.y);
        }
    }
	
    if (GetValue())        // draw sunken border
    {
        dc.SetPen(*wxGREY_PEN);
        dc.DrawLine(0,h-1,0,0);		dc.DrawLine(0,0,w,0);
        dc.SetPen(*wxWHITE_PEN);
        dc.DrawLine(w-1,1,w-1,h-1);	dc.DrawLine(w-1,h-1,0,h-1);
        dc.SetPen(*wxBLACK_PEN);
        dc.DrawLine(1,h-2,1,1);		dc.DrawLine(1,1,w-1,1);
    }
    else       		// draw raised border
    {
        dc.SetPen(*wxWHITE_PEN);
        dc.DrawLine(0,h-2,0,0);       	dc.DrawLine(0,0,w-1,0);
        dc.SetPen(*wxBLACK_PEN);
        dc.DrawLine(w-1,0,w-1,h-1);	dc.DrawLine(w-1,h-1,-1,h-1);
        dc.SetPen(*wxGREY_PEN);
        dc.DrawLine(2,h-2,w-2,h-2);	dc.DrawLine(w-2,h-2,w-2,1);
    }

    dc.EndDrawing();
}

//------------------------------------------------------------------------
// protected functions
//------------------------------------------------------------------------
wxSize wxCustomButton::DoGetBestSize() const
{
    wxClientDC dc((wxWindow*)this);

    int w=0, h=0;

    if (GetLabel() != wxEmptyString)
    {
        dc.SetFont(GetFont());
        dc.GetTextExtent(GetLabel(),&w,&h);
    }
    if (m_bmpNormal.Ok())
    {
        int bw = m_bmpNormal.GetWidth();
        int bh = m_bmpNormal.GetHeight();
        w = bw > w ? bw : w;
        h += bh;
    }

    return wxSize(w+2*m_marginX,h+2*m_marginY);
}

void wxCustomButton::CalcSize()
{
    int w, h;
    GetSize(&w,&h);

    int bw = 0, bh = 0;
    int tw = 0, th = 0;

    if (m_bmpNormal.Ok()) // assume they're all the same size
    {
        bw = m_bmpNormal.GetWidth();
        bh = m_bmpNormal.GetHeight();
    }
    wxString label = GetLabel();
    if (label != wxEmptyString)
    {
		wxClientDC dc((wxWindow*)this);
        dc.GetTextExtent(label, &tw, &th);
    }

    bmpPos = wxPoint((w - bw)/2, (h - (bh+th+2))/2);
	txtPos = wxPoint((w - tw)/2, (h - (bh+th+2))/2+bh+2);
	
	Refresh(FALSE);
}
