/////////////////////////////////////////////////////////////////////////////
// Name:        wxCustomButton.h based on wxCustomToggleCtrl.cpp
// Purpose:     a toggle button - eg of a wxWindow ver. 2 custom control
// Author:      Bruce Phillips modified by John Labenski
// Modified by:
// Created:     11/05/2002
// RCS-ID:		$Id: toggle.h,v 1.1 2003/01/06 16:34:13 john Exp $
// Copyright:   (c) Bruce Phillips, John Labenski
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/*

wxCustomButton is a bitmap and/or text button that can toggle or not.

It can be used as a drop-in replacement for a wxButton, wxToggleButton,
	wxBitmapButton, and the non-existant "wxBitmapToggleButton."

The event's wxCommandEvent::GetExtraLong contains one of the following
	wxEVT_LEFT_UP, wxEVT_RIGHT_UP, wxEVT_LEFT_DCLICK, wxEVT_RIGHT_DCLICK
	these can be used to distinguish between the types of events sent

There are four styles the button can take.

wxCUSTBUT_BUTTON == wxButton
	Left and Right clicks and double clicks all send 
		wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id,fn)

wxCUSTBUT_TOGGLE == wxToggleButton
	Left clicks sends
		wxEVT_COMMAND_TOGGLEBUTTON_CLICKED => EVT_TOGGLEBUTTON(id, fn)
	Left and Right double clicks and Right clicks send
		wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id,fn)

wxCUSTBUT_BUT_DCLICK_TOG 
	Left and Right clicks and Right double clicks send 
		wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id,fn)
	Left double clicks sends
		wxEVT_COMMAND_TOGGLEBUTTON_CLICKED => EVT_TOGGLEBUTTON(id, fn)

wxCUSTBUT_TOG_DCLICK_BUT
	Left clicks sends
		wxEVT_COMMAND_TOGGLEBUTTON_CLICKED => EVT_TOGGLEBUTTON(id, fn)
	Left and Right double clicks and Right clicks send
		wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id,fn)


It behaves like a wxButton if GetCanToggle == FALSE, single click sends this
	wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id, fn)

It behaves like a wxToggleButton if GetCanToggle == TRUE, single click sends
	wxEVT_COMMAND_TOGGLEBUTTON_CLICKED => EVT_TOGGLEBUTTON(id, fn)

The event's wxCommandEvent::GetInt (IsChecked) is TRUE if the button is 
	depressed, this is only useful for the wxToggleButton style


For both types of button when double-clicked it sends this event 
	wxEVT_COMMAND_BUTTON_CLICKED => EVT_BUTTON(id, fn)
	and the button state does not change. Only a single EVT_BUTTON event should
	be sent on double-click and event.GetExtraLong == wxEVT_XXX_DCLICK,
	if not then there's a bug.

If no bitmaps are set the text is centered, if only a bitmap it set then 
it's centered, if a bitmap and text is sent then the text is below the bitmap.

#include "wx/tglbtn.h" for EVT_TOGGLEBUTTON
*/

#ifndef WXCUSTOMTOGGLECTRL_H
#define WXCUSTOMTOGGLECTRL_H

#ifdef __GNUG__
    #pragma interface
#endif

#include "wx/defs.h"

class wxTimer;

// style for wxCustomButton, if used then toggle
//	   note : wxWANTS_CHARS etc, are just placeholders and aren't used anyway
enum wxCustomButton_Style
{
	wxCUSTBUT_BUTTON         = wxWANTS_CHARS,
	wxCUSTBUT_TOGGLE         = wxCLIP_CHILDREN,
	wxCUSTBUT_BUT_DCLICK_TOG = wxTRANSPARENT_WINDOW,
	wxCUSTBUT_TOG_DCLICK_BUT = wxNO_FULL_REPAINT_ON_RESIZE
};

//#define wxCUSTOMBUTTON_STYLE_VALID(type) 	(((type)&wxCUSTBUT_BUTTON)||((type)<=wxCUSTBUT_TOGGLE))

class wxCustomButton : public wxControl
{
public:

    wxCustomButton() : wxControl() { Init(); }
	
    wxCustomButton(wxWindow* parent, // compatible w/ wxToggleButton
                   wxWindowID id,
                   const wxString& label,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long style = 0,
                   const wxValidator& val = wxDefaultValidator,
                   const wxString& name = wxT("wxCustomButton"))
                   : wxControl()
    {
        Init();
        Create(parent,id,label,wxNullBitmap,pos,size,style,val,name);
    }

    wxCustomButton(wxWindow *parent, // compatible w/ wxBitmapButton
                   wxWindowID id,
                   const wxBitmap& bitmap,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long style = 0,
                   const wxValidator& val = wxDefaultValidator,
                   const wxString& name = wxT("wxCustomButton"))
                   : wxControl()
    {
        Init();
        Create(parent,id,wxEmptyString,bitmap,pos,size,style,val,name);
    }

    wxCustomButton(wxWindow *parent, // native
                   wxWindowID id,
                   const wxString& label,
                   const wxBitmap& bitmap,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long style = 0,
                   const wxValidator& val = wxDefaultValidator,
                   const wxString& name = wxT("wxCustomButton"))
                   : wxControl()
    {
        Init();
        Create(parent,id,label,bitmap,pos,size,style,val,name);
    }

    virtual ~wxCustomButton();
		
    bool Create(wxWindow* parent,
                wxWindowID id,
                const wxString& label,
                const wxBitmap &bitmap,
                const wxPoint& pos = wxDefaultPosition,
                const wxSize& size = wxDefaultSize,
                long style = 0,
                const wxValidator& val = wxDefaultValidator,
		        const wxString& name = wxT("wxCustomButton"));

    bool GetValue() const { return bool(m_down%2); }
    void SetValue( bool depressed );

	wxCustomButton_Style GetButtonStyle() const { return m_button_style; }
	void SetButtonStyle( wxCustomButton_Style style );
	
	// set the text label
    void SetLabel( const wxString &label );

    // set the bitmaps
    void SetBitmapLabel(const wxBitmap& bitmap) { m_bmpNormal = bitmap; CalcSize(); }
    void SetBitmapSelected(const wxBitmap& sel) { m_bmpSelected = sel; CalcSize(); };
    void SetBitmapFocus(const wxBitmap& focus)  { m_bmpFocus = focus; CalcSize(); };
    void SetBitmapDisabled(const wxBitmap& disabled) { m_bmpDisabled = disabled; CalcSize(); };
    void SetLabel(const wxBitmap& bitmap) { SetBitmapLabel(bitmap); }

    // retrieve the bitmaps
    const wxBitmap& GetBitmapLabel() const { return m_bmpNormal; }
    const wxBitmap& GetBitmapSelected() const { return m_bmpSelected; }
    const wxBitmap& GetBitmapFocus() const { return m_bmpFocus; }
    const wxBitmap& GetBitmapDisabled() const { return m_bmpDisabled; }
    wxBitmap& GetBitmapLabel() { return m_bmpNormal; }
    wxBitmap& GetBitmapSelected() { return m_bmpSelected; }
    wxBitmap& GetBitmapFocus() { return m_bmpFocus; }
    wxBitmap& GetBitmapDisabled() { return m_bmpDisabled; }

    // set/get the margins around the button
    virtual void SetMargins(int x, int y) { m_marginX = x; m_marginY = y; }
    int GetMarginX() const { return m_marginX; }
    int GetMarginY() const { return m_marginY; }
	
protected:
    virtual void OnPaint(wxPaintEvent &event);
	virtual void Paint( wxDC &dc );
	
	virtual void SendEvent();
	
    virtual void OnMouseEvents(wxMouseEvent &event);

	virtual void OnTimer(wxTimerEvent &event);
	
    virtual wxSize DoGetBestSize() const;
	virtual void CalcSize();
    
private:
    void Init();

    int m_down;			// toggle state if m_down%2 then depressed
    bool m_focused;     // mouse in window
	wxCustomButton_Style m_button_style;

    // the bitmaps for various states
    wxBitmap m_bmpNormal,
             m_bmpSelected,
             m_bmpFocus,
             m_bmpDisabled;

    // the margins around the bitmap
    int m_marginX,
        m_marginY;

	wxPoint bmpPos,
	        txtPos;

	wxTimer *m_timer;
	
	wxEventType m_eventType;	 // store the mouse event type

    DECLARE_DYNAMIC_CLASS(wxCustomButton)
    DECLARE_EVENT_TABLE()
};

// the single event tag
#define wxEVT_COMMAND_CUSTOM_TOGGLED (wxID_HIGHEST + 1)

// the event table entry macro
#define EVT_CUSTOM_TOGGLE(id,func) \
	EVT_CUSTOM(wxEVT_COMMAND_CUSTOM_TOGGLED,id,func)

// constants for event handler functions to test against event.GetInt()
#define wxCUSTOM_TOGGLE_IS_UP 	0
#define wxCUSTOM_TOGGLE_IS_DOWN 	1

#endif	// #ifndef WXCUSTOMTOGGLECTRL_H

