/*
 * SEND.C - Envia mensagems (Protocolo V7)
 */

 #include <time.h>
 #include <malloc.h>
 #include <stdio.h>
 #include <string.h>

 #include "icqv7.h"

/*---[ Prototipos ]---------------------------------------------------------------------------------------------*/

 static USHORT normalMsg(HICQ, ULONG, char *, ULONG);
 static USHORT urlMsg(HICQ, USHORT, ULONG, char *, ULONG);

/*---[ Statics ]------------------------------------------------------------------------------------------------*/

 static ULONG messageID = 0;

/*---[ Implementacao ]------------------------------------------------------------------------------------------*/

 ULONG queryCurrentID(HICQ icq)
 {
    ULONG ret = time(NULL);

    if(!beginSend(icq))
       return ret+100;

    while(ret == messageID)
       ret++;

    messageID = ret;

    finishSend(icq);

    return ret;
 }


 USHORT _System icqV7Message(HICQ icq, ULONG uin, USHORT type, const char *txt, ULONG *id)
 {
    /* Envia mensagem direto ao servidor, coloca identificacao em ID */
    char        *ptr;
    int         ret             = 0;
    ULONG       msgSequence     = queryCurrentID(icq);
    char        buffer[0x0100];
//  HUSER       usr             = icqQueryUserHandle(icq,uin);

    DBGMessage(txt);

    icqSetServerBusy(icq,TRUE);
/*
    if(usr && usr->mode != ICQ_OFFLINE)
    {
       sprintf(buffer,"Extended message #%lu sent to ICQ#%lu",msgSequence,uin);
       ret = advancedMsg(icq, uin, type, txt, msgSequence);
    }
    else
    {
*/
       *id = 0;    // Zera sequenciador para que a mensagem seja retirada da fila

       if(type == MSG_NORMAL)
       {
          sprintf(buffer,"Normal message #%lu sent to ICQ#%lu",msgSequence,uin);
          ret = normalMsg(icq,uin,(UCHAR *) txt,msgSequence);
       }
       else
       {
          sprintf(buffer,"URL message #%lu sent to ICQ#%lu",msgSequence,uin);
          for(ptr = (UCHAR *) txt;*ptr;ptr++)
          {
             if(*ptr == ICQ_FIELD_SEPARATOR)
                *ptr = 0xFE;
          }
          ret = urlMsg(icq,type,uin,(UCHAR *) txt,msgSequence);
       }
/*
    }
*/

    if(ret)
       return ret;

#ifdef EXTENDED_LOG
    icqDumpPacket(icq, icqQueryUserHandle(icq, uin), buffer, strlen(txt), (UCHAR *) txt);
#else
    icqWriteSysLog(icq,PROJECT,buffer);
#endif


    return ret;   /* 0 = Ok */
 }

 #pragma pack(1)
 struct normalPrefix
 {
    ULONG       id;             // 2 DWORD  ??B, a sort of ID (it seems to be based on timestamp, ack and replies to SNAC 4,07 should use same ID)
    ULONG       id2;
    USHORT      format;         // WORD     message-format
    char        szUin;          // UIN size;
 };

 struct normalHeader
 {
    USHORT      tlv2;           // TLV2
    USHORT      tlv2Sz;         // TLV2 - Size
    char        X1[7];          // 7 BYTE  unk, usually 05 01 00 01 01 01 01
    USHORT      msgSize;        // msg length + 4
    ULONG       X2;
 };

 struct normalFooter
 {
    USHORT      tlv6;           // TLV6
    USHORT      tlv6Sz;         // TLV6 - Size (Zero)

 };

 static USHORT normalMsg(HICQ icq, ULONG uin, char *txt, ULONG id)
 {
    const       UCHAR   tbl[]   = { 0x05, 0x01, 0x00, 0x01, 0x01, 0x01, 0x01 };
    char                bUIN[20];
    int                 f;
    FLAP                flap;
    SNAC                snac;
    struct normalHeader header;
    struct normalFooter footer;
    struct normalPrefix prefix;
    USHORT              sz              = strlen(txt)+1;

    sprintf(bUIN,"%ld",uin);
    prefix.szUin = strlen(bUIN);

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;
    flap.size           = ajustShortValue(      sizeof(SNAC)
                                                +sizeof(prefix)
                                                +prefix.szUin
                                                +sizeof(header)
                                                +sizeof(footer)
                                                +sz);

    snac.family         = 0x0400;
    snac.subType        = 0x0600;
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = 0x06000000;

    prefix.id           = ajustLongValue(id);           // 2 DWORD  ??B, a sort of ID (it seems to be based on timestamp, ack and replies to SNAC 4,07 should use same ID)
    prefix.id2          = mainTimer;
    prefix.format       = 0x0100;                       // WORD     message-format

    header.tlv2         = 0x0200;                       // TLV2
    header.tlv2Sz       = ajustShortValue(sz+13);       // TLV2 - Size
    header.msgSize      = ajustShortValue(sz+4);        // msg length + 4
    header.X2           = 0;

    for(f=0;f<7;f++)
       header.X1[f] = tbl[f];           // 7 BYTE  unk

    footer.tlv6         = 0x0600;       // TLV6
    footer.tlv6Sz       = 0;            // TLV6 - Size (Zero)

    /* Pacote formatado, envio */

    if(!beginSend(icq))
       return -1;

    packetSeq++;
    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap,   sizeof(FLAP));
    icqSend(sock, &snac,   sizeof(SNAC));
    icqSend(sock, &prefix, sizeof(prefix));
    icqSend(sock, bUIN,    prefix.szUin);
    icqSend(sock, &header, sizeof(header));
    icqSend(sock, txt,     sz);
    icqSend(sock, &footer, sizeof(footer));

    finishSend(icq);

    return 0;
 }

 #pragma pack(1)
 struct urlHeader
 {
    USHORT      tlv5;           // TLV5
    USHORT      tlv5Sz;         // TLV5 - Size
    ULONG       uin;            // My UIN
    UCHAR       subType;        // msg subtype
    UCHAR       flags;          // msg flags
    USHORT      txtSize;        // Text size
 };

 static USHORT urlMsg(HICQ icq, USHORT type, ULONG uin, char *txt, ULONG id)
 {
    char                bUIN[20];
    FLAP                flap;
    SNAC                snac;
    struct normalPrefix prefix;
    struct urlHeader    header;
    struct normalFooter footer;
    USHORT              sz              = strlen(txt)+1;

    sprintf(bUIN,"%ld",uin);
    prefix.szUin = strlen(bUIN);

    prefix.id           = ajustLongValue(id);           // 2 DWORD  ??B, a sort of ID (it seems to be based on timestamp, ack and replies to SNAC 4,07 should use same ID)
    prefix.id2          = mainTimer;
    prefix.format       = 0x0400;                       // WORD     message-format

    footer.tlv6         = 0x0600;                       // TLV6
    footer.tlv6Sz       = 0;                            // TLV6 - Size (Zero)

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;
    flap.size           = ajustShortValue(      sizeof(SNAC)
                                                +sizeof(prefix)
                                                +prefix.szUin
                                                +sizeof(header)
                                                +sizeof(footer)
                                                +sz);

    snac.family         = 0x0400;
    snac.subType        = 0x0600;
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = 0x06001200;

    header.tlv5         = 0x0500;                       // TLV5
    header.tlv5Sz       = ajustShortValue(sz+8);        // TLV5 - Size
    header.uin          = icqQueryUIN(icq);             // my Uin
    header.subType      = type;                         // msg subtype
    header.flags        = 0;                            // msg flags
    header.txtSize      = sz;                           // Text size

    /* Pacote formatado, envio */

    if(!beginSend(icq))
       return -1;

    packetSeq++;
    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap,   sizeof(FLAP));
    icqSend(sock, &snac,   sizeof(SNAC));
    icqSend(sock, &prefix, sizeof(prefix));
    icqSend(sock, bUIN,    prefix.szUin);
    icqSend(sock, &header, sizeof(header));
    icqSend(sock, txt,     sz);
    icqSend(sock, &footer, sizeof(footer));

    finishSend(icq);

    return 0;
 }

 int _System icqV7Confirmation(HICQ icq, ULONG uin, USHORT type, BOOL log, char *text)
 {
    static const char   *txt[]  = { "NickName", "FirstName", "LastName", "EMail", NULL };
    int                 sz      =  icqQueryMaxMessageLength(icq, NULL);
    char                *ptr;
    int                 f;
    char                *buffer;

    buffer = malloc(sz+10);

    if(!buffer)
    {
       icqWriteSysLog(icq,PROJECT,"Memory allocation error when sending confirmation message");
    }
    else
    {

       ptr = buffer;

       for(f=0;txt[f] != NULL && sz > 5;f++)
       {
          icqLoadString(icq, txt[f], "-", ptr, sz);
          sz  -= strlen(ptr);
          ptr += strlen(ptr);
          *(ptr++) = ICQ_FIELD_SEPARATOR;
          sz--;
       }

       *(ptr++) = icqLoadValue(icq,"Authorize",1) ? '0' : '1';
       *ptr     = 0;

       if(text)
       {
          *(ptr++) = ICQ_FIELD_SEPARATOR;
          strncpy(ptr,text,sz-4);
       }

       icqSendMessage(icq, uin, type, text);

       free(buffer);
    }
    return 0;

 }


