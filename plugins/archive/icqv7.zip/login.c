/*
 * LOGIN.C - Faz o procedimento de login
 */

#ifdef __OS2__
   #define INCL_DOSPROCESS
#endif

#ifdef linux
   #include <unistd.h>
#endif

 #include <string.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <pwMacros.h>
 #include "icqv7.h"

/*---[ Pacotes ]--------------------------------------------------------------------------------------------*/


/*---[ Prototipos ]-----------------------------------------------------------------------------------------*/

 static void processCookie(HICQ, int *, TLV *, UCHAR *);
 static void sendCookie(HICQ,int,UCHAR *);
// static void _System loginThread(ICQTHREAD *);

/*---[ Statics ]--------------------------------------------------------------------------------------------*/

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 int doLogin(HICQ icq, char *buffer)
 {
    long        loginServer;
//  int         sock;

    *cookie     = 0;

    DBGMessage("Conectando ao servidor");
    icqSystemEvent(icq, ICQEVENT_FINDINGSERVER);

#ifdef __OS2__
    DosSleep(10);
#endif

    icqLoadString(icq,"loginServer","login.icq.com",buffer,BUFFERSIZE);
    loginServer = icqGetHostByName(buffer);

    if(!loginServer || loginServer == 0xFFFFFFFF)
    {
       icqWriteSysLog(icq,PROJECT,"Unable to resolve the server name.");
       return -1;
    }

    DBGTracex(loginServer);

    icqSystemEvent(icq, ICQEVENT_CONNECTING);

    return icqConnect(loginServer, LOGIN_PORT);

/*
    strcpy(buffer,"localhost");
    loginServer = icqGetHostByName(buffer);
    DBGTracex(loginServer);

    return icqConnect(loginServer, 21);
*/

 }

 void processLoginPacket(HICQ icq, int sock, int sz, ULONG *pkt)
 {
    switch(*pkt)
    {
    case 0x01000000:
       CHKPoint();
       if(*cookie)
          sendCookie(icq,sock, (UCHAR *) pkt);
       else
          sendLoginPacket(icq,sock,(UCHAR *) pkt);
       break;

    default:
       icqDumpPacket(icq, NULL, "Packet Channel 1 received", sz, (unsigned char *) pkt);
    }
 }

 char *insertTLV(int *sz, USHORT type, short size, char *ptr, const char *string)
 {
//  int f;
    *sz += 4;

    if(size < 0)
       size = strlen(string);

    *( (USHORT *) ptr) = ajustShortValue(type);
    ptr += 2;

    *( (USHORT *) ptr) = ajustShortValue(size);
    ptr += 2;

    *sz += size;

    while(size--)
       *(ptr++) = *(string++);

    return ptr;
 }

 void sendLoginPacket(HICQ icq, int sock, UCHAR *pkt)
 {
    static const USHORT pwdKey[] =      { 0xF3, 0x26, 0x81, 0xC4, 0x39, 0x86,
                                          0xDB, 0x92, 0x71, 0xA3, 0xB9, 0xE6,
                                          0x53, 0x7A, 0x95, 0x7C
                                        };

    static const UCHAR  X1[] =          { 0x01, 0x0A };
    static const UCHAR  major[]  =      { 0x00, 0x04 };
    static const UCHAR  minor[]  =      { 0x00, 0x3F };
    static const UCHAR  lesser[] =      { 0x00, 0x01 };
    static const UCHAR  build[]  =      { 0x0C, 0xCF };
    static const UCHAR  X2[]     =      { 0x00, 0x00, 0x00, 0x55 };

    int                 f,p;
    char                temp[0x0100];

    int                 sz      = 4;
    UCHAR               *ptr    = pkt+sz;


    *( (ULONG *) pkt ) = 0x01000000;

    sprintf(temp,"%ld",icqQueryUIN(icq));
    ptr = insertTLV(&sz,1,-1,ptr,temp);

    icqQueryPassword(icq,temp);

//    strcpy(temp,"trashcan");
//    87 54 E0 B7 51 E5 BA FC

    p = strlen(temp);

    for(f=0;f<p;f++)
       temp[f] ^= pwdKey[f];

    ptr = insertTLV(&sz,2,p,ptr,temp);

    icqLoadString(icq,  "v7.ClientProfile",
                        "ICQ Inc. - Product of ICQ (TM).2000b.4.63.1.3279.85",
                        temp, 0xFF);
    ptr = insertTLV(&sz,0x03,-1,ptr,temp);

    ptr = insertTLV(&sz,0x16, 2,ptr,X1);
    ptr = insertTLV(&sz,0x17, 2,ptr,major);
    ptr = insertTLV(&sz,0x18, 2,ptr,minor);
    ptr = insertTLV(&sz,0x19, 2,ptr,lesser);
    ptr = insertTLV(&sz,0x1A, 2,ptr,build);
    ptr = insertTLV(&sz,0x14, 4,ptr,X2);

    icqLoadString(icq,  "v7.Language",
                        "en",
                        temp, 0xFF);
    ptr = insertTLV(&sz,0x0F,-1,ptr,temp);

    icqLoadString(icq,  "v7.Country",
                        "us",
                        temp, 0xFF);
    ptr = insertTLV(&sz,0x0E,-1,ptr,temp);
/*
#ifndef NDEBUG
    icqDumpPacket(icq, NULL, "Login packet sent", sz, (unsigned char *) pkt);
#endif
*/
    sendFlap(icq,sock,1,sz,pkt);

 }

 char * extractTLV(char *pkt, TLV *tlv, int *sz)
 {
    USHORT *ptr = (USHORT *) pkt;

    if(*sz < 4)
    {
//       DBGTrace(*sz);
       *sz = 0;
       memset(tlv,0,sizeof(TLV));
       return pkt;
    }

    tlv->id     = ajustShortValue(*(ptr++));
    tlv->sz     = ajustShortValue(*(ptr++));
    tlv->string = (UCHAR *) ptr;
    *sz -= (tlv->sz+4);

//    DBGTrace(tlv->id);
//    DBGTrace(*sz);

#ifdef __OS2__
    DosSleep(0);
#endif

    return tlv->string + tlv->sz;
 }


 BOOL processClosePacket(HICQ icq, int *sock, int sz, UCHAR *pkt)
 {
    TLV         tbl[3];
    UCHAR       *buffer = pkt;
    int         f;

    for(f=0;f<4 && sz > 0;f++)
    {
       pkt = extractTLV(pkt,&tbl[f],&sz);
    }
    DBGTrace(sz);
    DBGTrace(f);

    if( tbl[0].id == 1 && tbl[1].id == 5 && tbl[2].id == 6 )
    {
       processCookie(icq,sock,tbl,buffer);
       return FALSE;
    }

    return TRUE;
 }

 static void processCookie(HICQ icq, int *sock, TLV *tbl, UCHAR *buffer)
 {
    /* Recebe os tres TLVs do pacote de hello, desconecta do socket principal e reconecta no novo endereco */
    int         f;
    UCHAR       *src;
    UCHAR       *dst;
    long        ip;
    int         sz;

    icqCloseSocket(*sock);
    *sock = -1;

    sz= (tbl+1)->sz;
    strncpy(buffer,(tbl+1)->string, sz);
    *(buffer+sz) = 0;

    DBGMessage(buffer);

    src = (tbl+2)->string;
    sz  = (tbl+2)->sz;
    dst = cookie;

    if(sz != 0x0100)
    {
       icqWriteSysLog(icq,PROJECT,"Unexpected cookie size received from server");
       return;
    }

    DBGTrace(sz);

    for(f=0;f<sz;f++)
       *(dst++) = *(src++);

    for(src = buffer;*src && *src != ':';src++);

    if(*src != ':')
    {
       icqWriteSysLog(icq,PROJECT,"Malformed address received from the server");
       return;
    }

    *(src++) = 0;

    DBGMessage(buffer);
    DBGTrace(atoi(src));

    ip = icqGetHostByName(buffer);

    if(!ip || ip == 0xFFFFFFFF)
    {
       icqWriteSysLog(icq,PROJECT,"Unable to resolve the main server name");
       return;
    }

    *sock = icqConnect(ip, atoi(src));

    DBGTrace(*sock);

    if(*sock < 1)
    {
       icqWriteSysLog(icq,PROJECT,"Unable to connect to the main server");
       return;
    }
    else
    {
       icqWriteSysLog(icq,PROJECT,"Connected to the main server");
    }

 }


 static void sendCookie(HICQ icq, int sock, UCHAR *pkt)
 {
    static const UCHAR tbl[]   = { 0x00, 0x00, 0x00, 0x01, 0x00, 0x06, 0x01, 0x00 };

#ifdef linux
    char buffer[sizeof(FLAP)+9+COOKIE_LEN+5];
    FLAP *flap = (FLAP *) buffer;
#else
    FLAP        *flap   = (FLAP *) pkt;
#endif

    DBGMessage("Enviar cookie (264 bytes)");

    flap->cmdStart = 0x2a;
    flap->channel  = 1;
    flap->size     = ajustShortValue(COOKIE_LEN+8);


    if(!beginSend(icq))
       return;

    CHKPoint();

    packetSeq      = 0;
    flap->sequence = ajustShortValue(packetSeq);

#ifdef linux
    memcpy(buffer+sizeof(FLAP),tbl,8);
    memcpy(buffer+sizeof(FLAP)+8,cookie, COOKIE_LEN);
    icqSend(sock,buffer,sizeof(FLAP)+8+COOKIE_LEN);

//    icqDumpPacket(icq,NULL,"Login Packet",sizeof(FLAP)+8+COOKIE_LEN,buffer);
#else
    icqSend(sock, flap,         sizeof(FLAP));
    icqSend(sock, (void *) tbl, 8);
    icqSend(sock, cookie,       COOKIE_LEN);
#endif

    finishSend(icq);

 }

 void _System executeLogon(ICQTHREAD *thd)
 {
    UCHAR *buffer = (UCHAR *) (thd+1);

    const UCHAR snd18[] = { 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x04, 0x00, 0x05 };

    const UCHAR snd42[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x1F, 0x40, 0x03, 0xE7,
                            0x03, 0xE7, 0x00, 0x00, 0x00, 0x00 };

    const UCHAR snd24[] = { 0x00, 0x05, 0x00, 0x20, 0x09, 0x46, 0x13, 0x49, 0x4C, 0x7F,
                            0x11, 0xD1, 0x82, 0x22, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00,
                            0x09, 0x46, 0x13, 0x44, 0x4C, 0x7F, 0x11, 0xD1, 0x82, 0x22,
                            0x44, 0x45, 0x53, 0x54, 0x00, 0x00 };

    const UCHAR snd12[] = { 0x00, 0x01, 0x00, 0x03, 0x01, 0x10, 0x02, 0x8A, 0x00, 0x02,
                            0x00, 0x01, 0x01, 0x01, 0x02, 0x8A, 0x00, 0x03, 0x00, 0x01,
                            0x01, 0x10, 0x02, 0x8A, 0x00, 0x15, 0x00, 0x01, 0x01, 0x10,
                            0x02, 0x8A, 0x00, 0x04, 0x00, 0x01, 0x01, 0x10, 0x02, 0x8A,
                            0x00, 0x06, 0x00, 0x01, 0x01, 0x10, 0x02, 0x8A, 0x00, 0x09,
                            0x00, 0x01, 0x01, 0x10, 0x02, 0x8A, 0x00, 0x0A, 0x00, 0x01,
                            0x01, 0x10, 0x02, 0x8A };

    DIRECTINFO                  modePkt;

    int                         sz;
    SNAC                        *snac;
    FLAP                        *flap;
    char                        *ptr;
    ULONG                       mode    = icqQueryOnlineMode(thd->icq) & 0x0000FFFF;
    ULONG                       temp;


/*
the server reply 1/7 to the 1/6, and then it goes:
SNAC 1/8
SNAC 4/2
SNAC 2/4
*/
    sendSNAC(thd->icq,0x01,0x08,0x08000000,10,snd18);
    sendSNAC(thd->icq,0x04,0x02,0x06000000,16,snd42); // Add ICBM parameter
    sendSNAC(thd->icq,0x02,0x04,0x04000000,36,snd24); // set user info

/*
SNAC 3/4 with the contact list
if status = invisible SNAC 9/5 with visible list
*/
    sendContactList(thd->icq, 0x03, 0x04, USRF_ONLIST|USRF_TEMPORARY, buffer, "Contact-list");
    if(mode == ICQ_INVISIBLE)
       sendContactList(thd->icq, 0x09, 0x05, USRF_VISIBLE, buffer, "Visible-list");


/*
SNAC 1/1E with status

client sends                // set status code
 SNAC 1,1E
 TLV(6) status-code
 TLV(8) unknown, usually 0000
 TLV(C) direct-connection-info
*/
    flap  = (FLAP *) buffer;
    snac  = (SNAC *) (flap+1);
    ptr   = (char *) (snac+1);
    sz    = 0;

    memset(flap,0,sizeof(FLAP));
    memset(snac,0,sizeof(SNAC));
    memset(&modePkt,0,sizeof(DIRECTINFO));

    flap->cmdStart      = FLAP_START;
    flap->channel       = CHANNEL_SNAC;

    snac->family        = 0x0100;
    snac->subType       = 0x1E00;
    snac->request       = 0x1E000000;

    /* Monta o pacote de saida */

    DBGTracex(mode);

    temp = ajustLongValue(ajustModeBits(thd->icq,mode));
    ptr  = insertTLV( &sz, 0x06, 4, ptr, (const char *) &temp);

    temp = 0;
    ptr  = insertTLV( &sz, 0x08, 2, ptr, (const char *) &temp);

    modePkt.ipaddr      = icqGetHostID();                               // IPADDR
    modePkt.port        = ajustLongValue(icqQueryPeerPort(thd->icq));   // port where listening for connections
    modePkt.x1          = 0x04;                                         // unknown, usually 04
    modePkt.x2          = 0x0700;                                       // unknown, usually 0007
    modePkt.x3          = 0xAE1D;                                       // unknown, 1D AE
    modePkt.x4          = 0x9EF0;                                       // unknown, F0 9E
    modePkt.x5          = 0x50000000;                                   // unknown, 00 00 00 50
    modePkt.x6          = 0x03000000;                                   // unknown, 00 00 00 03
    modePkt.x7          = 0x576B173B;                                   // unknown, 3B 17 6B 57
    modePkt.Build       = 0xE9AC183B;                                   // unknown, 3B 18 AC E9
    modePkt.x9          = 0x4E6B173B;                                   // unknown, 3B 17 6B 4E
    modePkt.x10         = 0x0000;                                       // unknown, 00 00

    ptr = insertTLV( &sz, 0x0C, sizeof(DIRECTINFO), ptr, (const char *) &modePkt);

    if(!beginSend(thd->icq))
       return;

    packetSeq++;
    flap->sequence  = ajustShortValue(packetSeq);

    sz             += sizeof(SNAC);
    flap->size      = ajustShortValue(sz);

    sz             += sizeof(FLAP);

    icqSend(sock, (void *) buffer, sz);

    finishSend(thd->icq);

/*
#ifdef DEBUG
    icqDumpPacket(thd->icq, NULL, "status packet sent", sz, (unsigned char *) buffer);
#endif
*/

/*
SNAC 1/11
if status <> invisible SNAC 9/7 with invisible list
SNAC 1/2
SNAC 15/2, to require offline messages
*/
    temp = 0;
    sendSNAC(thd->icq,0x01,0x11,0x11000000,4,&temp);

// if status <> invisible SNAC 9/7 with invisible list
    if(mode != ICQ_INVISIBLE)
       sendContactList(thd->icq, 0x09, 0x07, USRF_INVISIBLE, buffer, "Invisible-list");

// SNAC 1/2
    sendSNAC(thd->icq,0x01,0x02,0x02000000,64,snd12);  // client ready

    sysSleep(1);

/* SNAC 15/2, to require offline messages */
    sendMultiPurpose(thd->icq,0x003c,0x0002,0x02000100,0,NULL);

/*
    rqOff.TLVtype       = 0x0100;                       // 00 01 TLV-1
    rqOff.TLVsize       = 0x0a00;                       // 00 0a TLV-Size
    rqOff.bytes         = 0x0008;                       // 08 00 (LE) bytes remaining, useless
    rqOff.uin           = icqQueryUIN(thd->icq);        // 88 df Meu UIN (ULONG, sem conversao)
    rqOff.cmd           = 0x003c;                       // 3c 00 Ask for offline message
    rqOff.X1            = 0x0002;                       // 02 00 Request ID

    DBGMessage("Enviando requisicao para offline-messages");

    sendSNAC(thd->icq,0x15,0x02,0x02000100,sizeof(rqOff),&rqOff);
*/
    if(sock > 0)
       icqSystemEvent(thd->icq,ICQEVENT_ONLINE);
    DBGMessage("Thread de logon terminada");
 }


