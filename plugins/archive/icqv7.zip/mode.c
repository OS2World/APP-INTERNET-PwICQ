/*
 * MODE.C - Muda de modo, ativa/desativa a thread de comunicacao
 */

#ifdef __OS2__
  #define INCL_DOSPROCESS
#endif

 #include <stdio.h>

 #include <pwMacros.h>
 #include <stdlib.h>
 #include <time.h>

 #include "icqv7.h"

/*---[ Pacotes ]--------------------------------------------------------------------------------------------*/

 #pragma pack(1)
 struct modeTLV
 {
    USHORT type;        //  00 06           TLV6
    USHORT size;        //  00 04           Size
    ULONG  mode;        //  00 03 00 13     Status Code
 };

/*---[ Statics ]--------------------------------------------------------------------------------------------*/

 static int     thread                  = 0;
 static BOOL    isOnline                = FALSE;

 UCHAR          cookie[COOKIE_LEN]      = { 0 };
 int            sock                    = -1;

 HLIST          reqList                 = NULL;
 USHORT         atualReq                = 0;
 int            offlineMsg              = 0;
 USHORT         downCounter             = 0xFFFF;


/*---[ Prototipos ]-----------------------------------------------------------------------------------------*/

 static void _System mainThread(ICQTHREAD *);
 static void receiveFlap(HICQ,FLAP *);
 static void processFlap(HICQ,UCHAR, USHORT, char *);

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 ULONG _System setMode(HICQ icq, ULONG current, ULONG last)
 {
    struct modeTLV      modePkt;

    DBGTracex(current);

/*
#ifdef DEBUG
    if(sizeof(FLAP) != 6)
    {
       DBGMessage("******* FLAP de tamanho inv�lido");
       return last;
    }
#endif
*/
    if((current & 0xFFFF) == 0xFFFF)
    {
       /* Mudou para offline, verificar desconexao */
       DBGMessage("Desconectar");
       isOnline = FALSE;
       return ICQ_OFFLINE;
    }

    DBGTrace(thread);

    if(!thread)
    {
       thread = icqCreateThread(icq, &mainThread, 8192, BUFFERSIZE, NULL, "c2s");

       if(thread < 1)
       {
          icqWriteSysLog(icq,PROJECT,"Unable to start the connection thread");
          thread = 0;
          return ICQ_OFFLINE;
       }
       else
       {
          return current;
       }
    }

    DBGMessage("Enviar pacote de mudanca de modo");

/*
        2a              Command Start
        02              Channel ID
        1f 09           Sequence
        00 12           Size
        00 01           Family
        00 1e           Subtype
        00 00           Flags
        00 00 00 1e     Request

        00 06           TLV6
        00 04           Size
        00 03 00 13     Status Code

 struct modeTLV
 {
    USHORT type;        //  00 06           TLV6
    USHORT size;        //  00 04           Size
    ULONG  mode;        //  00 03 00 13     Status Code
 };
*/
    modePkt.type = 0x0600;
    modePkt.size = 0x0400;
    modePkt.mode = ajustLongValue(ajustModeBits(icq,current));

    icqSetServerBusy(icq,TRUE);

    sendSNAC(icq, 0x01, 0x1E, 0x1E000000, sizeof(modePkt), &modePkt);

    return current;

 }

 static void _System mainThread(ICQTHREAD *thd)
 {
    char *buffer = (char *) (thd+1);
    int  sz;

    DBGMessage("Thread de conexao iniciada");

    icqSetServiceStatus(thd->icq,ICQSRVC_C2S, TRUE);

#ifdef __OS2__
    DosSleep(10);
#endif

    isOnline    = TRUE;
    *cookie     = 0;
    offlineMsg  = 0;
    packetSeq   = random();
    reqList     = icqCreateList();
    atualReq    = 3;
    downCounter = 0xFFFF;

    if(!reqList)
    {
       icqWriteSysLog(thd->icq,PROJECT,"Unable to allocate request table");
       icqAbend(thd->icq,0);
       return;
    }

    sock        = doLogin(thd->icq, buffer);

    DBGTrace(sock);

    if(sock > 0)
    {
       if(icqLoadValue(thd->icq,"hideWhenOffline",0))
          icqSystemEvent(thd->icq,ICQEVENT_SHOW);

       icqSysLog(thd->icq,"Starting login procedure");
       DBGMessage("Conectado ao servidor");

       sz = icqRecv(sock, buffer, 1);
       while(sz >= 0 && sock > 0 && isOnline && icqIsActive(thd->icq))
       {
          if(sz > 0)
          {
             if( (sz = receiveBlock(thd->icq, sock, sizeof(FLAP)-1, buffer+1, &isOnline)) > 0)
                receiveFlap(thd->icq,(FLAP *) buffer);
          }
          else if(!icqClearToSend(thd->icq))
          {
#ifdef EXTENDED_LOG
             icqSysLog(thd->icq,"System IDLE");
#endif
             icqSetServerBusy(thd->icq,FALSE);
          }
          else
          {
             icqSendQueued(thd->icq);
          }

          sz = icqRecv(sock, buffer, 1);
       }

       if(sock > 0)
       {
          icqCloseSocket(sock);
          sock = -1;
          icqWriteSysLog(thd->icq,PROJECT,"Disconnected");
       }
    }

    CHKPoint();

    if(icqLoadValue(thd->icq,"hideWhenOffline",0))
    {
       CHKPoint();
       icqSystemEvent(thd->icq,ICQEVENT_HIDE);
    }

    icqDestroyList(reqList);
    isOnline = FALSE;
    reqList  = NULL;

    icqSetServiceStatus(thd->icq,ICQSRVC_C2S, FALSE);
    icqSystemEvent(thd->icq, ICQEVENT_OFFLINE);

    DBGMessage("Thread de conexao terminada");
    thread = 0;

 }

 static void receiveFlap(HICQ icq, FLAP *h)
 {
    UCHAR       channel = h->channel;
    USHORT      sz      = ajustShortValue(h->size);
    char        *buffer = (char *) h;

    if(sz < BUFFERSIZE)
    {
        processFlap(icq,channel,sz,buffer);
        return;
    }

    DBGMessage("********* MEGA PACKET!!! ALOCAR MEM�RIA DINAMICAMENTE");

    buffer = malloc(sz+5);

    if(!buffer)
    {
       icqWriteSysLog(icq,PROJECT,"Memory allocation error when receiving FLAP");
       icqAbend(icq,0);
    }

    processFlap(icq,channel,sz,buffer);

    free(buffer);

 }

 void logSocketError(HICQ icq, const char *filter)
 {
    char buffer[0x0100];

    sprintf(buffer,filter,icqGetSockError());
    icqWriteSysLog(icq,PROJECT,buffer);

 }

 static void processFlap(HICQ icq,UCHAR channel, USHORT sz, char *buffer)
 {

    if(receiveBlock(icq, sock, sz, (char *) buffer, NULL) < 1)
    {
       logSocketError(icq,"Socket error %d when receiving flap packet");
       isOnline = FALSE;
       return;
    }

    switch(channel)
    {
    case CHANNEL_NEW:
       DBGMessage("CHANNEL_NEW");
       processLoginPacket(icq, sock, sz, (ULONG *) buffer);
       break;

    case CHANNEL_SNAC:
       processSnac(icq,sz,(SNAC *) buffer);
       break;

    case CHANNEL_ERROR:
       DBGMessage("CHANNEL_ERROR");
       icqDumpPacket(icq, NULL, "CHANNEL_ERROR Packet received", sz, (unsigned char *) buffer);
       break;

    case CHANNEL_CLOSE:
       if(processClosePacket(icq,&sock,sz,(UCHAR *) buffer))
          icqDumpPacket(icq, NULL, "Unexpected close packet received", sz, (unsigned char *) buffer);
       break;

    }

 }

 ULONG ajustModeBits(HICQ icq, ULONG mode)
 {
#ifdef EXTENDED_LOG
    char buffer[80];
#endif

    mode &= 0x0000FFFF;

/*
      0x20000000  direct connection only for contact list
      0x10000000  direct connection by request
      0x00020000  show ip? (licq uses it on invisible state)
      0x00010000  webaware
      0x00100000  unk
*/

    if(icqLoadValue(icq, "ip:contact", 1))
       mode |= 0x20000000;

    if(icqLoadValue(icq, "ip:request", 1))
       mode |= 0x10000000;

    if(icqLoadValue(icq, "webAware", 0))
       mode |= 0x00010000;


#ifdef EXTENDED_LOG
    sprintf(buffer,"Status indicator is %08lx",mode);
    icqWriteSysLog(icq,PROJECT,buffer);
#endif

    return mode;
 }


