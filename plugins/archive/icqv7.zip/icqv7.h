/*
 * ICQV7.H - Definicoes para o protocolo V7
 */

 #include <pwMacros.h>
 #include <icqtlkt.h>

/*---[ Definitions ]---------------------------------------------------------------------------------------*/

 #define BUFFERSIZE     32768
 #define LOGIN_PORT     5190
 #define COOKIE_LEN     0x0100

#ifdef __OS2__
 #define random rand
#endif

/*---[ Packet definitions ]--------------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct flap
 {
    UCHAR       cmdStart;               // * Command Start (byte: 0x2a)
    #define FLAP_START 0x2a

    UCHAR       channel;                // * Channel ID (byte)
    #define CHANNEL_NEW         0x01    // * 0x01 - New Connection Negotiation
    #define CHANNEL_SNAC        0x02    // * 0x02 - SNAC data (non connection-oriented data)
    #define CHANNEL_ERROR       0x03    // * 0x03 - FLAP-level Error
    #define CHANNEL_CLOSE       0x04    // * 0x04 - Close Connection Negotiation

    USHORT      sequence;               // * Sequence Number (word)
    USHORT      size;                   // * Data Field Length (word)

 } FLAP;

 typedef struct snac
 {
    USHORT      family;                 // 1 word Family ID
    USHORT      subType;                // 3 word SubType ID
    UCHAR       flags[2];               // 5 byte Flags[0]
    ULONG       request;                // 7 dword Request ID
                                        // 11 variable SNAC Data
 } SNAC;

 typedef struct tlv
 {
    USHORT      id;
    USHORT      sz;
    UCHAR       *string;
 } TLV;

 typedef struct directinfo
 {
    long        ipaddr;         // IPADDR
    ULONG       port;           // port where listening for connections
    UCHAR       x1;             // unknown, usually 04
    USHORT      x2;             // unknown, usually 0007
    USHORT      x3;             // unknown, 1D AE
    USHORT      x4;             // unknown, F0 9E
    ULONG       x5;             // unknown, 00 00 00 50
    ULONG       x6;             // unknown, 00 00 00 03
    ULONG       x7;             // unknown, 3B 17 6B 57
    ULONG       Build;          // Version ID, 3B 18 AC E9
    ULONG       x9;             // unknown, 3B 17 6B 4E
    USHORT      x10;            // unknown, 00 00
 } DIRECTINFO;

 typedef struct request
 {
    USHORT id;                  // Request ID
    USHORT timer;               // Request timer
    ULONG  uin;                 // User UIN
 } REQUEST;

 struct extendedHeader
 {
    USHORT      X1;             //      WORD      1B 00
    UCHAR       X2;             //      BYTE      ??E   (08 in auto-msg-req, else 07)
    UCHAR       X3[19];         //      19 BYTE   unk, 0
    UCHAR       X4[3];          //      3 BYTE    unk, 03 00 00
    UCHAR       X5;             //      if auto-msg-req BYTE    00
    UCHAR       X6;             //      BYTE      unk, 00 or 04 (00 in auto-msg-req)
    USHORT      seq;            //      WORD      ??D, seems to be a downcounter starting from FFFF
    USHORT      X7;             //      2 BYTE    0E 00
    USHORT      seq2;           //      WORD      same as ??D
    UCHAR       X8[12];         //      12 BYTE   0
    UCHAR       subType;        //      BYTE      msg-subtype
    UCHAR       flags;          //      BYTE      msg-flags
    USHORT      status;         //      WORD      first word of my status-code (but LE)
    USHORT      priority;       //      WORD      priority
    USHORT      msgSize;        //      LNTS      msg
 };

 struct msgAckPrefix
 {
    ULONG       id;
    ULONG       id2;
    USHORT      type;           // 10 BYTE   equals to first 10 BYTE of message
    UCHAR       sz;             // Size of UIN
 };

 struct msgAckMid
 {
    USHORT      x1;             // 2 BYTE    00 03
    UCHAR       ack1[26];       // 26 BYTE   from offset 0 of TLV(2711)
    UCHAR       x2;             // BYTE      0
    UCHAR       ack2[20];       // 20 BYTE   from offset 27 of TLV(2711)
    UCHAR       acceptStatus;
    UCHAR       x3[3];          // 3 BYTE    0
    USHORT      sz;             // LNTS      message
 };


/*---[ Types ]---------------------------------------------------------------------------------------------*/

 /* Mode flags */

 #define ICQFLAG_DIRECTONLYCONT 0x2000  //  2000  direct connection only for contact list
 #define ICQFLAG_DIRECTBYREQ    0x1000  //  1000  direct connection by request

//      0001  webaware


 #define ICQ_ONLINE             0x0000  //     0000  online
 #define ICQ_FREEFORCHAT        0x0020  //     0020  free4chat
 #define ICQ_AWAY               0x0001  //     0001  away
 #define ICQ_NA                 0x0004  //     0004  n/a
 #define ICQ_NA2                0x0005  //     0005  n/a
 #define ICQ_OCCUPIED           0x0010  //     0010  occupied
 #define ICQ_OCCUPIED2          0x0011  //     0011  occupied
 #define ICQ_DND                0x0013  //     0013  dnd
 #define ICQ_INVISIBLE          0x0100  //     0100  invisible

 #define ICQ_OFFLINE            0xFFFF

//* override-status codes
//    0=don't override
//    4=away
//    9=occupied
//    A=dnd
//    E=na


/*---[ Publics ]-------------------------------------------------------------------------------------------*/

 extern int     sock;
 extern USHORT  packetSeq;
 extern UCHAR   cookie[COOKIE_LEN];
 extern ULONG   mainTimer;
 extern HLIST   reqList;
 extern USHORT  atualReq;
 extern int     offlineMsg;
 extern HMODULE module;
 extern USHORT  downCounter;

/*---[ Prototipes ]----------------------------------------------------------------------------------------*/

 int             doLogin(HICQ, char *);
 int             receiveBlock(HICQ, int, int, char *, const BOOL *);
 void            processLoginPacket(HICQ, int, int, ULONG *);
 BOOL            processClosePacket(HICQ, int *, int, UCHAR *);
 BOOL            beginSend(HICQ);
 BOOL            finishSend(HICQ);
 void            processSnac(HICQ,int,SNAC *);
 int             sendContactList(HICQ, USHORT, USHORT, ULONG, char *, const char *);

 USHORT          advancedMsg(HICQ, ULONG, USHORT, char *, ULONG);

 void            logSocketError(HICQ, const char *);

 ULONG           ajustModeBits(HICQ, ULONG);

 ULONG   _System setMode(HICQ, ULONG, ULONG);
 void    _System executeLogon(ICQTHREAD *);
 void    _System procMessage(HICQ, int, ULONG, char *, UCHAR *);
 USHORT  _System icqV7Message(HICQ, ULONG, USHORT, const char *, ULONG *);
 int     _System icqV7Confirmation(HICQ, ULONG, USHORT, BOOL, char *);

 USHORT  _System queryModeIcon(HICQ, ULONG);
 HSEARCH _System requestUserInfo(HICQ, ULONG, int);


 USHORT          ajustShortValue(USHORT);
 ULONG           ajustLongValue(ULONG);

 char *          extractTLV(char *, TLV *, int *);
 char *          insertTLV(int *, USHORT, short, char *, const char *);

 char *          copyBuffer(int,char *, char *);

 void            sendFlap(HICQ, int, UCHAR, USHORT, void *);
 void            sendSNAC(HICQ, USHORT, USHORT, ULONG, int, const void *);
 void            sendTLV(USHORT, short, const void *);

 void            sendLoginPacket(HICQ, int, UCHAR *);

 void            processGenericPacket(HICQ,USHORT,char *);
 int             processSearchResult(HICQ, REQUEST *, int, UCHAR *);
 void            sendMultiPurpose(HICQ, USHORT, USHORT, ULONG, int, void *);

 REQUEST *       searchRequest(HICQ, USHORT );
 void            deleteRequest(HICQ, REQUEST *);
 REQUEST *       createRequest(HICQ, ULONG, int );





