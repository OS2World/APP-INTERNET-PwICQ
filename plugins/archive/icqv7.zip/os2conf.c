/*
 * OS2CONF.C - Dialogo de configuracao para o plugin de protocolo V7
 */

 #include "icqv7.h"

/*---[ Prototipes ]------------------------------------------------------------------------------------------*/

 static int _System loginConfig(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System loginLoad(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System loginSave(const DLGHELPER *,HWND,HICQ,ULONG,char *);

 static int _System optionsConfig(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System optionsLoad(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System optionsSave(const DLGHELPER *,HWND,HICQ,ULONG,char *);

/*---[ Publics ]---------------------------------------------------------------------------------------------*/

 const DLGMGR login   = {       sizeof(DLGMGR),
                                loginConfig,	// Configure
                                loginLoad,	// Load
                                loginSave,	// Save
                                NULL,		// Cancel
                                NULL,		// Event
                                NULL,		// Selected
                                NULL,		// Click
                                NULL,		// Changed
                                NULL		// sysButton		
                        };

 const DLGMGR options = {       sizeof(DLGMGR),
                                optionsConfig,	// Configure
                                optionsLoad,	// Load
                                optionsSave,	// Save
                                NULL,		// Cancel
                                NULL,		// Event
                                NULL,		// Selected
                                NULL,		// Click
                                NULL,		// Changed
                                NULL		// sysButton		
                        };

/*---[ Implementing ]----------------------------------------------------------------------------------------*/


 void EXPENTRY icqv7_ConfigPage(HICQ icq, void *lixo, ULONG uin, USHORT type, HWND hwnd, const DLGINSERT *dlg, char *buffer)
 {
    if(type != 1)
       return;
    dlg->insert(hwnd, module, 1070, &login,   CFGWIN_NETWORK);
    dlg->insert(hwnd, module, 1071, &options, CFGWIN_SECURITY);
 }

 static int loginConfig(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;
    return 0;
 }

 static int loginLoad(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    dlg->loadString(hwnd,0,101,"loginServer",0x0FF,"login.icq.com");
    dlg->loadSpinButton(hwnd,0,105,"reconnect", 0, 0, 3600);
    dlg->loadCheckBox(hwnd,0,106,"hideWhenOffline",  FALSE);

    return 0;
 }

 static int loginSave(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    CHKPoint();
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    dlg->saveString(hwnd,0,101,"loginServer",0xFF);
    dlg->saveSpinButton(hwnd,0,105,"reconnect");
    dlg->saveCheckBox(hwnd,0,106,"hideWhenOffline");

    return 0;
 }


 static int optionsConfig(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;
    return 0;
 }

 static int optionsLoad(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    dlg->loadCheckBox(hwnd,0,101,"ip:contact",       TRUE);
    dlg->loadCheckBox(hwnd,0,102,"ip:request",       TRUE);
    dlg->loadCheckBox(hwnd,0,103,"webAware",         FALSE);
    dlg->loadCheckBox(hwnd,0,110,"notifyIfRemoved",  FALSE);

    dlg->loadString(hwnd,0,111,"AutoRemoveMsg",0x0FF,"");

    dlg->setRadioButton(hwnd,106,icqLoadValue(icq,"ifUpdateFails",0));

    return 0;
 }

 static int optionsSave(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    dlg->saveCheckBox(hwnd,0,101,"ip:contact");
    dlg->saveCheckBox(hwnd,0,102,"ip:request");
    dlg->saveCheckBox(hwnd,0,103,"webAware");
    dlg->saveCheckBox(hwnd,0,110,"notifyIfRemoved");

    dlg->saveString(hwnd,0,111,"AutoRemoveMsg",0xFF);

    icqSaveValue(icq,"ifUpdateFails",dlg->getRadioButton(hwnd,106,3));

    return 0;
 }

