/*
 * advanced.c - Envia uma mensagem avancada
 */

 #include <time.h>
 #include <stdio.h>
 #include <string.h>

 #include "icqv7.h"
 
/*---[ Formatos ]-----------------------------------------------------------------------------------------------*/

 #pragma pack(1)
 struct msgPrefix
 {
    ULONG       id;             // 2 DWORD  ??B, a sort of ID (it seems to be based on timestamp, ack and replies to SNAC 4,07 should use same ID)
    ULONG       id2;
    USHORT      format;         // WORD     message-format
    char        szUin;          // UIN size;
 };

/*---[ Prototipos ]---------------------------------------------------------------------------------------------*/


/*---[ Statics ]------------------------------------------------------------------------------------------------*/

/*---[ Implementacao ]------------------------------------------------------------------------------------------*/


 #define TLV5_EXTRA_BYTES 40

 USHORT advancedMsg(HICQ icq, ULONG uin, USHORT type, char *txt, ULONG id)
 {
//    const char                  tlvA[]   = {    0x00, 0x01 };

    const char                  header[] = {    0x09, 0x46, 0x13, 0x49,
                                                0x4c, 0x7f, 0x11, 0xd1,
                                                0x82, 0x22, 0x44, 0x45,
                                                0x53, 0x54, 0x00, 0x00          };

    const char                  begin[] =  {    0x1B, 0x00, 0x07, 0x00,
                                                0x00, 0x00, 0x00, 0x00,
                                                0x00, 0x00, 0x00, 0x00,
                                                0x00, 0x00, 0x00, 0x00,
                                                0x00, 0x00, 0x00, 0x00,
                                                0x00, 0x00, 0x03, 0x00,
                                                0x00, 0x00                      };


    char                        bUIN[20];
    FLAP                        flap;
    SNAC                        snac;
    USHORT                      sz;
    USHORT                      szData;
    USHORT                      temp;
    ULONG                       color;
    int                         f;
    struct msgPrefix            prefix;


//    txt    = "meleca meleca";

    sz     = strlen(txt)+1;
    szData = sz+61;

    memset(&flap,0,sizeof(FLAP));
    memset(&snac,0,sizeof(SNAC));
    memset(&prefix,0,sizeof(struct msgPrefix));

    sprintf(bUIN,"%ld",uin);
    prefix.szUin = strlen(bUIN);

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;

    flap.size           = ajustShortValue(      sizeof(SNAC)
                                                +sizeof(prefix)
                                                +prefix.szUin
                                                +szData                 // TLV-2711
                                                +TLV5_EXTRA_BYTES       // TLV-5 Data
                                                +8                      // TLV3 + TLV-5 Prefix
                                                );
    snac.family         = 0x0400;
    snac.subType        = 0x0600;
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = 0x06000000;

    prefix.id           = ajustLongValue(id);           // 2 DWORD  ??B, a sort of ID (it seems to be based on timestamp, ack and replies to SNAC 4,07 should use same ID)
    prefix.id2          = mainTimer;
    prefix.format       = 0x0200;                       // WORD     message-format

    if(!beginSend(icq))
       return -1;

    packetSeq++;

    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap,   sizeof(FLAP));
    icqSend(sock, &snac,   sizeof(SNAC));
    icqSend(sock, &prefix, sizeof(prefix));
    icqSend(sock, bUIN,    prefix.szUin);

    /* Formata e envia o TLV-5 */
    temp = 0x0500;
    icqSend(sock, &temp, 2);
    temp = ajustShortValue(szData+TLV5_EXTRA_BYTES);
    icqSend(sock, &temp,  2);

    temp = 0;
    icqSend(sock, &temp, 2);

    icqSend(sock, &prefix.id,  4);
    icqSend(sock, &prefix.id2, 4);

    icqSend(sock, (void *) header, 16);

    /* Envia o TLV-A */
    temp = 0x0A00;
    icqSend(sock, &temp, 2);
    temp = 0x0200;
    icqSend(sock, &temp, 2);
    temp = 0x0100;
    icqSend(sock, &temp, 2);


    /* Envia o TLV-F */
    temp = 0x0F00;
    icqSend(sock, &temp, 2);
    temp = 0;
    icqSend(sock, &temp, 2);

    /* Envia o TLV 2711 --------------------------------------------------*/

    temp = 0x1127;
    icqSend(sock, &temp, 2);
    temp = ajustShortValue(szData);
    icqSend(sock, &temp,  2);

    icqSend(sock, (void *) begin, 26);  // 26 BYTE  ??E, 1B 00 07 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 00 00 00

    temp = 0;
    icqSend(sock, &temp, 1);            // BYTE     unk, 00 or 04 (00 on auto-msg-req)

    downCounter--;

    temp = downCounter;
    icqSend(sock, &temp,2);             // WORD     ??D, seems to be a downcounter starting from FFFF

    temp = 0x000E;
    icqSend(sock, &temp,2);             // WORD     0E 00  (it could be a LE counter of following bytes: 0E = 2+12)

    temp = downCounter;
    icqSend(sock, &temp,2);             // WORD     same as ??D

    color = 0;

    for(f=0;f<3;f++)
       icqSend(sock, &color, 4);

    bUIN[0] = type;
    bUIN[1] = 0;
    icqSend(sock, bUIN,2);              // BYTE     msg-subtype
                                        // BYTE     msg-flags

    temp = 0;
    icqSend(sock, &temp,2);             // WORD     first word of my status-code, but LE  (0 for strange-msg)
    icqSend(sock, &temp,2);             // WORD     priority

    temp = sz;
    icqSend(sock, &temp,2);             // LNTS     msg

    icqSend(sock, txt,          sz);

    color = icqLoadValue(icq, "msg.Foreground", 0);
    icqSend(sock, &color,       sizeof(color));

    color = ajustLongValue(icqLoadValue(icq, "msg.Background", 0xFFFFFF00));
    icqSend(sock, &color,       sizeof(color));

    /* Envia o TLV-3 */
    temp = 0x0300;
    icqSend(sock, &temp, 2);
    temp = 0;
    icqSend(sock, &temp, 2);

    finishSend(icq);

    return 0;
 }

/*

0000 2A 02 00 12 00 97
0000 00 04 00 06 00 00 00 00    00 06 3C 2D 53 73 1A 00   ..........<-Ss..
0010 00 00 00 02 08 32 37 32    34 31 32 33 34 00 05 00   .....27241234...
0020 72 00 00 3C 2D 53 73 1A    00 00 00 09 46 13 49 4C   r..<-Ss.....F.IL
0030 7F 11 D1 82 22 44 45 53    54 00 00 00 0A 00 02 00   ...."DEST.......
0040 01 00 0F 00 00 27 11 00    4D 1B 00 07 00 00 00 00   .....'..M.......
0050 00 00 00 00 00 00 00 00    00 00 00 00 00 00 00 03   ................
0060 00 00 00 00 FE FF 0E 00    FE FF 00 00 00 00 00 00   ................
0070 00 00 00 00 00 00 01 00    00 00 00 00 0E 00 6D 65   ..............me
0080 6C 65 63 61 20 6D 65 6C    65 63 61 00 00 00 00 00   leca meleca.....
0090 FF FF FF 00 00 03 00 00                              ........


        2A
        02
        00 12
        00 97

        00 04
        00 06
        00 00
        00 00 00 06

        3C 2D 53 73
        1A 00 00 00

        00 02

        08
        32 37 32 34
        31 32 33 34

        00 05
        00 72           114 Bytes (Deveria ser 115)

        00 00
        3C 2D 53 73
        1A 00 00 00

        09 46 13 49
        4C 7F 11 D1
        82 22 44 45
        53 54 00 00

        00 0A
        00 02
        00 01

        00 0F
        00 00




        27 112
        00 4D   = 77 bytes      ---> O CORRETO SERIA 75 Bytes

        1B 00
        07

        00 00 00 00
        00 00 00 00
        00 00 00 00
        00 00 00 00
        00 00 00

        03 00 00 00
        00
        FE FF
        0E 00
        FE FF

        00 00 00 00
        00 00 00 00
        00 00 00 00

        01
        00
        00 00
        00 00

        0E 00
        6D 65 6C 65
        63 61 20 6D
        65 6C 65 63
        61 00

        00 00 00 00
        FF FF FF 00


        00 03
        00 00

        (16*6)+15+4


*/
