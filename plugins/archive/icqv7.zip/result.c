/*
 * RESULT.C - Processa pacote de resultado de pesquisa
 */

 #include <string.h>
 #include <stdio.h>

 #include <pwMacros.h>

 #include "icqv7.h"

/*---[ Definicoes ]-----------------------------------------------------------------------------------------*/

 #pragma pack(1)
 struct resultcmd
 {
    char key[3];
    int ( * _System exec)(HICQ,REQUEST *,int,UCHAR *);
 } CMD;

 #define FPREFIX (void (* _System)(HICQ, REQUEST *, int, UCHAR *))

/*---[ Prototipos das funcoes de servico ]------------------------------------------------------------------*/

 static int _System shortInfo(HICQ,REQUEST *, int, UCHAR *);
 static int _System shortInfoLast(HICQ,REQUEST *, int, UCHAR *);
 static int _System shortInfoInvalid(HICQ,REQUEST *, int, UCHAR *);

/*---[ Tabela de comandos ]---------------------------------------------------------------------------------*/

/*
 static const RESULTCMD cmd[] =
 {
        0x90,   0x01, 0x0A,     shortInfo,      //  wp-short-request result
        0x9A,   0x01, 0x0A,     shortInfoLast,  //  wp-short-request result (the last)

        0,      0,       0,     NULL
 };
*/

 static const struct resultcmd cmd[] =
 {
        { { 0x90,   0x01, 0x0A },     shortInfo        },  //  wp-short-request result
        { { 0x9A,   0x01, 0x0A },     shortInfoLast    },  //  wp-short-request result (the last)
        { { 0x9a,   0x01, 0x32 },     shortInfoInvalid },

        { { 0,      0,       0 },     NULL }
 };

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 int processSearchResult(HICQ icq, REQUEST *id, int sz, UCHAR *pkt)
 {
    const struct resultcmd  *ptr    = cmd;

    while(ptr->exec)
    {
       if( !memcmp(pkt,ptr->key,3))
          return ptr->exec(icq, id, sz-3, pkt+3);
       ptr++;
    }

    icqDumpPacket(icq, NULL, "Unexpected search response received", sz, pkt);

    return -1;  // Mantem a requisicao
 }

 static char *extractString(UCHAR **src, int *sz)
 {
    char   *ptr  = *src;
    USHORT bytes = *( (USHORT *) ptr );

    ptr += 2;

    if(bytes > *sz)
    {
       *sz = 0;
       return NULL;
    }

    *src = (ptr+bytes);

    *sz  -= (bytes+2);

    return ptr;
 }

 static void sendAutoRemoveReply(HICQ icq, ULONG uin, char *buffer)
 {
    if(!icqLoadValue(icq,"notifyIfRemoved",0))
       return;

    icqLoadString(icq, "AutoRemoveMsg", "", buffer, 0xFF);

    if(!*buffer)
       return;

    icqSendMessage(icq, uin, MSG_NORMAL, buffer);

 }

 static int _System shortInfoInvalid(HICQ icq,REQUEST *id, int size, UCHAR *pkt)
 {
    HUSER       usr     = icqQueryUserHandle(icq,id->uin);
    char        buffer[0x0100];

    sprintf(buffer,"Unable to update ICQ#%lu",id->uin);
    icqWriteSysLog(icq,PROJECT,buffer);

    if(usr)
    {
      usr->flags &= ~(USRF_REFRESH|USRF_SEARCHING);

      if(usr->flags & USRF_TEMPORARY)
      {
         switch(icqLoadValue(icq,"ifUpdateFails",0))
         {
         case 0:        // Keep user
            break;

         case 1:        // Remove only if no messages
            if(!icqQueryMessage(icq, id->uin))
            {
               sprintf(buffer,"Rejecting ICQ#%lu (no messages)",id->uin);
               icqWriteSysLog(icq,PROJECT,buffer);
               sendAutoRemoveReply(icq,usr->uin,buffer);
               icqRejectUser(icq,usr,TRUE);
            }
            break;

         case 2:        // Remove with messages
            sprintf(buffer,"Rejecting ICQ#%lu",id->uin);
            icqWriteSysLog(icq,PROJECT,buffer);
            sendAutoRemoveReply(icq,usr->uin,buffer);
            icqRejectUser(icq,usr,TRUE);
            break;
         }
      }

/*
       if( (usr->flags & USRF_TEMPORARY) && !icqQueryMessage(icq, id->uin))
       {
          sprintf(buffer,"Removing ICQ#%lu from database",id->uin);
          icqWriteSysLog(icq,PROJECT,buffer);
          icqRejectUser(icq,usr);
       }
*/

    }

    return 0;   // Remove a requisicao
 }


 static int _System shortInfoLast(HICQ icq, REQUEST *id, int size, UCHAR *pkt)
 {
    CHKPoint();
    shortInfo(icq, id, size, pkt);
    return 0;   // Remove a requisicao
 }
 static int _System shortInfo(HICQ icq, REQUEST *id, int size, UCHAR *pkt)
 {
    ULONG       uin;
    HUSER       usr;
    int         sz              = *((USHORT *) pkt);
    char        *ptr[4];
    char        info[7];
    int         f;

    CHKPoint();

    if(sz > size)
       icqWriteSysLog(icq,PROJECT,"Unexpected packet size in the user update information");

/*
* wp-info
    WORD    length of this record (you can't rely on fields if record is shorter)
    UIN     his uin

    ptr[0]  LNTS    nick
    ptr[1]  LNTS    first
    ptr[2]  LNTS    last
    ptr[3]  LNTS    email

    info[0] BYTE    auth (0=required, 1=always)
    info[1] BYTE    status (00 offline, 01 online, 02 not webaware)
    info[2] BYTE    unknown, usually 0
    info[3] BYTE    sex
    info[4] BYTE    age

*/

    DBGTrace(sz);
    DBGTrace(size);

    pkt += 2;
    uin  = *( (ULONG *) pkt );

#ifdef EXTENDED_LOG
    icqDumpPacket(icq, icqQueryUserHandle(icq, uin), "User update received", size, (unsigned char *) pkt);
#endif

    DBGTrace(uin);

    pkt+= 4;

    for(f=0;f<4;f++)
    {
       if(sz > 0)
       {
          ptr[f] = extractString(&pkt, &sz);
          DBGMessage(ptr[f]);
       }
       else
       {
          ptr[f] = NULL;
       }
    }

    for(f=0;f<7;f++)
    {
       if(sz > 0)
       {
          info[f] = *(pkt++);
          sz--;
       }
       else
       {
          info[f] = 0;
       }

    }

    for(f=0;f<4;f++)
       icqConvertCodePage(icq, TRUE, ptr[f], -1);

    DBGTrace(info[0]);
    DBGTrace(info[1]);
    DBGTrace(info[2]);
    DBGTrace(info[3]);
    DBGTrace(info[4]);
    DBGTrace(info[5]);
    DBGTrace(info[6]);

    DBGTrace(sz);

    usr = icqUpdateUserInfo(    icq,
                                uin,
                                FALSE,
                                ptr[0],
                                ptr[1],
                                ptr[2],
                                ptr[3],
                                info[0] == 0 );
/*

    if(usr)
    {
       usr->sex = info[3];
       usr->age = info[4];
    }
*/

    return 1;
 }

