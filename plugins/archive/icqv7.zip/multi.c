/*
 * MULTI.C - Processa o pacote multi-fun��o
 */

 #include <stdio.h>
 #include <time.h>
 #include <string.h>

 #include <pwMacros.h>

 #include "icqv7.h"

/*---[ Definicoes ]-----------------------------------------------------------------------------------------*/

 #pragma pack(1)
 struct header
 {
    USHORT      bytes;          // WORD   (LE) bytes remaining, useless
    ULONG       uin;            // UIN    my uin
    USHORT      type;           // WORD   message-type
    USHORT      request;        // WORD   req-id
 };

 struct offlineMsg
 {
    ULONG       uin;            // UIN     his uin
    USHORT      year;           // WORD    year (LE)
    UCHAR       month;          // BYTE    month (1=jan)
    UCHAR       day;            // BYTE    day
    UCHAR       hour;           // BYTE    hour (GMT time)
    UCHAR       minutes;        // BYTE    minutes
    UCHAR       type;           // BYTE    msg-subtype
    UCHAR       flags;          // BYTE    msg-flags
    USHORT      size;           // LNTS    msg
    // Text
                                // WORD    0000, present only in single messages
 };


 struct multicmd
 {
    USHORT type;
    void ( * _System exec)(HICQ,USHORT,int,UCHAR *);
 };

 #define FPREFIX (void (* _System)(HICQ, USHORT, int, UCHAR *))

/*---[ Prototipos das funcoes de servico ]------------------------------------------------------------------*/

 static void _System offlineComplete(HICQ, USHORT, int, UCHAR *);
 static void _System offlineMessage(HICQ, USHORT, int, struct offlineMsg *);
 static void _System searchResult(HICQ, USHORT, int, UCHAR *);

/*---[ Tabela de comandos ]---------------------------------------------------------------------------------*/

 static const struct multicmd cmd[] =
 {
    { 0x0041,     FPREFIX offlineMessage },
    { 0x0042,     FPREFIX offlineComplete },
    { 0x07DA,     FPREFIX searchResult },

    { 0,          NULL }
 };

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 void processGenericPacket(HICQ icq, USHORT sz, char *pkt)
 {
    USHORT                      type    = ((struct header *)pkt)->type;
    USHORT                      request = ((struct header *)pkt)->request;
    const struct multicmd       *ptr    = cmd;
    char                        log[80];


    DBGTrace( ((struct header *)pkt)->bytes );
    DBGTrace( sz );

    if( ((struct header *)pkt)->bytes != (sz-2) )
       icqWriteSysLog(icq,PROJECT,"Unexpected size indicator in the multi-purpose packet, using size of the received data");

    if( ((struct header *)pkt)->uin != icqQueryUIN(icq) )
    {
       icqWriteSysLog(icq,PROJECT,"Unexpected UIN received in the multi-purpose packet");
       return;
    }

    pkt += sizeof(struct header);
    sz  -= sizeof(struct header);

    DBGTrace(type);
    DBGTrace(request);

    while(ptr->exec)
    {
       if(ptr->type == type)
       {
          ptr->exec(icq, request, sz, pkt);
          return;
       }
       ptr++;
    }

    sprintf(log,"Unexpected multi-purpose packet (type=%04x)",type);
    icqDumpPacket(icq, NULL, log, sz, pkt);

 }

 static void _System offlineComplete(HICQ icq, USHORT rq, int sz, UCHAR *pkt)
 {
    char log[80];

    icqSystemEvent(icq,ICQEVENT_LOGONCOMPLETE);

    switch(offlineMsg)
    {
    case 0:
       strcpy(log,"No messages received from the server");
       break;

    case 1:
       strcpy(log,"1 message received from the server");
       break;

    default:
       sprintf(log,"%d offline messages received from the server",offlineMsg);
    }

    icqWriteSysLog(icq,PROJECT,log);
    sendMultiPurpose(icq,0x003E,0x0002,0x02000100,0,NULL);

 }

 static void _System offlineMessage(HICQ icq, USHORT rq, int sz, struct offlineMsg *msg)
 {
    struct tm t;

    if(sz < sizeof(struct offlineMsg))
    {
       icqWriteSysLog(icq,PROJECT,"Offline message packet with invalid size received");
       return;
    }
    sz -= sizeof(struct offlineMsg);

    DBGTrace(msg->uin);
    DBGTrace(msg->year);
    DBGTrace(msg->month);               // BYTE    month (1=jan)
    DBGTrace(msg->day);                 // BYTE    day
    DBGTrace(msg->hour);                // BYTE    hour (GMT time)
    DBGTrace(msg->minutes);             // BYTE    minutes
    DBGTrace(msg->type);                // BYTE    msg-subtype
    DBGTrace(msg->flags);               // BYTE    msg-flags
    DBGTrace(msg->size);                // LNTS    msg

    if(msg->size > sz)
    {
       icqWriteSysLog(icq,PROJECT,"Offline message packet with invalid text size received");
       return;
    }

   DBGTracex(msg->type);
   DBGMessage( ((char *) (msg+1)) );

   memset(&t,0,sizeof(struct tm));

   offlineMsg++;

   t.tm_mday           = msg->day;         /* day of the month [1-31]                */
   t.tm_mon            = msg->month-1;     /* months since January [0-11]            */
   t.tm_year           = msg->year-1900;   /* years since 1900                       */

   t.tm_hour           = msg->hour;        /* hours since midnight [0-23]            */
   t.tm_min            = msg->minutes;     /* minutes after the hour [0-59]          */

   icqInsertMessage(icq, msg->uin, 0, msg->type, mktime(&t), 0, msg->size, (const char *) (msg+1));

 }


/*

multi.c(70):    ((struct header *)pkt)->bytes = 80
multi.c(71):    sz = 82
multi.c(85):    type = 65
multi.c(86):    request = 512
multi.c(117):   msg->uin = 5496712
multi.c(118):   msg->year = 2001
multi.c(119):   msg->month = 10
multi.c(120):   msg->day = 31
multi.c(121):   msg->hour = 0
multi.c(122):   msg->minutes = 0
multi.c(123):   msg->type = 1
multi.c(124):   msg->flags = 0
multi.c(125):   msg->size = 56
multi.c(70):    ((struct header *)pkt)->bytes = 9
multi.c(71):    sz = 11
multi.c(85):    type = 66
multi.c(86):    request = 512


*/

 #pragma pack(1)
 struct multiPurpose    // Multi-purpose
 {
    USHORT TLVtype;     // 00 01 TLV-1
    USHORT TLVsize;     // 00 0a TLV-Size
    USHORT bytes;       // 08 00 (LE) bytes remaining, useless
    ULONG  uin;         // 88 df Meu UIN (ULONG, sem conversao)
    USHORT cmd;         // 3c 00 Ask for offline message
    USHORT reqID;       // 02 00
 };

 void sendMultiPurpose(HICQ icq, USHORT cmd, USHORT req, ULONG id, int sz, void *data)
 {
    FLAP                flap;
    SNAC                snac;
    struct multiPurpose pkt;

    if(!data)
       sz = 0;

    pkt.TLVtype       = 0x0100;                       // 00 01 TLV-1
    pkt.TLVsize       = ajustShortValue(0x0a+sz);     // 00 0a TLV-Size
    pkt.bytes         = 0x0008 + sz;                  // 08 00 (LE) bytes remaining, useless
    pkt.uin           = icqQueryUIN(icq);             // 88 df Meu UIN (ULONG, sem conversao)
    pkt.cmd           = cmd;                          // xx xx Ask for offline message
    pkt.reqID         = req;                          // 02 00 Request ID

//    sendSNAC(icq,0x15,0x02,id,sizeof(pkt),&pkt);

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;
    flap.size           = ajustShortValue(sizeof(SNAC)+sizeof(pkt)+sz);

    snac.family         = 0x1500;
    snac.subType        = 0x0200;
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = id;

    if(!beginSend(icq))
       return;

    packetSeq++;
    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap, sizeof(FLAP));
    icqSend(sock, &snac, sizeof(SNAC));
    icqSend(sock, &pkt,  sizeof(pkt));

    if(sz)
       icqSend(sock, (void *) data,   sz);

    finishSend(icq);


 }

 static void _System searchResult(HICQ icq, USHORT req, int sz, UCHAR *pkt)
 {
    REQUEST *id = searchRequest(icq, req);

    if(processSearchResult(icq,id,sz,pkt))
       return;

    DBGMessage("Pesquisa terminada");

    if(id)
    {
       icqWriteSysLog(icq,PROJECT,"Search complete");
       icqSystemEvent(icq,ICQEVENT_ENDSEARCH);
       deleteRequest(icq, id);
    }

 }


