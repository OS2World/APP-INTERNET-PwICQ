/*
 * NETWORK.C - Envia/Recebe pacotes
 */

#ifdef __OS2__
   #include <nerrno.h>
#else
   #include <errno.h>
#endif

 #include <string.h>

 #include <pwMacros.h>

 #include "icqv7.h"

/*---[ Statics ]--------------------------------------------------------------------------------------------*/

 USHORT                 packetSeq       = 0x2301;
 static const BOOL      true            = TRUE;

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 int receiveBlock(HICQ icq, int sock, int size, char *ptr, const BOOL *isOnline)
 {
    int  bytes;
    int  recv    = 0;

    if(!isOnline)
       isOnline = &true;

    do
    {
       bytes = icqRecv(sock, ptr, size);

       while(bytes == 0 && icqIsActive(icq) && *isOnline)
          bytes = icqRecv(sock, ptr, size);


/*
#ifdef __OS2__
      while(bytes < 0 && icqGetSockError() == 10035 && icqIsActive(icq))
#else
      while(bytes < 0 && icqGetSockError() == EWOULDBLOCK && icqIsActive(icq))
#endif
       {
          icqWriteSysLog(icq,PROJECT,"Socket timeout when receiving block");
          bytes = icqRecv(sock, ptr, size);
       }
*/

       if(bytes < 1)
          return bytes;

       ptr  += bytes;
       size -= bytes;
       recv += bytes;
    } while(size > 0);
    return recv;
 }

 USHORT ajustShortValue(USHORT vlr)
 {
    return ((vlr & 0xFF00) >> 8) | ( (vlr & 0x00FF) << 8 );
 }

 void sendFlap(HICQ icq, int sock, UCHAR channel, USHORT size, void *pkt)
 {
    FLAP        flap;

    flap.cmdStart = 0x2a;
    flap.channel  = channel;
    flap.size     = ajustShortValue(size);

    if(!beginSend(icq))
       return;

    packetSeq++;
    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap, sizeof(FLAP));
    icqSend(sock, pkt,   size);

    finishSend(icq);
 }

 void sendSNAC(HICQ icq, USHORT family, USHORT subType, ULONG request, int sz, const void *pkt)
 {
    FLAP flap;
    SNAC snac;

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;
    flap.size           = ajustShortValue(sizeof(SNAC)+sz);

    snac.family         = ajustShortValue(family);
    snac.subType        = ajustShortValue(subType);
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = request;

    if(!beginSend(icq))
       return;

    packetSeq++;
    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap, sizeof(FLAP));
    icqSend(sock, &snac, sizeof(SNAC));

    if(sz)
       icqSend(sock, (void *) pkt,   sz);

    finishSend(icq);
 }


ULONG ajustLongValue(ULONG l)
 {
    ULONG  ret;
    UCHAR  *o   = (UCHAR *) &l;
    UCHAR  *d   = (UCHAR *) &ret;

    // nwLong(0x 01 23 45 67) = 67452301

    *(d++) = *(o+3);
    *(d++) = *(o+2);
    *(d++) = *(o+1);
    *(d++) = *o;

    /*
    #ifdef _DBG_MODE_
       if(ret != htonl(l))
       {
         DBGMessage("**** Erro na conversao");
         DBGTracex(ret);
         DBGTracex(htonl(l));
         exit(-1);
       }
    #endif
    */

    return ret;
 }

/*
 void sendTLV(USHORT type, short size, const void *ptr)
 {
    if(size < 0)
       size = strlen(ptr);

    type = ajustShortValue(type);
    icqSend(sock, &type, 2);

    type = ajustShortValue(size);
    icqSend(sock, &type, 2);

    if(size > 0 && ptr)
       icqSend(sock, (char *) ptr, size);

 }

*/
