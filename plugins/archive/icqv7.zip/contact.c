/*
 * CONTACT.C - Processamento da contact-list
 */

 #include <stdio.h>
 #include <string.h>

 #include <pwMacros.h>
 #include "icqv7.h"


/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 #define isUserValid(u,flag) ((u->flags & flag) && (u->flags & USRF_ONLIST))

 int sendContactList(HICQ icq, USHORT family, USHORT subType, ULONG flag, char *pkt, const char *txt)
 {
    /* Envia a contact-list */
    HUSER       u;
    int         qtd   = 0;
    int         sz      = 0;
    FLAP        *flap   = (FLAP *) pkt;
    SNAC        *snac   = (SNAC *) pkt;


    for(u = icqQueryFirstUser(icq);u;u = icqQueryNextUser(icq,u))
    {
       if( isUserValid(u,flag) )        // Usar a MACRO!
       {
          qtd++;
          sz++;
          sprintf(pkt,"%ld",u->uin);
          sz += strlen(pkt);
       }
    }
    sz += sizeof(SNAC);

    if(qtd)
    {
       sprintf(pkt,"%d users in the %s",qtd,txt);
       icqWriteSysLog(icq,PROJECT,pkt);
    }
    else
    {
       sprintf(pkt,"No users in the %s",txt);
       icqWriteSysLog(icq,PROJECT,pkt);
       sendSNAC(icq,family,subType,ajustLongValue( (ULONG) subType),0,NULL);

       return 0;
    }

    DBGMessage("Enviando contact-list...");
    DBGTrace(qtd);
    DBGTrace(sz);

    if(!beginSend(icq))
       return -1;

    memset(flap,0,sizeof(FLAP));
    flap->cmdStart      = 0x2a;
    flap->channel       = CHANNEL_SNAC;
    flap->size          = ajustShortValue(sz);

    packetSeq++;
    flap->sequence = ajustShortValue(packetSeq);

    DBGTrace(packetSeq);

    icqSend(sock, flap, sizeof(FLAP));

    memset(snac,0,sizeof(SNAC));
    snac->family        = ajustShortValue(family);
    snac->subType       = ajustShortValue(subType);
    snac->request       = ajustLongValue( (ULONG) subType);

    icqSend(sock, snac, sizeof(SNAC));

    for(u = icqQueryFirstUser(icq);u;u = icqQueryNextUser(icq,u))
    {
       if( isUserValid(u,flag) )        // USAR A MACRO!!!
       {
          sz--;
          sprintf(pkt+10,"%ld",u->uin);
          *pkt = strlen(pkt+10);
          sz -= *pkt;
          icqSend(sock, pkt, 1);
          icqSend(sock, pkt+10, *pkt);
       }
    }

    DBGTrace(sz);
    DBGTrace(sizeof(SNAC));

    finishSend(icq);

    if(sz != sizeof(SNAC))
    {
       icqWriteSysLog(icq,PROJECT,"Failure on packet size calculation");
       icqAbend(icq,0);
       return -1;
    }

    return 0;
 }


