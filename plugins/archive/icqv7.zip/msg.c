/*
 * MSG.C - Processa um SNAC de mensagem
 */

 #include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
 #include <string.h>

 #include <pwMacros.h>
 #include "icqv7.h"

/*---[ Estruturas ]-----------------------------------------------------------------------------------------*/
/*
 #pragma pack(1)

 struct extendedHeader
 {
    USHORT      X1;             //      WORD      1B 00
    UCHAR       X2;             //      BYTE      ??E   (08 in auto-msg-req, else 07)
    UCHAR       X3[19];         //      19 BYTE   unk, 0
    UCHAR       X4[3];          //      3 BYTE    unk, 03 00 00
    UCHAR       X5;             //      if auto-msg-req BYTE    00
    UCHAR       X6;             //      BYTE      unk, 00 or 04 (00 in auto-msg-req)
    USHORT      seq;            //      WORD      ??D, seems to be a downcounter starting from FFFF
    USHORT      X7;             //      2 BYTE    0E 00
    USHORT      seq2;           //      WORD      same as ??D
    UCHAR       X8[12];         //      12 BYTE   0
    UCHAR       subType;        //      BYTE      msg-subtype
    UCHAR       flags;          //      BYTE      msg-flags
    USHORT      status;         //      WORD      first word of my status-code (but LE)
    USHORT      priority;       //      WORD      priority
    USHORT      msgSize;        //      LNTS      msg
 };
*/
/*---[ Prototipos ]-----------------------------------------------------------------------------------------*/

 static BOOL message(HICQ, ULONG, TLV *);
 static BOOL url(HICQ, ULONG, TLV *);
 static BOOL advanced(HICQ, ULONG, TLV *, ULONG, ULONG, USHORT);
 static void dumpTLV(HICQ, const char *, ULONG, TLV *);
 static BOOL procExtendedMsg(HICQ,ULONG,USHORT,struct extendedHeader *);
 static void sendConfirmation(HICQ, ULONG, const char *, ULONG, ULONG, USHORT);
 static void setUserLocalIP(HICQ, ULONG, long);

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 void _System procMessage(HICQ icq, int size, ULONG req, char *pkt, UCHAR *buffer)
 {
    char        *ptr            = pkt;
    int         sz;
    char        temp[0x0100];
    USHORT      msgFormat;
    ULONG       uin;
    HUSER       usr;
    time_t      onlineSince     = 0;
    short       qtd;
    ULONG       status          = ICQ_OFFLINE;
    TLV         tlv;
    BOOL        error           = TRUE;
    ULONG       id1;
    ULONG       id2;

    id1        = *( (ULONG *) ptr);
    ptr       += 4;

    id2        = *( (ULONG *) ptr);
    ptr       += 4;

    msgFormat  = ajustShortValue( *( (USHORT *) ptr ) );
    ptr       += 2;

    if(*ptr > 20)
    {
       icqDumpPacket(icq, NULL, "Unexpected message received", size, (unsigned char *) pkt);
       return;
    }

//    icqDumpPacket(icq, NULL, "Message received", size, (unsigned char *) pkt);

    sz         = *(ptr++);
    DBGTrace(sz);

    ptr        = copyBuffer(sz,temp,ptr);
    *(temp+sz) = 0;
    sz         = size-sz;
    sz        -= 10;

    DBGMessage(temp);
    uin = atol(temp);

    if(!uin)
    {
       icqDumpPacket(icq, NULL, "Unexpected UIN received", size, (unsigned char *) pkt);
       return;
    }

#ifdef LOGUSER
    if(uin == LOGUSER)
       icqDumpPacket(icq, icqQueryUserHandle(icq, uin), "Advanced Message", size, pkt);
#endif

    usr = icqQueryUserHandle(icq, uin);

    if(usr)
       icqRegisterUserAction(usr);

    ptr += 2;
    qtd  = ajustShortValue( *( (USHORT *) ptr ) );
    ptr += 2;
    sz  -= 4;

    DBGTrace(qtd);
    DBGTrace(sz);

    ptr = extractTLV(ptr, &tlv, &sz);

//     while(qtd-- && sz > 0)
    while(tlv.id && sz > 0)
    {
       qtd--;

//        DBGTracex(tlv.id);
//        dumpTLV(icq,"Message TLV %d received from ICQ#%d",uin,&tlv);

       switch(tlv.id)
       {
       case 0x01: // TLV(1)   unknown, usually 0050
          break;

       case 0x04: // TLV(4)   unknown, usually 0000, not present in file-req
          break;

       case 0x06: // TLV(6)   sender's status
          status = ajustLongValue(*( (ULONG *) tlv.string));
          DBGTracex(status);
          icqSetUserOnlineMode(icq, uin, status);
          break;

       case 0x0F: // TLV(F)   a time, in seconds
          break;

       case 0x02: //TLV(2)   TIME_T   member since
          if(qtd < 0 && msgFormat == 1)
             error = message(icq,uin,&tlv);
          break;

       case 0x03: // TLV(3)   TIME_T   online since
          onlineSince = ajustLongValue( * ((ULONG *) tlv.string) );
          break;

       case 0x05:
          switch(msgFormat)
          {
          case 0x04:   // url or contacts or auth-req or userAddedYou
             error = url(icq,uin,&tlv);
             break;

          case 0x02:   // advanced message
             error = advanced(icq,uin,&tlv,id1,id2,ajustShortValue(msgFormat));
             break;

          default:
             sprintf(temp,"Unexpected type 0x%04x (%d)",msgFormat,msgFormat);
             strncat(temp," in TLV %d from ICQ#%d",0xFF);
             dumpTLV(icq,temp,uin,&tlv);
          }
          break;

       default:
          dumpTLV(icq,"Unexpected TLV 0x%04lx in message from ICQ#%d",uin,&tlv);

       }
       ptr = extractTLV(ptr, &tlv, &sz);
    }

    DBGTrace(sz);

    if(error)
       icqDumpPacket(icq, usr, "Unable to decode message format", size, (unsigned char *) pkt);
    else if(sz > 0)
       icqDumpPacket(icq, usr, "Found extra bytes in message packet", size, (unsigned char *) pkt);

    if(status != ICQ_OFFLINE)
       usr = icqSetUserOnlineMode(icq, uin, status);
    else
       usr = icqQueryUserHandle(icq, uin);

    if(usr && onlineSince)
       usr->onlineSince = onlineSince;
/*
#ifdef DEBUG
    if(usr)
    {
       strftime(temp,0xFF,"Online desde: %a, %D %T",localtime( (long *) &usr->onlineSince) );
       DBGMessage(temp);
       DBGMessage(asctime(gmtime((long *) &usr->onlineSince)));
    }
#endif
*/
 }


 static BOOL message(HICQ icq, ULONG uin, TLV *tlv)
 {
    char *ptr = tlv->string;
    int  sz;
    int  msgSize;
    char logLine[80];

    if(tlv->id != 0x02)
       return TRUE;

    ptr += 2;
    sz   = ajustShortValue(*( (USHORT *) ptr));
    ptr += 2;
    ptr += sz;
    sz   = tlv->sz - (sz+4);

    ptr += 2;
    sz  -= 2;

    DBGTrace(sz);

    msgSize = ajustShortValue(*( (USHORT *) ptr)) - 4;
    ptr    += 6;
    sz     -= 6;

    DBGTrace(msgSize);
    DBGTrace(sz);

    if(msgSize > sz)
    {
       sprintf(logLine,"Text (%d) is larger than packet (%d)",msgSize,sz);
#ifdef EXTENDED_LOG
       icqDumpPacket(icq, NULL, logLine, sz, (unsigned char *) ptr);
#else
       icqWriteSysLog(icq,PROJECT,logLine);
#endif

       return TRUE;
    }

    icqInsertMessage(icq, uin, 0, MSG_NORMAL, 0, 0, msgSize, ptr);

    return FALSE;
 }

 static BOOL url(HICQ icq, ULONG uin, TLV *tlv)
 {
/*
   UIN    sender's uin
   BYTE   msg-type
   BYTE   msg-flags
   LNTS   msg
   if text-msg
     COLOR   foreground
     COLOR   background
   if contacts-req
     2 BYTE    39 00, it seems to be the number of the following bytes
     18 BYTE   unk, 2A 0E 7D 46 76 76 D4 11 BC E6 00 04 AC 96 1E A6 02 00
     DLS       Request For Contacts
     15 BYTE   00 00 00 00 00 01 00 00 00 00 00 00 00 00 00
     2 BYTE    11 00, it seems to be the number of the following bytes
     2 BYTE    0
     DTS       request message
*/

    char  *ptr           = tlv->string;
    int   sz             = tlv->sz;
    char  subType;
    UCHAR flags;
    int   msgSize;

    if(tlv->id != 0x05)
       return TRUE;

    ptr      += 4;
    subType   = *(ptr++);
    flags     = *(ptr++);
    sz       -= 6;

    msgSize   = *( (USHORT *) ptr );

    ptr      += 2;
    sz       -= 2;

#ifdef EXTENDED_LOG
    switch(flags)
    {
    case 0x00:  // = normal
       icqWriteSysLog(icq,PROJECT,"Message Flag: Normal");
       break;

    case 0x80:  // = multiple
       icqWriteSysLog(icq,PROJECT,"Message Flag: Multiple");
       break;

    case 0x03:  //  = special (used for auto-msg-req)
       icqWriteSysLog(icq,PROJECT,"Message Flag: Special");
       break;

    default:
       icqWriteSysLog(icq,PROJECT,"Message Flag: Unknown");
    }
#endif

    DBGTrace(sz);
    DBGTrace(msgSize);

    if(msgSize > sz)
    {
       icqWriteSysLog(icq,PROJECT,"Unexpected message size");
       return TRUE;
    }

//    icqWriteSysLog(icq,PROJECT,ptr);

    icqInsertMessage(icq, uin, 0, subType, 0, 0, msgSize, ptr);

    return FALSE;
 }

 static BOOL advanced(HICQ icq, ULONG uin, TLV *msg, ULONG id1, ULONG id2, USHORT type)
 {
    TLV         tlv;
    char        *ptr;
    int         sz;
//  HUSER       usr     = icqQueryUserHandle(icq, uin);

    DBGMessage("Advanced message");
    DBGTrace(msg->id);

    if(msg->id != 0x05)
       return TRUE;

    DBGTracex(msg->sz);


//     WORD       ??A, 00 02 for file-ack, else 00 00
//     8 BYTE     same as ??B
//     16 BYTE    capability1

    sz  = msg->sz;
    ptr = extractTLV(msg->string+26, &tlv, &sz);
    while(tlv.id && sz > 0)
    {
       DBGTracex(tlv.id);
       DBGTrace(tlv.sz);

       switch(tlv.id)
       {
       case 0x000A:     // TLV(A)     00 02 on file-reply, 00 01 else
          break;

/*

       case 0x0005:     // TLV(5)     WORD, listening port (BE)  (present on FT)
          DBGTracex( * ((USHORT *) tlv.string) );
          break;

       case 0x0003:     // TLV(3)     IPADDR, internal ip  (present on FT and file-reply)
          DBGTracex( * ((ULONG *) tlv.string) );
          break;

*/
       case 0x0003:     // TLV(3)     IPADDR, internal ip  (present on FT and file-reply)
          if(tlv.sz == 4)
             setUserLocalIP(icq,uin, *((long *) tlv.string) );
#ifdef EXTENDED_LOG
          else
             dumpTLV(icq,"Unexpected size in TLV 0x%04lx received in advanced message from ICQ#%lu",uin,&tlv);
#endif
          break;

       case 0x000F:     // TLV(F)     empty
          break;

       case 0x2711:
#ifdef LOG2711
          dumpTLV(icq,"TLV %08x received in advanced message from ICQ#%lu",uin,&tlv);
#endif
          if(procExtendedMsg(icq,uin,tlv.sz,(struct extendedHeader *) tlv.string))
             sendConfirmation(icq,uin,tlv.string,id1,id2,type);
#ifdef LOGUSER
          else if(uin == LOGUSER)
             icqWriteSysLog(icq,PROJECT,"Message was *NOT* confirmed");
#endif
          break;

       default:
          dumpTLV(icq,"Unexpected TLV 0x%04lx received in advanced message from ICQ#%lu",uin,&tlv);
       }

       ptr = extractTLV(ptr, &tlv, &sz);
    }

    DBGTrace(tlv.id);
    DBGTrace(sz);

    return FALSE;

 }

 static void dumpTLV(HICQ icq, const char *text, ULONG uin, TLV *tlv)
 {
    char linha[132];
    sprintf(linha,text,tlv->id,uin);
#ifdef EXTENDED_LOG
    icqDumpPacket(icq, icqQueryUserHandle(icq, uin), linha, tlv->sz, tlv->string);
#else
    icqWriteSysLog(icq,PROJECT,linha);
#endif
 }

 static BOOL procExtendedMsg(HICQ icq,ULONG uin, USHORT sz, struct extendedHeader *h)
 {
#ifdef EXTENDED_LOG
    char linha[132];
#endif
/*
    USHORT      X1;             //      WORD      1B 00
    UCHAR       X2;             //      BYTE      ??E   (08 in auto-msg-req, else 07)
    UCHAR       X3[19];         //      19 BYTE   unk, 0
    UCHAR       X4[3];          //      3 BYTE    unk, 03 00 00
    UCHAR       X5;             //      if auto-msg-req BYTE    00
    UCHAR       X6;             //      BYTE      unk, 00 or 04 (00 in auto-msg-req)
    USHORT      seq;            //      WORD      ??D, seems to be a downcounter starting from FFFF
    USHORT      X7;             //      2 BYTE    0E 00
    USHORT      seq2;           //      WORD      same as ??D
    UCHAR       X8[12];         //      12 BYTE   0
    UCHAR       subtype;        //      BYTE      msg-subtype
    UCHAR       flags;          //      BYTE      msg-flags
    USHORT      status;         //      WORD      first word of my status-code (but LE)
    USHORT      priority;       //      WORD      priority
    USHORT      txtSize;        //      LNTS      msg
*/

#ifdef EXTENDED_LOG
    sprintf(linha,"ICQ#%lu Status:%04x Subtype:%04x Size:%04x Flags:%02x",uin,h->status,h->subType,h->msgSize,h->flags);
    icqWriteSysLog(icq,PROJECT,linha);
/*
    switch(h->flags)
    {
    case 0x00:  // = normal
       icqWriteSysLog(icq,PROJECT,"Message Flag: Normal");
       break;

    case 0x80:  // = multiple
       icqWriteSysLog(icq,PROJECT,"Message Flag: Multiple");
       break;

    case 0x03:  //  = special (used for auto-msg-req)
       icqWriteSysLog(icq,PROJECT,"Message Flag: Special");
       break;

    default:
       icqWriteSysLog(icq,PROJECT,"Message Flag: Unknown");
    }
*/
#endif

    DBGTracex(h->status);
    DBGTracex(h->subType);

    if(h->msgSize > 1)
       return icqInsertMessage(icq, uin, 0, h->subType, 0, 0, h->msgSize, (char *) (h+1));

#ifdef LOGUSER
    if(uin == LOGUSER)
       return TRUE;
#endif

    return FALSE;
 }

 struct tbl
 {
    USHORT      mode;
    UCHAR       acceptStatus;
 };

 static void sendConfirmation(HICQ icq, ULONG uin, const char *msg, ULONG id1, ULONG id2, USHORT type)
 {
    static const struct tbl     status[] = {    { ICQ_AWAY,       0x04 },
                                                { ICQ_NA,         0x0E },

                                                { 0x00,           0x00 }
                                           };

    FLAP                        flap;
    SNAC                        snac;

    struct msgAckPrefix         p;
    struct msgAckMid            m;
    char                        bUIN[20];
    int                         f;
    char                        *ackMsg = "";
    ULONG                       temp;

    sprintf(bUIN,"%lu",uin);    // icqQueryUIN(icq));

#ifdef EXTENDED_LOG
    icqWriteSysLog(icq,PROJECT,"Sending message confirmation");
#endif

    memset(&flap,0,sizeof(FLAP));
    memset(&snac,0,sizeof(SNAC));
    memset(&p,0,sizeof(p));
    memset(&p,0,sizeof(m));

    p.id    = id1;
    p.id2   = id2;
    p.type  = type;
    p.sz    = strlen(bUIN);

    m.x1    = 0x0300;

    for(f=0;f<26;f++)
       m.ack1[f] = msg[f];

    for(f=0;f<20;f++)
       m.ack2[f] = msg[27+f];

    temp = icqQueryOnlineMode(icq) & 0xFFFF;
    for(f=0;status[f].mode && status[f].mode != temp;f++);
    m.acceptStatus = status[f].acceptStatus;

    m.sz = strlen(ackMsg)+1;

    flap.cmdStart       = 0x2a;
    flap.channel        = CHANNEL_SNAC;

    flap.size           = ajustShortValue(      sizeof(SNAC)
                                                +sizeof(p)
                                                +p.sz
                                                +sizeof(m)
                                                +m.sz
                                                +8
                                                );
    snac.family         = 0x0400;
    snac.subType        = 0x0B00;
    snac.flags[0]       =
    snac.flags[1]       = 0;
    snac.request        = 0x04000000;

    if(!beginSend(icq))
       return;

    packetSeq++;

    flap.sequence = ajustShortValue(packetSeq);

    icqSend(sock, &flap,   sizeof(FLAP));
    icqSend(sock, &snac,   sizeof(SNAC));

    icqSend(sock, &p,      sizeof(p));
    icqSend(sock, bUIN,    p.sz);

    icqSend(sock, &m,      sizeof(m));
    icqSend(sock, ackMsg,  m.sz);

    temp = 0;
    icqSend(sock, &temp,   sizeof(temp));

    temp = 0xFFFFFFFF;
    icqSend(sock, &temp,   sizeof(temp));

    finishSend(icq);

#ifdef LOGUSER
    if(uin == LOGUSER)
       icqWriteSysLog(icq,PROJECT,"Message was confirmed");
#endif

 }

 static void setUserLocalIP(HICQ icq, ULONG uin, long addr)
 {
#ifdef EXTENDED_LOG
    char buffer[0x0100];
    sprintf(buffer,"ICQ#%lu seens to be in IP ",uin);
    strncat(buffer,icqFormatIP(addr),0xFF);
    icqWriteSysLog(icq,PROJECT,buffer);
#endif
 }


