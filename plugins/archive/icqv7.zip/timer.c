/*
 * Controle de temporizacao
 */

 #include <pwMacros.h>

 #include <string.h>

 #include "icqv7.h"

/*---[ Statics ]----------------------------------------------------------*/

 ULONG  mainTimer       = 0;

/*---[ Implementacao ]----------------------------------------------------*/

 void EXPENTRY icqv7_Timer(HICQ icq, void *lixo)
 {
    REQUEST *req;

    mainTimer++;

    if(reqList)
    {
       for(req = icqQueryFirstElement(reqList);req;req=icqQueryNextElement(reqList,req))
       {
          req->timer++;
       }
    }

 }


