/*
 * lnxconfig.c - Configuracao ICQV7 - Linux
 */

 #include <stdio.h>
 #include <icqtlkt.h>

/*---[ Constants ]---------------------------------------------------------------------------*/
 
 /*
      0       1       2                                         3
  0_  |       |       |                                         |
      Server: ---------------------------------------------------
  1_  Reconnect: xxxx (Select 0 to disable)
  2_          Hide Window when offline
  3_
  
  */

 static const TABLEDEF srv_table[] = { { 0,   0, 0, 1, 1, ICQTABLE_BEGIN,       0,    0, "Login"                    },
                                       { 0,   0, 0, 1, 1, ICQTABLE_LABEL,       0,    0, "Server:"                  },
 							          { 101, 0, 1, 1, 3, ICQTABLE_ENTRY,       0,    0, NULL                       },
 							          { 0,   1, 0, 2, 1, ICQTABLE_LABEL,	   0,      0, "Reconnect:"               },
 							          { 105, 1, 1, 2, 2, ICQTABLE_SPIN,        0, 3600, "(Select 0 to disable)"    },
 							          { 0,   0, 0, 0, 0, ICQTABLE_END,         0,    0, NULL                       },
 							          { 0,   1, 0, 2, 1, ICQTABLE_BEGIN,       0,    0, "Options"                  },
 							          { 106, 0, 0, 1, 1, ICQTABLE_CHECKBOX,    0,    0, "Hide Window when offline" },
 							          { 0,   0, 0, 0, 0, ICQTABLE_END,         0,    0, NULL                       },
 								      { 0,   0, 0, 0, 0, 0,                    0,    0, NULL                       } 
 								   };

 static const TABLEDEF opt_table[] = { { 0,   0, 0, 1, 1, ICQTABLE_BEGIN,       0, 0, "Server options"                        },
                                       { 101, 0, 0, 1, 1, ICQTABLE_CHECKBOX,    0, 0, "Direct connection only for know users" },
                                       { 102, 1, 0, 2, 1, ICQTABLE_CHECKBOX,    0, 0, "Direct connection by request"          },
                                       { 103, 2, 0, 3, 1, ICQTABLE_CHECKBOX,    0, 0, "Enable web indicator"                  },
 							          { 0,   0, 0, 0, 0, ICQTABLE_END,         0, 0, NULL                                    },

                                       { 0,   1, 0, 2, 1, ICQTABLE_BEGIN,       0, 0, "When unknown user update fails"        },
                                       { 105, 0, 0, 1, 1, ICQTABLE_RADIOBUTTON, 1, 0, "Keep user" },
                                       { 106, 1, 0, 2, 1, ICQTABLE_RADIOBUTTON, 0, 0, "Remove user only if no pending messaged" },
                                       { 107, 2, 0, 3, 1, ICQTABLE_RADIOBUTTON, 0, 0, "Remove messages and user" },
                                       { 108, 3, 0, 4, 1, ICQTABLE_CHECKBOX,    0, 0, "Send auto-reply if removed" },

                                       {   0, 4,0,  5,1,  ICQTABLE_BEGIN,       0,0, "Auto-reply text"             },
                                       { 109, 0,0,  1,1,  ICQTABLE_MLE,         0,0, NULL                        },
                                       {   0, 0,0,  0,0,  ICQTABLE_END,         0,0, NULL                        },

 							          { 0,   0, 0, 0, 0, ICQTABLE_END,         0, 0, NULL                                    },
                                        							          
 								      { 0,   0, 0, 0, 0, 0,                    0, 0, NULL                                    } 
 								   };


 static int _System srv_load(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System srv_save(const DLGHELPER *,HWND,HICQ,ULONG,char *);

 static const DLGMGR   srv_mgr  = { sizeof(DLGMGR),
 								   NULL,			// Configure
 								   srv_load,		// load
 								   srv_save,		// save
 								   NULL,			// cancel
 								   NULL,			// event
 								   NULL,			// selected
 								   NULL,			// click
 								   NULL			 // changed
 								 };

 static int _System opt_load(const DLGHELPER *,HWND,HICQ,ULONG,char *);
 static int _System opt_save(const DLGHELPER *,HWND,HICQ,ULONG,char *);

 static const DLGMGR   opt_mgr  = { sizeof(DLGMGR),
 								   NULL,			// Configure
 								   opt_load,		// load
 								   opt_save,		// save
 								   NULL,			// cancel
 								   NULL,			// event
 								   NULL,			// selected
 								   NULL,			// click
 								   NULL			 // changed
 								 };

/*---[ Prototipos ]--------------------------------------------------------------------------*/


/*---[ Implementacao ]-----------------------------------------------------------------------*/

 void EXPENTRY icqv7_ConfigPage(HICQ icq, void *dBlock, ULONG uin, USHORT type, HWND hwnd,  const DLGINSERT *dlg, char *buffer)
 {
    if(type != 1)
       return;
 
    DBGMessage("Anexar paginas de configuracao da interface grafica");
 
    dlg->insertTable(hwnd, CFGWIN_NETWORK,  srv_table, &srv_mgr, "Server\nICQV7 server configuration");
    dlg->insertTable(hwnd, CFGWIN_SECURITY, opt_table, &opt_mgr, "Server\nICQV7 security configuration");

 }

 static int _System srv_load(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    CHKPoint();
    
    dlg->loadString(hwnd,0,101,"loginServer",0xFF,"login.icq.com");
    dlg->loadCheckBox(hwnd,0,106,"hideWhenOffline",FALSE);
    
    dlg->setSpinButton(hwnd,105,icqLoadValue(icq,"reconnect",0));
    
    return 0;
 }
 
 static int _System srv_save(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    CHKPoint();
    
    dlg->saveString(hwnd,0,101,"loginServer",0xFF);
    dlg->saveCheckBox(hwnd,0,106,"hideWhenOffline");

    icqSaveValue(icq,"reconnect",dlg->getSpinButton(hwnd,105));

    return 0;
 }
 
 static int _System opt_load(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    if(dlg->sz != sizeof(DLGHELPER))
       return -1;

    dlg->loadCheckBox(hwnd,0,101,"ip:contact", TRUE);
    dlg->loadCheckBox(hwnd,0,102,"ip:request", TRUE);
    dlg->loadCheckBox(hwnd,0,103,"webAware",   FALSE);
       
    dlg->setRadioButton(hwnd,105,icqLoadValue(icq,"ifUpdateFails",0));
    dlg->loadCheckBox(hwnd,0,108,"notifyIfRemoved",  FALSE);
    dlg->loadString(hwnd,0,109,"AutoRemoveMsg",0x0FF,"");
    
    return 0;
 }

 static int _System opt_save(const DLGHELPER *dlg, HWND hwnd, HICQ icq, ULONG uin, char *buffer)
 {
    dlg->saveCheckBox(hwnd,0,101,"ip:contact");
    dlg->saveCheckBox(hwnd,0,102,"ip:request");
    dlg->saveCheckBox(hwnd,0,103,"webAware");

    icqSaveValue(icq,"ifUpdateFails",dlg->getRadioButton(hwnd,105,3));
    dlg->saveCheckBox(hwnd,0,108,"notifyIfRemoved");
    dlg->saveString(hwnd,0,109,"AutoRemoveMsg",0xFF);

    return 0;
 }
