/*
 * REQUEST.C - Gerenciamento da lista de requisicoes pendentes
 */

 #include <pwMacros.h>

 #include "icqv7.h"

/*---[ Definicoes ]-----------------------------------------------------------------------------------------*/

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 REQUEST * createRequest(HICQ icq, ULONG uin, int sz)
 {
    REQUEST *ret;

    if(!reqList)
       return NULL;

    ret = icqAddElement(reqList,sizeof(REQUEST)+sz);

    if(ret)
    {
       beginSend(icq);
       ret->id  = atualReq++;
       ret->uin = uin;
       finishSend(icq);
    }

    DBGTracex(ret->id);

    return ret;
 }

 void deleteRequest(HICQ icq, REQUEST *req)
 {
    if(!(reqList && req))
       return;
    icqRemoveElement(reqList, req);
 }

 REQUEST * searchRequest(HICQ icq, USHORT id)
 {
    REQUEST *ret;


    if(!reqList)
       return NULL;

    for(ret = icqQueryFirstElement(reqList);ret;ret=icqQueryNextElement(reqList,ret))
    {
       if(ret->id == id)
          return ret;
    }
    return NULL;
 }

 #pragma pack(1)
 struct userReqPkt
 {
    USHORT      type;
    ULONG       uin;
 };

 HSEARCH _System requestUserInfo(HICQ icq, ULONG uin, int searchs)
 {
    REQUEST             *req = createRequest(icq,uin,sizeof(ULONG));
    struct userReqPkt   pkt;

    DBGTrace(searchs);

    if(!req)
       return 0;

    *( (ULONG *) (req+1)) = uin;

/*
     subtype=B204       // query info about user
       UIN   user to request info
     subtype=D004       // query my info
       UIN   my uin
*/
//    pkt.type = (uin == icqQueryUIN(icq)) ? 0x04D0 : 0x04B2;

    pkt.type = 0x051F;
    pkt.uin  = uin;

    sendMultiPurpose(icq, 0x07D0, req->id, 0x02000100, sizeof(pkt), &pkt);

    icqSystemEvent(icq,ICQEVENT_BEGINSEARCH);

    return 0;
 }


