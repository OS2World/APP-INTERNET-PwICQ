/*
 * SNAC.C - Processa um pacote SNAC
 */

 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <time.h>
 #include <pwMacros.h>
 #include "icqv7.h"

/*---[ Formatos de pacote ]---------------------------------------------------------------------------------*/

 #pragma pack(1)
 struct msgConf
 {
    ULONG       id;
    ULONG       x1;
    USHORT      type;
    UCHAR       sz;
 };

/*---[ Prototipos das funcoes de servico ]------------------------------------------------------------------*/

 static void _System serverIsReady(HICQ, int, ULONG, void *, UCHAR *);
 static void _System doNothing(HICQ, int, ULONG, void *, UCHAR *);
 static void _System rateInformation(HICQ, int, ULONG, void *, UCHAR *);
 static void _System confirmStatus(HICQ, int, ULONG, void *, UCHAR *);
 static void _System userOnline(HICQ, int, ULONG, char *, UCHAR *);
 static void _System userOffline(HICQ, int, ULONG, char *, UCHAR *);
 static void _System multiPurpose(HICQ, int, ULONG, char *, UCHAR *);
 static void _System userRejected(HICQ, int, ULONG, char *, UCHAR *);
 static void _System msgConfirmed(HICQ, int, ULONG, struct msgConf *, UCHAR *);
 static void _System msgDelivered(HICQ, int, ULONG, struct msgAckPrefix *, UCHAR *);

/*---[ Tabela de comandos ]---------------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct snaccmd
 {
    USHORT family;
    USHORT subType;
    void ( * _System exec)(HICQ,int,ULONG,void *,UCHAR *);
 } CMD;

 #define FPREFIX (void (* _System)(HICQ, int, ULONG, void *, UCHAR *))

 static const CMD cmd[] =
 {
        { 0x01,   0x03,   FPREFIX serverIsReady },
        { 0x01,   0x13,   FPREFIX doNothing },
        { 0x01,   0x18,   FPREFIX doNothing },
        { 0x01,   0x07,   FPREFIX rateInformation },
        { 0x01,   0x0F,   FPREFIX confirmStatus },

        { 0x02,   0x03,   FPREFIX doNothing },

        { 0x03,   0x03,   FPREFIX doNothing },
        { 0x03,   0x0A,   FPREFIX userRejected },
        { 0x03,   0x0B,   FPREFIX userOnline },
        { 0x03,   0x0C,   FPREFIX userOffline },

        { 0x04,   0x05,   FPREFIX doNothing },
        { 0x04,   0x07,   FPREFIX procMessage },
        { 0x04,   0x0B,   FPREFIX msgDelivered },
        { 0x04,   0x0C,   FPREFIX msgConfirmed },

        { 0x09,   0x03,   FPREFIX doNothing },

        { 0x15,   0x03,   FPREFIX multiPurpose },

        { 0x00,   0x00,   NULL }
 };

/* SNACs de erro:

   0001/0001: Generic Service Controls Error
   0002/0001: Location/User Information Services Error
   0003/0001: Buddy List Service Error
   0004/0001: Messaging Service Error
   0005/0001: Advertisements Service Error
   0007/0001: Administrative/Account/Userinfo change Error
   0008/0001: Display Popup Service Error
   0009/0001: BOS-specific Error
   0009/0009: Server BOS Error
   000A/0001: User Lookup/Search Service Error
   000B/0001: Statistics/Reports Service Error
   000C/0001: Translate Service Error
   000D/0001: Chatrooms Navigation Error
   000E/0001: Chatrooms Service Error
   000E/0009: Chat/Client Error

*/

/*---[ Implementacao ]--------------------------------------------------------------------------------------*/

 static void writeDump(HICQ icq, int sz, SNAC *pkt)
 {
    char log[80];
    DBGTracex(pkt->family);
    DBGTracex(pkt->subType);
    sprintf(log,"Unknown SNAC packet (Family %04x Type: %04x)",pkt->family,pkt->subType);
    icqDumpPacket(icq, NULL, log, sz, (unsigned char *) pkt);
 }

 void processSnac(HICQ icq, int sz, SNAC *pkt)
 {
//#ifdef EXTENDED_LOG
//    char log[80];
//#endif
    const CMD   *ptr = cmd;

//    if(pkt->family != 0x03)
//       icqSetServerBusy(icq,TRUE);

    pkt->family  = ajustShortValue(pkt->family);
    pkt->subType = ajustShortValue(pkt->subType);

/*
    if(pkt->family == 0x04 && pkt->subType == 0x07)
       writeDump(icq,sz,pkt);
*/

    while(ptr->exec)
    {
       if(ptr->family == pkt->family && ptr->subType == pkt->subType)
       {
//#ifdef EXTENDED_LOG
//          sprintf(log,"SNAC %02x,%02x",pkt->family,pkt->subType);
//          icqWriteSysLog(icq,PROJECT,log);
//#endif
          ptr->exec(icq, sz-sizeof(SNAC), pkt->request, (void *) (pkt+1), (UCHAR *) pkt);
          return;
       }
       ptr++;
    }

/*
    if(icqPacket(icq, 7, pkt, sz, 0, 0))
      return;
*/
    writeDump(icq,sz,pkt);

 }

 static void _System serverIsReady(HICQ icq, int sz, ULONG req, void *pkt, UCHAR *buffer)
 {
    const UCHAR snd[] = { 0x00, 0x01, 0x00, 0x03, 0x00, 0x02, 0x00, 0x01,
                          0x00, 0x03, 0x00, 0x01, 0x00, 0x15, 0x00, 0x01,
                          0x00, 0x04, 0x00, 0x01, 0x00, 0x06, 0x00, 0x01,
                          0x00, 0x09, 0x00, 0x01, 0x00, 0x0A, 0x00, 0x01 };

    icqWriteSysLog(icq,PROJECT,"Server contacted");
    icqSystemEvent(icq,ICQEVENT_CONTACT);

/*
SNAC 1/17
SNAC 1/6
SNAC 1/E
SNAC 2/2
SNAC 3/2
SNAC 4/4
SNAC 9/2
*/

    sendSNAC(icq,0x01,0x17,0x17000000,32,snd);

    sendSNAC(icq,0x01,0x06,0x06000000,0,NULL);
    sendSNAC(icq,0x01,0x0E,0x0E000000,0,NULL);  // Requests personal information.
    sendSNAC(icq,0x02,0x02,0x02000000,0,NULL);  // Request rights information for location service
    sendSNAC(icq,0x03,0x02,0x02000000,0,NULL);  // Request rights information for buddy list
    sendSNAC(icq,0x04,0x04,0x04000000,0,NULL);  // Requests rights for ICBM (Instant Message) operations.
    sendSNAC(icq,0x09,0x02,0x02000000,0,NULL);  // Requests BOS rights
 }

 static void _System rateInformation(HICQ icq, int sz, ULONG req, void *pkt, UCHAR *buffer)
 {
    icqCreateThread(icq, &executeLogon, 8192, BUFFERSIZE, NULL, "lgn");
 }

 static void _System doNothing(HICQ icq, int sz, ULONG req, void *pkt, UCHAR *buffer)
 {

 }

 static void _System confirmStatus(HICQ icq, int sz, ULONG req, void *pkt, UCHAR *buffer)
 {
    char *ptr   = (char *) pkt;
    int  bytes;
    TLV  tlv;
/*
server sends                   //  response to 1,0E
 SNAC 1,0F
 B-UIN   my uin
 WORD    warning level
 WORD    user class?
 TLV(1)  class2, usually 0000 or 0050
 TLV(C)  direct-connection-info, usually 0s
 TLV(A)  my ip address
 TLV(4)  idle time, usually 0000
 TLV(6)  status code
 TLV(F)  unknown, it seems to be an incrementing value usually 0000 xxxx (session length?)
 TLV(2)  date: member since
 TLV(3)  date: online since
*/
    DBGMessage("Mudan�a de status confirmada");

    bytes = *(ptr++);
    sz--;

    ptr   += bytes;
    sz    -= bytes;

    ptr   += 4;
    sz    -= 4;

    ptr = extractTLV(ptr, &tlv, &sz);
    while(sz > 0)
    {
       switch(tlv.id)
       {
       case 0x01: // class2, usually 0000 or 0050
          break;

       case 0x0C: //  direct-connection-info, usually 0s
          break;

       case 0x0A: //  my ip address
          icqSetLocalIP(icq,*((long *) tlv.string));
          DBGMessage(icqFormatIP(*((long *) tlv.string)) );
          break;

       case 0x04: //  idle time, usually 0000
          break;

       case 0x06: //  status code
          break;

       case 0x0F: //  unknown, it seems to be an incrementing value usually 0000 xxxx (session length?)
          break;

       case 0x02: // TLV(2)  TIME_T   member since
          icqSaveValue(icq, "V7.memberSince", ajustLongValue( * ((ULONG *) tlv.string)) );
          break;

       case 0x03: // TLV(3)  TIME_T   online since
          icqSaveValue(icq, "V7.onlineSince", ajustLongValue( * ((ULONG *) tlv.string)) );
          break;

       }
       ptr = extractTLV(ptr, &tlv, &sz);
    }

 }

 char *copyBuffer(int sz,char *dst, char *src)
 {
    while(sz--)
       *(dst++) = *(src++);
    return src;
 }

 static void _System userOffline(HICQ icq, int sz, ULONG req, char *pkt, UCHAR *buffer)
 {
    char        temp[80];
 /*
 server sends                      // OFFgoing user
 SNAC 3,0C
 B-UIN
 DWORD   unknown, usually 00000001
 TLV(1)  unknown, usually 0000
 */

    strncpy(temp,pkt+1,*pkt);
    *(temp + *pkt) = 0;

    icqSetUserOnlineMode(icq, atol(temp), ICQ_OFFLINE);

 }
 static void _System userOnline(HICQ icq, int sz, ULONG req, char *pkt, UCHAR *buffer)
 {
    char        temp[0x0100];
    ULONG       uin;
    HUSER       usr;
    TLV         tlv;
    long        ip              = 0;
    long        memberSince     = 0;
    long        onlineSince     = 0;
    ULONG       status          = 0;
    DIRECTINFO  info;

    strncpy(temp,pkt+1,*pkt);
    *(temp + *pkt) = 0;

    uin = atol(temp);

    if(!uin)
    {
       icqDumpPacket(icq, NULL, "Unexpected UIN number received", sz, (unsigned char *) pkt);
       return;
    }

    memset(&info,0,sizeof(DIRECTINFO));

    sz  -= *pkt;
    pkt += *pkt;
    pkt += 5;
    sz  -= 5;

    pkt = extractTLV(pkt, &tlv, &sz);
    while(sz > 0)
    {
       switch(tlv.id)
       {
       case 0x01: // TLV(1)  class2, usually 0050
          break;

       case 0x0c: // TLV(C)  direct-connection-info
          if(tlv.sz != sizeof(DIRECTINFO))
             icqDumpPacket(icq, NULL, "Unexpected direct information received", tlv.sz, tlv.string);
          else
             copyBuffer(tlv.sz,(char *) &info, tlv.string);
          break;

       case 0x0a: // TLV(A)  ip address
          if(!ip)
             ip = *((long *) tlv.string);
          break;

       case 0x04: // TLV(4)  unknown, usually 0000
          break;

       case 0x06: // TLV(6)  status
          status = ajustLongValue(*( (ULONG *) tlv.string));
          break;

       case 0x0d: // TLV(D)  capability-info
          break;

       case 0x0f: // TLV(F)  unknown
          break;

       case 0x02: // TLV(2)  TIME_T   member since
          memberSince = ajustLongValue( * ((ULONG *) tlv.string) );
          break;

       case 0x03: // TLV(3)  TIME_T   online since
          onlineSince = ajustLongValue( * ((ULONG *) tlv.string) );
          break;

       }

       pkt = extractTLV(pkt, &tlv, &sz);
    }

    usr = icqUserOnline(        icq,
                                uin,
                                status,
                                info.ipaddr,
                                ip,
                                info.port,
                                0,
                                info.Build );

    if(usr)
    {
       if(memberSince)
          usr->memberSince = memberSince;
       if(onlineSince)
          usr->onlineSince = onlineSince;
       else
          usr->onlineSince = time(NULL);
    }


 }

 static void _System multiPurpose(HICQ icq, int szPacket, ULONG req, char *packet, UCHAR *buffer)
 {
    TLV         tlv;
    char        *pkt    = packet;
    int         sz      = szPacket;

    DBGTrace(sz);
    pkt = extractTLV(pkt, &tlv, &sz);
    while(tlv.id)
    {
       if(tlv.id == 1)
       {
          processGenericPacket(icq,tlv.sz,tlv.string);
       }
       else if(tlv.sz == 0)
       {
          icqDumpPacket(icq, NULL, "Invalid TLV received in multi-purpose packet", szPacket, (unsigned char *) packet);
          sz = 0;
          icqAbend(icq,0);
       }
       else
       {
          icqDumpPacket(icq, NULL, "Unexpected TLV received in multi-purpose packet", szPacket, (unsigned char *) packet);
       }
       pkt = extractTLV(pkt, &tlv, &sz);
    }

 }

 static void _System userRejected(HICQ icq, int sz, ULONG req, char *packet, UCHAR *buffer)
 {
    HUSER usr   = icqQueryUserHandle(icq, atol(packet+1));
/*
   03 00 0a 00 00 00 88 57 8a 60 09 31 33 36 39 31   ......�W�`.13691
   36 35 31 31                                       6511

   03 00
   0a 00
   00 00
   88 57 8a 60

   09
   31 33 36 39 31
   36 35 31 31

*/
   DBGMessage(packet+1);
   if(!usr)
   {
      icqWriteSysLog(icq,PROJECT,"Unexpected user-reject packet received");
      return;
   }

   icqUserEvent(icq, usr, ICQEVENT_REJECTED);

   sprintf(buffer,"User %s (ICQ#%ld) rejected by server",icqQueryUserNick(usr),usr->uin);
   icqWriteSysLog(icq,PROJECT,buffer);

 }

 static void _System msgConfirmed(HICQ icq, int sz, ULONG req, struct msgConf *msg, UCHAR *buffer)
 {
    ULONG       id      = ajustLongValue(msg->id);
    ULONG       uin;
    UCHAR       *ptr    = (UCHAR *)(msg+1);
    char        log[0x0100];

    if(msg->sz > 0x0F)
    {
       icqWriteSysLog(icq,PROJECT,"Unexpected text size in message confirmation");
       return;
    }

    *(ptr+(msg->sz)) = 0;

    uin              = atol(ptr);

    sprintf(log,"Message #%lu to ICQ#%lu confirmed by server",id,uin);

#ifdef EXTENDED_LOG
    icqDumpPacket(icq, icqQueryUserHandle(icq, uin), log, sz, (UCHAR *) msg);
#else
    icqWriteSysLog(icq,PROJECT,log);
#endif

    icqProcessServerConfirmation(icq, uin, id);
 }

 static void _System msgDelivered(HICQ icq, int sz, ULONG req, struct msgAckPrefix *hdr, UCHAR *buffer)
 {
    ULONG               id      = ajustLongValue( hdr->id );
    char                *ptr    = (char *) (hdr+1);
    struct msgAckMid    *mid    = (struct msgAckMid *) (ptr + hdr->sz);
    ULONG               uin;
    const char          *title  = "User is not available";
    char                work[0x0100];

    strncpy(work,ptr,hdr->sz);
    *(work + hdr->sz) = 0;
    uin = atol(work);

    sprintf(work,"Message #%lu to ICQ#%lu ",id,uin);

    switch(mid->acceptStatus)
    {
    case 0x00:  //  normally accepted   (use this replying to auto-msg-req)
       strncat(work,"accepted",0xFF);
       break;

    case 0x09:  //  not accepted, occupied
       strncat(work,"wasn't accepted by the user",0xFF);
       title = "User is occupied";
       break;

    case 0x0A:  //  not accepted, dnd
       strncat(work,"accepted in DND mode",0xFF);
       title = "User is in DND mode";
       break;

    case 0x04:  //  accepted but away
       strncat(work,"accepted in away mode",0xFF);
       title = "User is away";
       break;

    case 0x0E:  //  accepted but NA
       strncat(work,"accepted in N/A mode",0xFF);
       break;

    case 0x0C:  //  accepted to contact list (no blink in tray)
       strncat(work,"was accepted to contact-list",0xFF);
       break;

    default:
       sprintf(work,"seens to be accepted by the user (Accept code 0x%02x)",mid->acceptStatus);
    }

#ifdef EXTENDED_LOG
    icqDumpPacket(icq, icqQueryUserHandle(icq, uin), work, sz, (UCHAR *) hdr);
#else
    icqWriteSysLog(icq,PROJECT,work);
#endif

    if(mid->sz > 1)
       icqInsertAwayMessage(icq, uin, title, (UCHAR *) (mid+1));

    icqProcessServerConfirmation(icq, uin, id);

 }


