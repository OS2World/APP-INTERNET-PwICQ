/*
 * MAIN.C - Ponto de entrada para o gerenciador de protocolo versao 7
 */

#ifdef __OS2__
 #define INCL_DOSSEMAPHORES
 #define INCL_DOSPROCESS
#endif

 #include <stdio.h>
 #include <time.h>
 #include <stdlib.h>
 #include <string.h>
 #include <pwMacros.h>

#ifdef linux
 #include <unistd.h>
#endif

 #include "icqv7.h"

/*---[ Statics ]-----------------------------------------------------------------------------*/

 static ICQMODETABLE mTable[] = {       { ICQ_ONLINE,              5,      "Online" },
                                        { ICQ_AWAY,                6,      "Away" },
                                        { ICQ_NA,                 40,      "N/A" },
                                        { ICQ_OCCUPIED,           12,      "Busy" },
                                        { ICQ_DND,                42,      "DND" },
                                        { ICQ_FREEFORCHAT,        13,      "Free for chat" },
                                        { ICQ_OFFLINE,             7,      "Offline" },

                                        { 0,                       0,      NULL }
                             };

//                                        ICQ_INVISIBLE,          14,      "Invisible",

/*

      ULONG             (* _System setMode)(HICQ,ULONG,ULONG);
      int               (* _System sendCmd)(HICQ, unsigned short, void *, int);
      HSEARCH           (* _System requestUserUpdate)(HICQ, ULONG, int);
      int               (* _System requestUserInfo)(HICQ, ULONG, int);
      USHORT            (* _System sendMessage)(HICQ, ULONG, USHORT, const char *, ULONG *);
      int               (* _System sendConfirmation)(HICQ, ULONG, USHORT, BOOL, char *);
      int               (* _System addUser)(HICQ, HUSER);
      int               (* _System delUser)(HICQ, HUSER);
      USHORT            (* _System queryModeIcon)(HICQ, ULONG);
      int               (* _System setPassword)(HICQ,const char *, const char *);
      int               (* _System isOnline)(HICQ);
      int               (* _System searchByICQ)(HICQ, ULONG, HWND, SEARCHCALLBACK);
      int               (* _System searchByMail)(HICQ, const char *, HWND, SEARCHCALLBACK);
      int               (* _System searchRandom)(HICQ, USHORT, HWND, SEARCHCALLBACK);
      int               (* _System searchByInformation)(HICQ,HWND, const char *, const char *,const char *, const char *,BOOL, SEARCHCALLBACK );

*/

 static const C2SPROTMGR caps = {       sizeof(C2SPROTMGR),
                                        0x07,
                                        XBUILD,
#ifdef DEBUG
    "ICQ Version 7 protocol manager Build " BUILD " (Debug Version)",
#else
    "ICQ Version 7 protocol manager Build " BUILD,
#endif
                                        512,
                                        mTable,

                                        setMode,
                                        NULL,
                                        requestUserInfo,
                                        NULL,
                                        icqV7Message,
                                        icqV7Confirmation,
                                        NULL,
                                        NULL,
                                        queryModeIcon,
                                        NULL,
                                        NULL,
			   	    	                NULL,
					                    NULL,
					                    NULL,
					                    NULL
                                };

#ifdef linux
   pthread_mutex_t      sendFlag;
#endif

#ifdef __OS2__
  HMTX                  sendFlag;
#endif

  HMODULE               module          = NULLHANDLE;

/*---[ Implementacao ]-----------------------------------------------------------------------*/

 int EXPENTRY icqv7_Configure(HICQ icq, HMODULE mod)
 {
    char buffer[0x0100];

    strcpy(buffer,"Loading ");
    strncat(buffer,caps.descr,0xFF);
    icqWriteSysLog(icq,PROJECT,buffer);

#ifdef EXTENDED_LOG
    icqWriteSysLog(icq,PROJECT,"**** Extensive logging enabled ****");
#endif

    module = mod;

    srand(time(NULL));

    if(icqQueryUserDataBlockLength() != sizeof(ICQUSER))
    {
       icqWriteSysLog(icq,PROJECT,"Can't start protocol manager due to invalid pwICQ core version");
       return -1;
    }

    if(!icqRegisterServerProtocolManager(icq,&caps))
    {
       icqWriteSysLog(icq,PROJECT,"Can't register V7 protocol manager");
       return -2;
    }

    return 0;
 }

 int EXPENTRY icqv7_Start(HICQ icq, void *lixo, HWND hwnd)
 {
#ifdef __OS2__
   char temp[0x0100];
#endif

    icqWriteSysLog(icq,PROJECT,"Client<->Server V7 protocol manager starting");

#ifdef linux
    if(pthread_mutex_init(&sendFlag, 0))
    {
       icqWriteSysLog(icq,PROJECT,"Unable to initialize semaphore");
       icqAbend(icq,0);
    }
#endif

#ifdef __OS2__
    sprintf(temp,"\\SEM32\\PWICQ\\MTX\\V7PROTOCOL\\%ld",icqQueryUIN(icq));
    if(DosCreateMutexSem(temp,&sendFlag,0,FALSE))
    {
       icqWriteSysLog(icq,PROJECT,"Unable to create semaphore");
       icqAbend(icq,0);
    }
#endif

    return 0;
 }

 int EXPENTRY icqv7_Terminate(HICQ icq, void *lixo)
 {
    int f;

    icqSetOnlineMode(icq,ICQ_OFFLINE);

    DBGTrace(sock);

#ifdef __OS2__
    for(f=0;f<100 && sock > 0;f++)
       DosSleep(10);
    DosCloseMutexSem(sendFlag);
#endif

#ifdef linux
    for(f=0;f<100 && sock > 0;f++)
       usleep(1000);
#endif

    if(!icqDeRegisterServerProtocolManager(icq,&caps))
    {
       icqWriteSysLog(icq,PROJECT,"Unable to deregister protocol manager");
       return 0;
    }

    if(sock < 1)
       icqWriteSysLog(icq,PROJECT,"Client<->Server V7 protocol stopped normally");
    else
       icqWriteSysLog(icq,PROJECT,"Client<->Server V7 protocol stopped abnormally");

    return 0;
 }

 BOOL beginSend(HICQ icq)
 {
#ifdef linux
   pthread_mutex_lock(&sendFlag);
#endif

#ifdef __OS2__
   if(DosRequestMutexSem(sendFlag, 2000))
   {
      icqWriteSysLog(icq,PROJECT,"Unable to get semaphore");
      return FALSE;
   }
#endif
   return TRUE;
 }

 BOOL finishSend(HICQ icq)
 {
#ifdef linux
   pthread_mutex_unlock(&sendFlag);
#endif

#ifdef __OS2__
   DosReleaseMutexSem(sendFlag);
#endif

   return TRUE;
 }

 #pragma pack(1)
 struct userMode
 {
    USHORT      mode;
    USHORT      icon;
 };

 USHORT _System queryModeIcon(HICQ icq, ULONG mode)
 {
    const struct userMode        *ptr;
    const static struct userMode tbl[]          = {     { 0x0000,  5 },     // Online
                                                        { 0x0008, 41 },     // Aska.ru
                                                        { 0x0001,  6 },     // Away
                                                        { 0x0005, 40 },     // N/A
                                                        { 0x0004, 40 },     // NA99A
                                                        { 0x0010, 12 },     // Occupied (MAC)
                                                        { 0x0011, 12 },     // Occupied
                                                        { 0x0013, 42 },     // DND
                                                        { 0x0002, 42 },     // DND (LICQ)
                                                        { 0x0020, 13 },     // Free for chat
                                                        { 0x0100, 14 },     // Invisible
                                                        { 0xFFFF,  7 },     // Offline
                                                        { 0x0000,  0 }
                                                 };

    mode &= 0x0000FFFF;
    for(ptr = tbl; ptr->icon && ptr->mode != mode; ptr++);
    return ptr->icon ? ptr->icon : 5;
 }



