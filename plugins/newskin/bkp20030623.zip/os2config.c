/*
 * os2config.c - OS2 Configuration window Processing
 */

 #pragma strings(readonly)

 #define INCL_WIN
 #define INCL_GPI

 #include <string.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <malloc.h>
 #include <pwicqgui.h>

/*---[ Defines ]------------------------------------------------------------------------------------------*/

 #define CHILD_WINDOW(h,i) WinWindowFromID(h,DLG_ELEMENT_ID+i)

 #define MSGID_NAMEBOX    MSG_WINDOW_COMPONENTS

/*---[ Structures ]---------------------------------------------------------------------------------------*/


/*---[ Constants ]----------------------------------------------------------------------------------------*/

 const char *icqConfigWindowClass = "pwICQConfig";

 static const MSGCHILD childlist[] =
 {
    { "InfoBox",       MSGID_INFOBOX,     WC_STATIC,    "",          "8.Helv",      SS_GROUPBOX|DT_LEFT|DT_VCENTER                                          },
    { "Namebox",       MSGID_NAMEBOX,     WC_STATIC,    "",          "8.Helv",      SS_GROUPBOX|DT_LEFT|DT_VCENTER                                          },

    { "Static",        MSGID_NICK,        WC_STATIC,    "Nick:",     "8.Helv",      SS_TEXT|DT_LEFT|DT_VCENTER                                              },
    { "Field",         MSGID_NICKENTRY,   WC_STATIC,    "",          "8.Helv.Bold", SS_TEXT|DT_LEFT|DT_VCENTER                                              },
    { "Static",        MSGID_NAME,        WC_STATIC,    "Name:",     "8.Helv",      SS_TEXT|DT_LEFT|DT_VCENTER                                              },
    { "Field",         MSGID_NAMEENTRY,   WC_STATIC,    "",          "8.Helv.Bold", SS_TEXT|DT_LEFT|DT_VCENTER                                              },

    { "CloseButton",   MSGID_CLOSEBUTTON, ICQ_BUTTON,   "~Close",    "8.Helv",      0                                                                       },
    { "SaveButton",    MSGID_SENDBUTTON,  ICQ_BUTTON,   "~Save",     "8.Helv",      0                                                                       },
    { "ReloadButton",  MSGID_SENDTO,      ICQ_BUTTON,   "Re~load",   "8.Helv",      0                                                                       },
    { "RefreshButton", MSGID_ADDBUTTON,   ICQ_BUTTON,   "~Refresh",  "8.Helv",      0                                                                       },

    { "MsgButton",     MSGID_MESSAGE,     ICQ_BUTTON,   "",          "8.Helv",      BS_NOBORDER                                                             },
    { "AboutButton",   MSGID_ABOUTBUTTON, ICQ_BUTTON,   "",          "8.Helv",      BS_NOBORDER                                                             },

    { "UserMode",      MSGID_USERMODE,    ICQ_STATIC,   "",          "",            SS_ICON                                                                 },

    { "Tree",          MSGID_OPTIONS,     WC_CONTAINER, "",          "8.Helv",      WS_VISIBLE|WS_TABSTOP|CCS_READONLY                                      }

 };

 static const USHORT userBox[] =   {	MSGID_NICK,
   										MSGID_NICKENTRY,
   										MSGID_NAME,
   										MSGID_NAMEENTRY,
   										MSGID_USERMODE
   							       };

 static const USHORT buttonBar[] = {    MSGID_CLOSEBUTTON,		/* Close button                 */
                                        MSGID_SENDBUTTON,		/* Save configuration           */
                                        MSGID_SENDTO,           /* Reload configuration         */
                                        MSGID_ADDBUTTON         /* Refresh information from srv */
   							        };


/*---[ Prototipes ]---------------------------------------------------------------------------------------*/

 static void   resize(HWND, short, short);
 static USHORT resizeUserInfo(HWND, short, short);
 static void   configureContainer(HWND);

/*---[ Implementation ]-----------------------------------------------------------------------------------*/

 hWindow icqskin_createConfigWindow(HICQ icq)
 {
    ULONG               ulFrameFlags = FCF_TITLEBAR|FCF_SIZEBORDER|FCF_MINMAX|FCF_TASKLIST|FCF_SYSMENU|FCF_NOMOVEWITHOWNER|FCF_ACCELTABLE;
    HWND                frame;
    HWND                hwnd;
    HWND                h;
    ICQCONFIGDIALOG     *cfg;

    frame = WinCreateStdWindow(   HWND_DESKTOP,
    						      0,
  							      &ulFrameFlags,
    							  (PSZ) icqConfigWindowClass,
    							  (PSZ) "pwICQ",
    							  WS_VISIBLE,
    							  (HMODULE) module,
    							  1001,
    							  &hwnd
    						  );
    							
    if(!hwnd)
       return hwnd;

    cfg = WinQueryWindowPtr(hwnd,0);
    WinSetWindowPtr(frame,QWL_USER,cfg);

    icqskin_setICQHandle(hwnd,icq);


    return hwnd;
 }

 MRESULT EXPENTRY icqConfigWindow(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_CREATE:
       icqskin_cfgWindow(hwnd,ICQCONFIGDIALOG);
       break;

    case WM_DESTROY:
       icqskin_destroyCfgWindow(hwnd);
       return icqFrameWindow(hwnd, msg, mp1, mp2);

    case WMICQ_SETUSERID:
       ((ICQCONFIGDIALOG *) WinQueryWindowPtr(hwnd,0))->uin = (ULONG) mp1;
       break;

    case WMICQ_CREATECHILDS:
       icqskin_setMsgWindowChilds(hwnd,childlist);
       break;

    case WMICQ_SETMSGCHILD:
       icqFrameWindow(hwnd, msg, mp1, mp2);
       configureContainer(hwnd);
       break;

//    case WMICQ_SKINCHILDS:
//       break;

    case WMICQ_LOADSKIN:
       icqFrameWindow(hwnd, msg, mp1, mp2);
       WinSendMsg(hwnd,WMICQ_SKINCHILDS,mp1,mp2);
       break;

    case WM_SIZE:
       resize(hwnd,SHORT1FROMMP(mp2),SHORT2FROMMP(mp2));
       return icqFrameWindow(hwnd, msg, mp1, mp2);

    case WMICQ_SIZEMSGBOX:
       return (MRESULT) resizeUserInfo(hwnd,SHORT1FROMMP(mp1),SHORT2FROMMP(mp1));

    default:
       return icqFrameWindow(hwnd, msg, mp1, mp2);
    }

    return 0;
 }

 static USHORT setControlPos(HWND hwnd, USHORT x, USHORT y, USHORT ySize)
 {
    char   buffer[0x0100];
    POINTL aptl[TXTBOX_COUNT];
    HPS    hps;

    ULONG  flag        = SWP_SIZE;

    WinQueryWindowText(hwnd,0xFF,buffer);
    *(buffer+0xFF) = 0;

    hps = WinGetPS(hwnd);

    GpiQueryTextBox(      hps,
                          strlen(buffer),
                          (char *) buffer,
                          TXTBOX_COUNT,
                          aptl);
    WinReleasePS(hps);

    if(x != 0xFFFF && y != 0xFFFF)
       flag |= SWP_MOVE|SWP_SHOW;

    WinSetWindowPos(hwnd, 0, x, y, aptl[TXTBOX_TOPRIGHT].x, ySize, flag);

    return x+aptl[TXTBOX_TOPRIGHT].x;

 }

 static USHORT getControlSize(HWND hwnd)
 {
    char   buffer[0x0100];
    POINTL aptl[TXTBOX_COUNT];

    HPS    hps         =  WinGetPS(hwnd);

    WinQueryWindowText(hwnd,0xFF,buffer);
    *(buffer+0xFF) = 0;

    hps = WinGetPS(hwnd);

    GpiQueryTextBox(      hps,
                          strlen(buffer),
                          (char *) buffer,
                          TXTBOX_COUNT,
                          aptl);
    WinReleasePS(hps);

    return (aptl[TXTBOX_TOPRIGHT].y - aptl[TXTBOX_BOTTOMRIGHT].y)+2;
 }

 static USHORT resizeUserInfo(HWND hwnd, short cx, short cy)
 {
    HWND    h;
    int     f;
    int     qtd         = 0;
    int     ySize;
    int		iconSize;
    USHORT	top;
    int     pos;
    USHORT	y;

    iconSize =
    ySize    = (int) icqskin_querySizes(CHILD_WINDOW(hwnd,MSGID_ABOUTBUTTON),0,0);

    for(f=0;f < (sizeof(userBox)/sizeof(USHORT)); f++)
    {
       h = CHILD_WINDOW(hwnd,userBox[f]);

       if( h && WinIsWindowVisible(h))
       {
          qtd++;
          pos = getControlSize(h);
          if(pos > ySize)
             ySize = pos;
       }

    }

    if(!qtd)
       return 0;

    top = y = (cy-(ySize+8));
    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_NAMEBOX), 0, 0, y, cx, ySize+12, SWP_SIZE|SWP_MOVE);

    y   += 3;

    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_USERMODE), 0, 3, y, iconSize, iconSize, SWP_SIZE|SWP_MOVE);

    pos  = setControlPos(CHILD_WINDOW(hwnd,MSGID_NICK),6+ySize, y, ySize);
    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_NICKENTRY), 0, pos+4, y, (cx/2)-(pos+8), ySize, SWP_SIZE|SWP_MOVE);

    pos  = setControlPos(CHILD_WINDOW(hwnd,MSGID_NAME),cx/2,y,ySize);

    f    = cx-((iconSize*2)+6);
    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_NAMEENTRY), 0, pos+4, y, f-(pos+6), ySize, SWP_SIZE|SWP_MOVE);

    f   += 1;
    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_ABOUTBUTTON), 0, f, y, iconSize, iconSize, SWP_SIZE|SWP_MOVE);

    f   += iconSize+1;
    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_INFOBUTTON), 0, f, y, iconSize, iconSize, SWP_SIZE|SWP_MOVE);

    return top;
 }

 static void configureContainer(HWND hwnd)
 {
    CNRINFO cnrinfo;
    ULONG   clr;

    hwnd = CHILD_WINDOW(hwnd,MSGID_OPTIONS);
    DBGTracex(hwnd);

    clr = CLR_WHITE;
    WinSetPresParam(hwnd,PP_BACKGROUNDCOLORINDEX,sizeof(clr),&clr);
    clr = CLR_BLACK;
    WinSetPresParam(hwnd,PP_FOREGROUNDCOLORINDEX,sizeof(clr),&clr);

 }

 static void resize(HWND hwnd, short cx, short cy)
 {
    USHORT yTop    = icqskin_resizeUserInfoBox(hwnd,cx,cy)+2;
    USHORT yBottom = icqskin_resizeButtonBox(hwnd,cx,buttonBar)+2;
    USHORT xLeft   = 4;
    HWND   h;

    if(yTop < yBottom)
       yTop = cy;

    WinSetWindowPos(CHILD_WINDOW(hwnd,MSGID_INFOBOX), 0, 0, yBottom, cx, yTop-yBottom, SWP_SIZE|SWP_MOVE);

    h = CHILD_WINDOW(hwnd,MSGID_OPTIONS);
    DBGTracex(h);

    if(h &&  WinIsWindowVisible(h))
    {
       CHKPoint();
       WinSetWindowPos(h, 0, xLeft, yBottom+4, 119, yTop-(yBottom+14), SWP_SIZE|SWP_MOVE);
       xLeft += 121;
    }


 }


