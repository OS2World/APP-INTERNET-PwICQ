/*
 * os2bitmap.c - Load Image file
 */

 #pragma strings(readonly)

 #define INCL_DOSMEMMGR
 #define INCL_GPI
 #define INCL_GPILOGCOLORTABLE
 #define INCL_WIN

 #include <string.h>
 #include <io.h>
 #include <os2.h>
 #include <mmioos2.h>
 #include <pwicqgui.h>

/*---[ Prototipes ]---------------------------------------------------------------------------------------*/

#ifdef USE_MMPM
 static HBITMAP LoadBitmap( HAB, HDC, HPS, PSZ );
#endif

/*---[ Implementation ]-----------------------------------------------------------------------------------*/

 HBITMAP icqskin_loadBitmap(HICQ icq, const char *fileName)
 {
#ifndef USE_MMPM

    return NO_IMAGE;

#else

    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HAB                hab             = icqQueryAnchorBlock(icq);
    HDC                hdc;
    HPS                hps;
    HBITMAP            ret             = NO_IMAGE;
    char               buffer[0x0100];

    if(icqskin_queryImage(icq,fileName,0xFF,buffer))
       return ret;

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       ret = LoadBitmap(hab,hdc,hps,buffer);
       GpiDestroyPS(hps);
    }

    DevCloseDC(hdc);

    return ret;

#endif
 }

 int icqskin_loadImageFromResource(HICQ icq, USHORT id, USHORT cx, USHORT cy, HBITMAP *img, HBITMAP *msk)
 {
    char               buffer[0x0100];
    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HAB                hab             = icqQueryAnchorBlock(icq);
    HDC                hdc;
    HPS                hps;
    HBITMAP            src;
    int                rc;

    CHKPoint();

    icqskin_deleteImage( *img );
    icqskin_deleteImage( *msk );

    WinLoadString(hab, module, id, 0xFF, buffer);

    DBGMessage(buffer);
    rc = icqskin_loadImage(icq, buffer, img, msk);

    if(*img != NO_IMAGE)
       return rc;

    DBGMessage("File not found, loading default image");

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       src = GpiLoadBitmap(hps, module, id, cx, cy);
       if(src != GPI_ERROR)
       {
          icqskin_MakeTransparent(hps,src,img,msk);
          GpiDeleteBitmap(src);
       }
       GpiDestroyPS(hps);
    }

    DevCloseDC(hdc);

    return cy;
 }


 int icqskin_loadImage(HICQ icq, const char *fileName, HBITMAP *img, HBITMAP *msk)
 {
#ifndef USE_MMPM

    return 0;

#else

    char               buffer[0x0100];
    HBITMAP            src             = NO_IMAGE;
    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HAB                hab             = icqQueryAnchorBlock(icq);
    int			       rc              = -1;
    HDC                hdc;
    HPS                hps;

    /* Clean old images */

    icqskin_deleteImage( *img );
    icqskin_deleteImage( *msk );

    if(!fileName)
       return -1;

    if(icqskin_queryImage(icq,fileName,0xFF,buffer))
       return rc;

    /* And load the new one */

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       src = LoadBitmap(hab,hdc,hps,buffer);

       if(src != NO_IMAGE)
       {
          rc = icqskin_MakeTransparent(hps,src,img,msk);
          GpiDeleteBitmap(src);
      }
      GpiDestroyPS(hps);

    }

    DevCloseDC(hdc);

    return rc;

#endif

 }

#ifdef MAKELIB
 int EXPENTRY icqMakeBitmapTransparent(HPS hps, HBITMAP src, HBITMAP *img, HBITMAP *msk)
 {
    return icqskin_MakeTransparent(hps, src, img, msk);
 }
#endif

 int icqskin_MakeTransparent(HPS hps, HBITMAP src, HBITMAP *img, HBITMAP *msk)
 {
    int                rc               = 0;
    BITMAPINFOHEADER   bmpData;
    BITMAPINFOHEADER2  bmih;
    POINTL             aptlPoints[4];

    if(src == NO_IMAGE)
    {
       *img = *msk = NO_IMAGE;
       return -1;
    }

    GpiQueryBitmapParameters(src, &bmpData);
    rc = bmpData.cy;

    /* Create masking image */

    memset(&bmih,0, sizeof(BITMAPINFOHEADER2));
    bmih.cbFix        = sizeof(bmih);
    bmih.cx           = bmpData.cx;
    bmih.cy           = bmpData.cy;
    bmih.cPlanes      = 1;
    bmih.cBitCount    = 1;

    *msk = GpiCreateBitmap(hps, &bmih, 0L, NULL, NULL);

    GpiSetBitmap(hps,*msk);

    aptlPoints[0].x=0;
    aptlPoints[0].y=0;
    aptlPoints[1].x=aptlPoints[0].x+bmpData.cx-1;
    aptlPoints[1].y=aptlPoints[0].y+bmpData.cy-1;
    aptlPoints[2].x=0;
    aptlPoints[2].y=0;
    aptlPoints[3].x=aptlPoints[2].x+bmpData.cx;
    aptlPoints[3].y=aptlPoints[2].y+bmpData.cy;

    GpiSetColor(hps,CLR_WHITE);
    GpiSetBackColor(hps,CLR_PINK);
    GpiWCBitBlt(hps,src,4,aptlPoints,ROP_NOTSRCCOPY,BBO_IGNORE);

    /* Create base image */
    *img  = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

    bmih.cbFix        = sizeof(bmih);
    bmih.cx           = bmpData.cx;
    bmih.cy           = bmpData.cy;
    bmih.cPlanes      = 1;
    bmih.cBitCount    = 24;

    *img  = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

    GpiSetBitmap(hps,*img);
    GpiSetColor(hps,CLR_WHITE);
    GpiSetBackColor(hps,CLR_BLACK);

    GpiWCBitBlt( hps,*msk,4,aptlPoints,ROP_NOTSRCCOPY,BBO_IGNORE);
    GpiWCBitBlt( hps,src,4,aptlPoints,ROP_SRCAND,BBO_IGNORE);

    GpiSetBitmap(hps,NULLHANDLE);

    return rc;
 }

 HPOINTER icqskin_CreatePointer(SKINDATA *skn, USHORT id)
 {
    SIZEL              sizl            = { 0, 0 };  /* use same page size as device */
    DEVOPENSTRUC       dop             = { 0, "DISPLAY", NULL, 0L, 0L, 0L, 0L, 0L, 0L};
    HPOINTER           ret			   = NULLHANDLE;
    HAB                hab             = icqQueryAnchorBlock(skn->icq);
    HDC                hdc;
    HPS                hps;
    HBITMAP            bmp;
    BITMAPINFOHEADER2  bmih;
    RECTL              rcl;
    POINTL			   p;
    USHORT			   fator;

    hdc  = DevOpenDC(hab, OD_MEMORY, "*", 5L, (PDEVOPENDATA)&dop, NULLHANDLE);
    hps  = GpiCreatePS(hab, hdc, &sizl, PU_PELS | GPIT_MICRO | GPIA_ASSOC);

    if(hps)
    {
       bmih.cbFix        = sizeof(bmih);
       bmih.cx           = skn->iconSize;
       bmih.cy           = skn->iconSize*2;
       bmih.cPlanes      = 1;
       bmih.cBitCount    = 24;
       bmp               = GpiCreateBitmap(  hps, &bmih, 0L, NULL, NULL);

       GpiSetBitmap(hps,bmp);

/*
       Bit-map handle from which the pointer image is created.

       The bit map must be logically divided into two sections vertically,
       each half representing one of the two images used as the successive
       drawing masks for the pointer.

       For an icon, there are two bit map images.
       The first half is used for the AND mask and the second half is used
       for the XOR mask. For details of bit map formats, see
*/

       rcl.xLeft   =
       rcl.yBottom = 0;

       rcl.yTop    = skn->iconSize*2;
       rcl.xRight  = skn->iconSize;

       WinFillRect(hps, &rcl, CLR_BLACK);

       fator       = skn->iconSize * id;
       rcl.xLeft   = fator;
       rcl.yBottom = 0;
       rcl.yTop    = skn->iconSize;
       rcl.xRight  = fator+skn->iconSize;

       p.x = 0;
       p.y = 0;
       WinDrawBitmap(hps, skn->iconImage, &rcl, &p, CLR_WHITE, CLR_BLACK, DBM_NORMAL);

       p.x = 0;
       p.y = skn->iconSize;
       WinDrawBitmap(hps, skn->iconMasc, &rcl, &p, CLR_WHITE, CLR_BLACK, DBM_NORMAL);

       GpiSetBitmap(hps,NULLHANDLE);

       ret = WinCreatePointer(HWND_DESKTOP, bmp, TRUE, 0, 0);
       DBGTracex(ret);

       GpiDeleteBitmap(bmp);
       GpiDestroyPS(hps);
    }

    DevCloseDC(hdc);
    return ret;

 }

#ifdef USE_MMPM

 static HBITMAP LoadBitmap( HAB hab, HDC hdc, HPS hps, PSZ pszFileName )
 {
     HBITMAP       hbm;
     MMIOINFO      mmioinfo;
     MMFORMATINFO  mmFormatInfo;
     HMMIO         hmmio;
     ULONG         ulImageHeaderLength;
     MMIMAGEHEADER mmImgHdr;
     ULONG         ulBytesRead;
     ULONG         dwNumRowBytes;
     PBYTE         pRowBuffer;
     ULONG         dwRowCount;
     SIZEL         ImageSize;
     ULONG         dwHeight, dwWidth;
     SHORT         wBitCount;
     FOURCC        fccStorageSystem;
     ULONG         dwPadBytes;
     ULONG         dwRowBits;
     ULONG         ulReturnCode;
     ULONG         dwReturnCode;
     HBITMAP       hbReturnCode;
     LONG          lReturnCode;
     FOURCC        fccIOProc;

 //    DBGMessage(pszFileName);

     ulReturnCode = mmioIdentifyFile ( pszFileName,
                                       0L,
                                       &mmFormatInfo,
                                       &fccStorageSystem,
                                       0L,
                                       0L);

     /*
      *  If this file was NOT identified, then this function won't
      *  work, so return an error by indicating an empty bitmap.
      */

     if ( ulReturnCode == MMIO_ERROR )
     {
          DBGMessage("Erro em mmioIdentifyFile");
          return NO_IMAGE;
     }

     /*
      *  If mmioIdentifyFile did not find a custom-written IO proc which
      *  can understand the image file, then it will return the DOS IO Proc
      *  info because the image file IS a DOS file.
      */

     if( mmFormatInfo.fccIOProc == FOURCC_DOS )
     {

          WinMessageBox( HWND_DESKTOP,
                         HWND_DESKTOP,
                         "Image file could not be interpreted by any permanently or temporarily installed IO procedures.",
                         pszFileName,
                         (HMODULE) NULL,
                         (ULONG) MB_OK | MB_MOVEABLE |
                                 MB_ERROR );
          return NO_IMAGE;
     }

     /*
      *  Ensure this is an IMAGE IOproc, and that it can read
      *  translated data
      */

     if ( (mmFormatInfo.ulMediaType != MMIO_MEDIATYPE_IMAGE) ||
          ((mmFormatInfo.ulFlags & MMIO_CANREADTRANSLATED) == 0) )
     {

          WinMessageBox( HWND_DESKTOP,
                         HWND_DESKTOP,
                         "No IMAGE IO Procedures exist which can translate the data in the image file specified.",
                         pszFileName,
                         (HMODULE) NULL,
                         (ULONG) MB_OK | MB_MOVEABLE |
                                 MB_ERROR );
          return NO_IMAGE;
     }
     else
     {
          fccIOProc = mmFormatInfo.fccIOProc;
     }

     /* Clear out and initialize mminfo structure */

     memset ( &mmioinfo,
              0L,
              sizeof ( MMIOINFO ) );

     mmioinfo.fccIOProc = fccIOProc;
     mmioinfo.ulTranslate = MMIO_TRANSLATEHEADER | MMIO_TRANSLATEDATA;

     hmmio = mmioOpen ( (PSZ) pszFileName,
                        &mmioinfo,
                        MMIO_READ | MMIO_DENYWRITE | MMIO_NOIDENTIFY );

     if ( ! hmmio )
     {
          /* If file could not be opened, return with error */
          DBGMessage("Erro em mmioOpen");
          return NO_IMAGE;
     }

     dwReturnCode = mmioQueryHeaderLength ( hmmio,
                                          (PLONG)&ulImageHeaderLength,
                                            0L,
                                            0L);

     if ( ulImageHeaderLength != sizeof ( MMIMAGEHEADER ) )
     {
          /* We have a problem.....possibly incompatible versions */

          ulReturnCode = mmioClose (hmmio, 0L);
          return NO_IMAGE;
     }

     ulReturnCode = mmioGetHeader ( hmmio,
                                    &mmImgHdr,
                                    (LONG) sizeof ( MMIMAGEHEADER ),
                                    (PLONG)&ulBytesRead,
                                    0L,
                                    0L);

     if ( ulReturnCode != MMIO_SUCCESS )
     {
          /* Header unavailable */
          DBGMessage("Erro em mmioGetHeader");
          ulReturnCode = mmioClose (hmmio, 0L);
          return NO_IMAGE;
     }

     /*
      *  Determine the number of bytes required, per row.
      *      PLANES MUST ALWAYS BE = 1
      */

     dwHeight = mmImgHdr.mmXDIBHeader.BMPInfoHeader2.cy;
     dwWidth = mmImgHdr.mmXDIBHeader.BMPInfoHeader2.cx;
     wBitCount = mmImgHdr.mmXDIBHeader.BMPInfoHeader2.cBitCount;
     dwRowBits = dwWidth * mmImgHdr.mmXDIBHeader.BMPInfoHeader2.cBitCount;
     dwNumRowBytes = dwRowBits >> 3;

     /*
      *  Account for odd bits used in 1bpp or 4bpp images that are
      *  NOT on byte boundaries.
      */

     if ( dwRowBits % 8 )
     {
          dwNumRowBytes++;
     }

     /*
      *  Ensure the row length in bytes accounts for byte padding.
      *  All bitmap data rows must are aligned on LONG/4-BYTE boundaries.
      *  The data FROM an IOProc should always appear in this form.
      */

     dwPadBytes = ( dwNumRowBytes % 4 );

     if ( dwPadBytes )
     {
          dwNumRowBytes += 4 - dwPadBytes;
     }

     /* Allocate space for ONE row of pels */

     if ( DosAllocMem( (PPVOID)&pRowBuffer,
                       (ULONG)dwNumRowBytes,
                       fALLOC))
     {
          ulReturnCode = mmioClose (hmmio, 0L);
          DBGMessage("Erro de alocacao de memoria");
          return NO_IMAGE;
     }

     /* ***************************************************
        Create a memory presentation space that includes
        the memory device context obtained above.
        ***************************************************/

     ImageSize.cx = dwWidth;
     ImageSize.cy = dwHeight;

     /* ***************************************************
        Create an uninitialized bitmap.  This is where we
        will put all of the bits once we read them in.
        ***************************************************/

     hbm = GpiCreateBitmap ( hps,
                             &mmImgHdr.mmXDIBHeader.BMPInfoHeader2,
                             0L,
                             NULL,
                             NULL);

     if ( !hbm )
     {
          ulReturnCode = mmioClose (hmmio, 0L);
          return NO_IMAGE;
     }

     /* ***************************************************
        Select the bitmap into the memory device context.
        *************************************************** */

     hbReturnCode = GpiSetBitmap ( hps,
                                   hbm );

     /****************************************************************
         LOAD THE BITMAP DATA FROM THE FILE
             One line at a time, starting from the BOTTOM
      *************************************************************** */

     for ( dwRowCount = 0; dwRowCount < dwHeight; dwRowCount++ )
     {
          ulBytesRead = (ULONG) mmioRead ( hmmio,
                                           pRowBuffer,
                                           dwNumRowBytes );

          if ( !ulBytesRead )
          {
               break;
          }

          /*
           *  Allow context switching while previewing.. Couldn't get
           *  it to work. Perhaps will get to it when time is available...
           */

          lReturnCode = GpiSetBitmapBits ( hps,
                                           (LONG) dwRowCount,
                                           (LONG) 1,
                                           (PBYTE) pRowBuffer,
                                           (PBITMAPINFO2) &mmImgHdr.mmXDIBHeader.BMPInfoHeader2);

     }

     ulReturnCode = mmioClose (hmmio, 0L);

     DosFreeMem(pRowBuffer);

     return(hbm);
 }

#endif


