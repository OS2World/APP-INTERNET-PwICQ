/*
 * edit.c - Window management callbacks
 */

#ifdef __OS2__
 #pragma strings(readonly)
 #define INCL_WIN
#endif

 #define MSGEDITWINDOW hWindow

 #include <string.h>
 #include <pwicqgui.h>

/*---[ Macros ]-------------------------------------------------------------------------------------------*/

#ifdef __OS2__
   #define CHILD_WINDOW(h,i) WinWindowFromID(h,i + (i < DLG_ELEMENT_ID ? DLG_ELEMENT_ID : 0))
#else
   #define CHILD_WINDOW(h,i) icqskin_getDlgItemHandle(h,i)
#endif

/*---[ Prototipes ]---------------------------------------------------------------------------------------*/

 static int   _System setTitle(hWindow,const char *);
 static int   _System setMessage(hWindow, USHORT, BOOL, HMSG);

 static int   _System setVisible(hWindow, USHORT, BOOL);
 static int   _System getVisible(hWindow, USHORT);

 static int   _System setEnabled(hWindow, USHORT, BOOL);

 static int   _System setString(hWindow,USHORT,const char *);
 static int   _System getString(hWindow,USHORT,int,char *);

 static int   _System setCheckBox(hWindow,USHORT,BOOL);
 static int   _System getCheckBox(hWindow,USHORT);

 static int   _System loadUserFields(hWindow);
 static void  _System loadString(hWindow, USHORT, USHORT);

 static void  _System setReply(hWindow, USHORT);
 static void  _System setTime(hWindow, USHORT, time_t);

 static void  _System setEditable(hWindow, USHORT, BOOL);
 static void  _System setIcon(hWindow,USHORT,USHORT);

 static int   _System queryClipboard(HICQ, int, char *);

/*---[ Constants ]----------------------------------------------------------------------------------------*/

 const DIALOGCALLS icqskin_dialogCalls =
 {
    sizeof(DIALOGCALLS),

    /* Frame Window only */
    setTitle,
    setVisible,
    getVisible,
    setEnabled,
    setString,
    getString,
    setCheckBox,
    getCheckBox,
    loadString,
    setTime,
	setEditable,
	setIcon,
	
    /* Miscellaneous */	
	queryClipboard,

    /* Message dialog only */
    setMessage,
    loadUserFields,
    setReply,

 };

/*---[ Implementation ]-----------------------------------------------------------------------------------*/

 static int _System setTitle(MSGEDITWINDOW hwnd,const char *title)
 {
    return 0;
 }

 static int _System setMessage(MSGEDITWINDOW hwnd, USHORT type, BOOL out, HMSG msg)
 {
    return 0;
 }

 static int _System setVisible(MSGEDITWINDOW hwnd, USHORT id, BOOL visible)
 {
    hwnd = CHILD_WINDOW(hwnd,id);

    if(!hwnd)
       return -1;

    if(visible)
       icqskin_show(hwnd);
    else
       icqskin_hide(hwnd);

    return 0;
 }

 static int _System setEnabled(MSGEDITWINDOW hwnd, USHORT id, BOOL enabled)
 {
    hwnd = CHILD_WINDOW(hwnd,id);

    if(!hwnd)
       return -1;

    icqskin_setEnabled(hwnd,enabled);

    return 0;
 }

 static int _System setString(MSGEDITWINDOW hwnd, USHORT id, const char *text)
 {
#ifdef __OS2__
    if(id >= DLG_ELEMENT_ID)
       id -= DLG_ELEMENT_ID;
#endif
	
	if(id < MSG_WINDOW_COMPONENTS)
       icqskin_setMsgWindowText(hwnd, id, text);
	
    return 0;
 }

 static int _System getString(MSGEDITWINDOW hwnd, USHORT id, int sz, char *text)
 {
#ifdef __OS2__
    if(id >= DLG_ELEMENT_ID)
       id -= DLG_ELEMENT_ID;
#endif
    icqskin_getMsgWindowText(hwnd, id, sz, text);
    return 0;
 }

 static int _System setCheckBox(MSGEDITWINDOW hwnd, USHORT id, BOOL check)
 {
    return 0;
 }

 static int _System getCheckBox(MSGEDITWINDOW hwnd, USHORT id)
 {
    return 0;
 }

 static int _System loadUserFields(MSGEDITWINDOW hwnd)
 {
    ICQMSGDIALOG *cfg             = icqskin_getWindowDataBlock(hwnd);
    HUSER        usr              = NULL;
    char         buffer[0x0100];

    if(cfg->uin > SYSTEM_UIN)
       usr = icqQueryUserHandle(cfg->fr.icq,cfg->uin);

    icqskin_setMsgWindowText(hwnd,MSGID_NICK,"Nick:");
    icqskin_setMsgWindowText(hwnd,MSGID_NAME,"Name:");

    if(usr)
    {
       icqskin_setMsgWindowText(hwnd,MSGID_NICKENTRY,icqQueryUserNick(usr));

       strncpy(buffer,icqQueryUserFirstName(usr),0xFF);
       strncat(buffer," ",0xFF);
       strncat(buffer,icqQueryUserLastName(usr),0xFF);
       *(buffer+0xFF) = 0;
       icqskin_setMsgWindowText(hwnd,MSGID_NAMEENTRY,buffer);

       if(usr->modeIcon == usr->offlineIcon)
          icqskin_setDlgItemIcon(hwnd,MSGID_USERMODE,ICQICON_OFFLINE);
       else
          icqskin_setDlgItemIcon(hwnd,MSGID_USERMODE,usr->modeIcon);
    }
    else
    {
       icqskin_setMsgWindowText(hwnd,MSGID_NICKENTRY,"N/A");
       icqskin_setMsgWindowText(hwnd,MSGID_NAMEENTRY,"N/A");
       icqskin_setDlgItemIcon(hwnd,MSGID_USERMODE,ICQICON_OFFLINE);
    }

    return 0;
 }

 static void _System loadString(MSGEDITWINDOW hwnd, USHORT id, USHORT resource)
 {
#ifdef __OS2__
    char buffer[40];
    WinLoadString(WinQueryAnchorBlock(hwnd), module, resource, 39, (PSZ) buffer);
    WinSetWindowText(WinWindowFromID(hwnd,id),buffer);
#endif
 }

 static void _System setReply(MSGEDITWINDOW hwnd, USHORT type)
 {

 }

 static void _System setTime(MSGEDITWINDOW hwnd, USHORT id, time_t tm)
 {
    char buffer[80];
    strftime(buffer,79,"%m/%d/%Y %H:%M:%S ",localtime(&tm));
    setString(hwnd,id,buffer);
 }

 static void  _System setEditable(hWindow hwnd, USHORT id, BOOL flag)
 {
    hwnd = CHILD_WINDOW(hwnd,id);

    if(flag)	
       icqskin_setEditable(hwnd);
    else
	   icqskin_setReadOnly(hwnd);

 }

 static int _System getVisible(hWindow hwnd, USHORT id)
 {
    hwnd = CHILD_WINDOW(hwnd,id);
	
	DBGTracex(hwnd);
    DBGTrace(icqskin_getVisibility(hwnd));
	CHKPoint();
	
    return (int) icqskin_getVisibility(hwnd);
 }

 static void _System setIcon(hWindow hwnd, USHORT id, USHORT icon)
 {
    hwnd = CHILD_WINDOW(hwnd,id);
    icqskin_setButtonIcon(hwnd,icon);
 }

 static int _System queryClipboard(HICQ icq, int sz, char *buffer)
 {
#ifdef __OS2__
    return icqskin_queryClipboard(icq, sz, buffer);
#else
    /* For some reason GTK2 hangs when using icqskin_queryClipboard in this context */
    *buffer = 0;
    return 0;	
#endif	
 }

