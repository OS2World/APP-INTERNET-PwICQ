/*
 * MAIN.C - pwICQ's Skin manager entry points
 */

#ifdef __OS2__
 #pragma strings(readonly)
#endif

 #include <pwicqgui.h>

/*---[ Table descriptions ]--------------------------------------------------------------------------------*/

  HMODULE                     module                   = 0;

  const struct icqButtonTable icqgui_MainButtonTable[] =
  {
     { ID_MODE,        7, -3,  3, -68, 22,     "ModeButton",   (BUTTON_CALLBACK) icqskin_modeButton,   "Offline",    "8.Helv"  },
     { ID_CONFIG, 0xFFFF,  3,  3,  60, 22,     "SysButton",    (BUTTON_CALLBACK) icqskin_configButton, "pwICQ",      "8.Helv"  },
     { ID_SYSMSG,     10,  3, 28,  -6, 0xFFFF, "SysMsgButton", (BUTTON_CALLBACK) icqskin_sysmsgButton, "System",     "8.Helv"  },
     { ID_SEARCH,     11,  3, 53,  -6, 0xFFFF, "SearchButton", (BUTTON_CALLBACK) icqskin_searchButton, "Search/Add", "8.Helv"  }
  };

  const int icqgui_MainButtonTableElements = sizeof(icqgui_MainButtonTable)/sizeof(struct icqButtonTable);





