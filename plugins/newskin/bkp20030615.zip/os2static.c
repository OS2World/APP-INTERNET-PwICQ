/*
 * os2static.c - OS/2 Static control
 */

 #pragma strings(readonly)

 #define INCL_WIN
 #define INCL_GPI

 #include <string.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <pwicqgui.h>

/*---[ Defines ]------------------------------------------------------------------------------------------*/


/*---[ Control data structure ]---------------------------------------------------------------------------*/

 #pragma pack(1)

 typedef struct _icqstatic
 {
    USHORT  sz;
    HICQ    icq;
    USHORT  icon;					

    char    text[1];
 } ICQSTATIC;

/*---[ Constants ]----------------------------------------------------------------------------------------*/

 const char *icqStaticWindowClass = ICQ_STATIC;

/*---[ Prototipes ]---------------------------------------------------------------------------------------*/

 static void destroy(HWND);
 static void create(HWND, PCREATESTRUCT);
 static void erase(HWND, HPS, PRECTL);
 static void paint(HWND);
 static int  querySizes(HWND,USHORT *,USHORT *);

/*---[ Implementation ]-----------------------------------------------------------------------------------*/

 MRESULT EXPENTRY icqStaticWindow(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2)
 {
    switch(msg)
    {
    case WM_CREATE:
       create(hwnd,(PCREATESTRUCT) mp2);
       break;

    case WMICQ_SETICON:
       DBGTrace(mp1);
       ((ICQSTATIC *) WinQueryWindowPtr(hwnd,0))->icon = SHORT1FROMMP(mp1);
       CHKPoint();
       WinInvalidateRect(hwnd,NULL,FALSE);
       break;

    case WMICQ_SETICQHANDLE:
       ((ICQSTATIC *) WinQueryWindowPtr(hwnd,0))->icq  = (HICQ) mp1;
       break;

    case WM_DESTROY:
       destroy(hwnd);
       break;

    case WM_ERASEBACKGROUND:
       erase(hwnd,(HPS) mp1, (PRECTL) mp2);
       break;

    case WM_PAINT:
       paint(hwnd);
       break;

    case WMICQ_QUERYSIZES:
       return (MRESULT) querySizes(hwnd, (USHORT *) mp1, (USHORT *) mp2);

    default:
       return WinDefWindowProc(hwnd,msg,mp1,mp2);

    }

    return 0;
 }

 static void destroy(HWND hwnd)
 {
    ICQSTATIC *cfg = WinQueryWindowPtr(hwnd,0);

    if(!cfg || cfg->sz != sizeof(ICQSTATIC))
       return;


    cfg->sz = 0;
    free(cfg);
 }

 static void create(HWND hwnd, PCREATESTRUCT cr)
 {
    USHORT    sz		= sizeof(ICQSTATIC);
    ICQSTATIC *cfg;

    /* Calculate the data block size based in Window Style */

    DBGTracex(WinQueryWindowULong(hwnd,QWL_STYLE));

    cfg = malloc(sz);
    WinSetWindowPtr(hwnd,0,cfg);
    if(!cfg)
    {
       WinPostMsg(hwnd,WM_CLOSE,0,0);
       return;
    }

    cfg->sz    = sizeof(ICQSTATIC);
    cfg->icon  = NO_ICON;

 }

 void icqskin_eraseRect(HWND hwnd, HPS hps, PRECTL rcl)
 {
    HWND       owner = WinQueryWindow(hwnd, QW_OWNER);
    HBITMAP    bg    = icqskin_queryBackground(owner);

    RECTL	   rMap;
    POINTL     p;

    icqskin_selectPallete(owner,hps);

    if(bg == NO_IMAGE)
    {
       WinFillRect(hps, rcl, ICQCLR_BACKGROUND);
    }
    else
    {
       rMap.xLeft   = rcl->xLeft;
       rMap.xRight  = rcl->xRight;
       rMap.yTop    = rcl->yTop;
       rMap.yBottom = rcl->yBottom;
       WinMapWindowPoints(hwnd, owner, (POINTL *) &rMap, 2);

       p.x = rcl->xLeft;
       p.y = rcl->yBottom;
       WinDrawBitmap(hps, bg, &rMap, &p, CLR_WHITE, CLR_BLACK, DBM_NORMAL);
    }

 }

 static void erase(HWND hwnd, HPS hps, PRECTL rcl)
 {
    ICQSTATIC  *cfg = WinQueryWindowPtr(hwnd,0);

    hps = WinBeginPaint(hwnd,NULLHANDLE,rcl);

    icqskin_eraseRect(hwnd, hps, rcl);

    if(cfg && cfg->icq && cfg->icon != NO_ICON)
       icqskin_drawIcon(icqGetSkinDataBlock(cfg->icq), hps, cfg->icon, 3, 3);

    WinEndPaint(hps);

 }

 static void paint(HWND hwnd)
 {
    HPS   hps;
    RECTL rcl;
    erase(hwnd,hps,&rcl);
 }


 static int querySizes(HWND hwnd, USHORT *xPtr, USHORT *yPtr)
 {
    ICQSTATIC        *cfg = WinQueryWindowPtr(hwnd,0);
    int				 x    = 0;
    SKINDATA         *skn;

    if(cfg->icon != NO_ICON && cfg->icq)
    {
       skn  = icqGetSkinDataBlock(cfg->icq);
       if(skn)
          x = skn->iconSize+6;
    }

    return x;
 }


