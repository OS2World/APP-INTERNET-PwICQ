/*
 * gtkframe.c - GTK Frame functions
 */
 
 #include <pwicqgui.h>
 #include <string.h>
 #include <unistd.h>

/*---[ Implementation ]-------------------------------------------------------*/

 int icqskin_setFrameIcon(hWindow hwnd, SKINDATA *cfg, USHORT id)
 {
#ifdef GTK2	
	gtk_window_set_icon(GTK_WINDOW(hwnd),cfg->icons[id]);
#endif	
	return 0;
 }

 int icqskin_setFrameTitle(hWindow hwnd, const char *title)
 {
	gtk_window_set_title(GTK_WINDOW(hwnd),title);
	return 0;
 }

 int icqskin_setDlgItemHandle(hWindow hwnd, USHORT id, hWindow child)
 {
	ICQFRAME *frame = gtk_object_get_user_data(GTK_OBJECT(hwnd));
	hWindow  *wndChilds;
	
	if(!frame)
	{ 
	   DBGMessage("Invalid Call to icqskin_setDlgItemHandle"); 
	   return -1;
	}
	
	if(id > frame->childs)
	{
	   DBGMessage("Invalid child window ID when setting DLG Handle");
	   return -1;
	}

	wndChilds     = (hWindow *) (((char *)frame) + frame->sz);
	wndChilds[id] = child;
	
	return 0;
	
 }

 hWindow icqskin_getDlgItemHandle(hWindow hwnd, USHORT id)
 {
	ICQFRAME *frame = gtk_object_get_user_data(GTK_OBJECT(hwnd));
	hWindow  *wndChilds;
	
	if(!frame)
	{ 
	   DBGMessage("Invalid Call to icqskin_getDlgItemHandle"); 
	   return NULL;
	}
	
	if(id >= frame->childs)
	{
	   DBGPrint("Invalid child window ID %d when querying DLG Handle",id);
	   return NULL;
	}

	wndChilds = (hWindow *) (((char *)frame) + frame->sz);
	
#ifdef DEBUG	
	if(!wndChilds[id])
	   DBGMessage("****** NO CHILD WINDOW ON DLGITEMHANDLE REQUEST");
#endif	

	return wndChilds[id];
	
 }
 
 int icqskin_setICQHandle(hWindow hwnd, HICQ icq)
 {
	ICQFRAME *frame = gtk_object_get_user_data(GTK_OBJECT(hwnd));
    frame->icq = icq;
    return 0;	
 }
 
 void icqskin_storeFrame(hWindow hwnd,const char *key)
 {
	ICQFRAME *frame = gtk_object_get_user_data(GTK_OBJECT(hwnd));
    gint     x,
	         y,
	         width,
	         height;
	
    char buffer[80];
	
	if(!(frame && frame->icq))
	   return;

    if(!(hwnd && hwnd->window))
	{
	   sprintf(buffer,"Invalid save \"%s\" request",key);
	   DBGMessage(buffer);
	   icqWriteSysLog(frame->icq,PROJECT,buffer);
	   return;
	}
	
	DBGTracex(hwnd);
	DBGTracex(hwnd->window);

    if( !gdk_window_get_deskrelative_origin(hwnd->window,&x,&y))
       return;

    gdk_window_get_size(hwnd->window,&width,&height);

    sprintf(buffer,"%d,%d,%d,%d",x,y,width,height);

    icqSaveString(frame->icq,key,buffer);
	
 }

 
 void icqskin_restoreFrame(hWindow hwnd, const char *key, USHORT w, USHORT h)
 {
	ICQFRAME *frame = gtk_object_get_user_data(GTK_OBJECT(hwnd));
    int      x,
	         y,
	         width,
	         height;
	
    char     buffer[80];
	
	if(key)
       icqLoadString(frame->icq,key,"",buffer,79);
    else
	   *buffer = 0;

    if(!*buffer)
    {
       gtk_window_set_default_size(GTK_WINDOW(hwnd),w,h);
       return;
    }

    DBGMessage(buffer);
    if(sscanf(buffer,"%d,%d,%d,%d",&x,&y,&width,&height) != 4)
    {
       gtk_window_set_default_size(GTK_WINDOW(hwnd),w,h);
       return;
    }

	DBGTrace(width);
	DBGTrace(height);
	
    gtk_window_set_default_size(GTK_WINDOW(hwnd),width,height);
	
	return;
 }
 
 int icqskin_setFrameName(hWindow hwnd, const char *name)
 {
	return 0;
 }

