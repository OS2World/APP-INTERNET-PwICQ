/*
 * gtkmenu.c - GTK implementation of pwICQ menus
 */

 #include <pwicqgui.h>
 #include <string.h>
 #include <malloc.h>

/*---[ Structures ]-----------------------------------------------------------*/

 #pragma pack(1)
 struct menu_option
 {
	HICQ         icq;
    hWindow		 hwnd;
    USHORT 		 id;
    MENUCALLBACK *cbk;
	ULONG        cbkParm;
 };

 struct menu_data
 {
	SKINDATA *cfg;
	ULONG    uin;
 };

/*---[ Prototipes ]-----------------------------------------------------------*/

 static void menuAction(const struct menu_option *);

/*---[ Implementation ]-------------------------------------------------------*/

 hWindow icqskin_CreateMenu(HICQ icq, USHORT id, SKINDATA *cfg)
 {
	struct menu_data parm = { cfg, 0 };
    hWindow ret = gtk_menu_new();
    gtk_object_set_user_data(GTK_OBJECT(ret),g_memdup(&parm, sizeof(parm)));
	return ret;
 }

 void icqskin_showMenu(hWindow hwnd, ULONG uin, USHORT x, USHORT y)
 {
	struct menu_data *parm = gtk_object_get_user_data(GTK_OBJECT(hwnd));
	
	if(!parm)
	   return;
	
	parm->uin = uin;
	
	gtk_menu_popup(GTK_MENU(hwnd),NULL,NULL,NULL,NULL,0,0);
	
 }

 void icqskin_setMenuTitle(HICQ icq, USHORT id, const char *title)
 {
	SKINDATA *skn = icqGetSkinDataBlock(icq);
	DBGTrace(id);
	if(id >= ICQMNU_COUNTER || !skn->menu[id])
	   return;
    gtk_menu_set_title(GTK_MENU(skn->menu[id]),title);
 }

 int _System icqskin_insertMenu(HICQ icq, USHORT menu, const char *text, USHORT icon, MENUCALLBACK *cbk, ULONG p)
 {
    GtkWidget           *box;
    GtkWidget           *item;
	SKINDATA            *skn   = icqGetSkinDataBlock(icq);
    struct menu_option	parm   = { icq, NULL, icon, cbk, p };
	
	if(menu >= ICQMNU_COUNTER || !skn->menu[menu])
	   return -1;
	
	parm.hwnd = skn->menu[menu];
    box       = gtk_hbox_new(FALSE,5);
    item      = gtk_menu_item_new();
	
    gtk_box_pack_start(GTK_BOX(box), gtk_pixmap_new(skn->iPixmap[icon],skn->iBitmap[icon]), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), gtk_label_new(text),  FALSE, FALSE, 0);

    gtk_container_add(GTK_CONTAINER(item),box);
    gtk_menu_append(GTK_MENU(skn->menu[menu]),item);
    gtk_widget_show_all(item);
	
    gtk_signal_connect_object(GTK_OBJECT(item), "activate", GTK_SIGNAL_FUNC(menuAction), g_memdup(&parm, sizeof(parm)));
	
    return 0; 	
 }

 static void menuAction(const struct menu_option *opt)
 {
	struct menu_data *parm = gtk_object_get_user_data(GTK_OBJECT(opt->hwnd));
	
    if(opt->cbk && parm)
       opt->cbk(opt->icq, parm->uin, opt->id, (ULONG) opt->cbkParm);
 }

