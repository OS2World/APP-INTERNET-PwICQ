/*
 * LIBMAIN.C - OS2Win compatible entry points
 */

#ifdef __OS2__
 #pragma strings(readonly)
 int _CRT_init(void);
#endif

 #include <string.h>
 #include <stdio.h>

 #include <pwicqgui.h>

/*---[ Data block ]---------------------------------------------------------------------------------------*/

 SKINDATA icqskin_dataBlock = { 0 };

/*---[ Implementation ]-----------------------------------------------------------------------------------*/

 unsigned long _System _DLL_InitTerm(unsigned long hModule, unsigned long ulFlag)
 {
    switch (ulFlag)
    {
    case 0 :
       if (_CRT_init() == -1)
          return 0UL;
       memset(&icqskin_dataBlock,0,sizeof(icqskin_dataBlock));
       break;

    case 1 :
       break;

    default  :
       return 0UL;
    }

    module = hModule;
    return 1UL;
 }

 APIRET EXPENTRY icqStartWindowTools(HICQ icq, HAB hab)
 {

    CHKPoint();

    if(icqQueryUserDataBlockLength() != sizeof(ICQUSER))
    {
       icqWriteSysLog(icq,PROJECT,"Invalid core version detected");
       return -1;
    }

    icqWriteSysLog(icq,PROJECT,"OS/2 PM layer version " ICQGUI_INCLUDED " Build " __DATE__ " " __TIME__ " by " USER "@" HOSTNAME);

    return 0;
 }

 APIRET EXPENTRY icqExecuteWindowLoop(HICQ icq)
 {
    QMSG        qmsg;
    HAB         hab     = icqQueryAnchorBlock(icq);

    while(WinGetMsg(hab,&qmsg,0,0,0))
       WinDispatchMsg(hab,&qmsg);

    return 0;
 }


 APIRET EXPENTRY icqStopWindowTools(HICQ icq)
 {
    CHKPoint();

    return 0;
 }

 void  EXPENTRY icqDefaultMsgPreProcessor(HICQ icq, HUSER usr, ULONG uin, struct icqmsg *msg, BOOL convert)
 {

 }

 void EXPENTRY icqAjustDefaultMsgDialog(HWND hwnd, HICQ icq, ULONG flags, USHORT type, BOOL out)
 {

 }

 const MSGMGR * EXPENTRY icqQueryDefaultMsgMgr(HICQ icq)
 {

    return NULL;
 }

 void EXPENTRY icqAjustFrameTitle(HICQ icq, HWND hwnd, const char *txt, HPOINTER *ptrMode)
 {
    icqWriteSysLog(icq,PROJECT,"Deprecated call to icqAjustFrameTitle()");
 }

 void EXPENTRY icqAjustTaskList(HICQ icq, HWND hwnd, const char *txt)
 {

 }

 int EXPENTRY icqValidateDefaultEditHelper(USHORT sz)
 {
    return sz == sizeof(MSGEDITHELPER) ? 0 : 99;
 }

 int EXPENTRY icqLoadIconTable(HICQ icq, HBITMAP *img, HBITMAP *msk)
 {
    return 0;
 }

 int EXPENTRY icqMakeBitmapTransparent(HPS hps, HBITMAP src, HBITMAP *img, HBITMAP *msk)
 {
    return -1;
 }

 int icqskin_postEvent(HICQ icq, ULONG uin, char id, USHORT event, ULONG parm)
 {
    icqWriteSysLog(icq,PROJECT,"***** UNEXPECTED CALL TO ICQSKIN_POST_EVENT");
    return -1;
 }

 APIRET EXPENTRY icqOpenDefaultConfigurationWindow(HICQ icq, ULONG uin, USHORT type, PAGELOADER *load)
 {
    return 0;
 }

 void EXPENTRY icqLogonDialog(HICQ icq)
 {

 }

 APIRET EXPENTRY icqRegisterConfigurationWindow(HICQ icq, HAB hab)
 {
    return 0;
 }

 int EXPENTRY icqOpenSearchWindow(HICQ icq, USHORT id)
 {
    return 0;
 }

 HPOINTER EXPENTRY icqCreatePointer(HICQ icq, int id)
 {
    return icqskin_CreatePointer(icqskin_getDataBlock(icq), id);
 }



